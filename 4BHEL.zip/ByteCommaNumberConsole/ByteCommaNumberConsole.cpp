// ByteCommaNumberConsole.cpp : Definiert den Einstiegspunkt f�r die Konsolenanwendung.
//

#include "stdafx.h"
#include <cstdint>

const int noBytes = 8;
const int coBytes = 3;
const int siBits = 8;

void GetZero(uint8_t no[]);

void AddOne(uint8_t no[]);

void AddOneAt(uint8_t no[], int itemIndex, int bitIndex);

void Copy(uint8_t no[], uint8_t copy[]);

void Add(uint8_t no1[], uint8_t no2[], uint8_t result[]);

void AddTo1(uint8_t no1[], uint8_t no2[]);

void Sub(uint8_t no1[], uint8_t no2[], uint8_t result[]);

void SubTo1(uint8_t no1[], uint8_t no2[]);

void Mul(uint8_t no1[], uint8_t no2[], uint8_t result[]);

void MulWithBit(uint8_t isBitNo1Set, uint8_t no2[], uint8_t result[], int iR, int jR);

void Div(uint8_t no1[], uint8_t no2[], uint8_t result[]);

int IsHigher(uint8_t no1[], uint8_t no2[]);

int IsHigherZero(uint8_t no[]);

void Shift(uint8_t no[], int by);

void ShiftRight(uint8_t no[], int by);

void ShiftLeft(uint8_t no[], int by);

uint8_t IsBitSet(uint8_t no, uint8_t index);

void SetBit(uint8_t no[], int arrayIndex, int bitIndex, uint8_t value);

int main()
{
	uint8_t no1[noBytes];
	uint8_t no2[noBytes];
	uint8_t no3[noBytes];

	GetZero(no1);
	GetZero(no2);

	for (int i = 0; i < 16; i++)
	{
	//	AddOne(no1);
	}

	for (int i = 0; i < 8; i++)
	{
	//	AddOne(no2);
	}

	no1[0] = 8;
	no2[0] = 4;

	Sub(no2, no1, no3);

	return 0;
}

void GetZero(uint8_t no[])
{
	for (int i = 0; i < noBytes; i++) no[i] = 0;
}

void AddOne(uint8_t no[])
{
	AddOneAt(no, coBytes, 0);
}

void AddOneAt(uint8_t no[], int itemIndex, int bitIndex)
{
	uint8_t carry = 1;

	for (int i = itemIndex; i < noBytes; i++)
	{
		for (int j = bitIndex; j < siBits; j++)
		{
			uint8_t isBitSet = IsBitSet(no[i], j);
			uint8_t addBit = (isBitSet + carry) % 2;

			SetBit(no, i, j, addBit);

			if ((isBitSet + carry) < 2)	return;
		}
	}
}

void Copy(uint8_t no[], uint8_t copy[])
{
	for (int i = 0; i < noBytes; i++) copy[i] = no[i];
}

void Add(uint8_t no1[], uint8_t no2[], uint8_t result[])
{
	GetZero(result);

	uint8_t carry = 0;

	for (int i = 0; i < noBytes; i++)
	{
		for (int j = 0; j < siBits; j++)
		{
			uint8_t addBit = (IsBitSet(no1[i], j) + IsBitSet(no2[i], j) + carry) % 2;

			result[i] = result[i] | (addBit << j);
			carry = (IsBitSet(no1[i], j) + IsBitSet(no2[i], j) + carry) >= 2;
		}
	}
}

void AddTo1(uint8_t no1[], uint8_t no2[])
{
	uint8_t tmp[noBytes];

	Add(no1, no2, tmp);
	Copy(tmp, no1);
}

void Sub(uint8_t no1[], uint8_t no2[], uint8_t result[])
{
	GetZero(result);

	uint8_t carry = 0;

	for (int i = 0; i < noBytes; i++)
	{
		for (int j = 0; j < siBits; j++)
		{
			uint8_t subBit = (2 + IsBitSet(no1[i], j) - IsBitSet(no2[i], j) - carry) % 2;

			result[i] = result[i] | (subBit << j);
			carry = (2 + IsBitSet(no1[i], j) - IsBitSet(no2[i], j) - carry) < 2;
		}
	}

	if (carry) GetZero(result);
}

void SubTo1(uint8_t no1[], uint8_t no2[])
{
	uint8_t tmp[noBytes];

	Sub(no1, no2, tmp);
	Copy(tmp, no1);
}

void Mul(uint8_t no1[], uint8_t no2[], uint8_t result[])
{
	GetZero(result);

	for (int i1 = 0; i1 < noBytes; i1++)
	{
		for (int j1 = 0; j1 < siBits; j1++)
		{
			MulWithBit(IsBitSet(no1[i1], j1), no2, result, i1 - coBytes, j1);
		}
	}
}

void MulWithBit(uint8_t isBitNo1Set, uint8_t no2[], uint8_t result[], int iR, int jR)
{
	for (int i2 = 0; i2 < noBytes; i2++)
	{
		for (int j2 = 0; j2 < siBits; j2++, jR++)
		{
			if (jR >= siBits)
			{
				iR++;
				jR = 0;
			}

			if (iR < 0)continue;
			if (iR > noBytes)return;

			if (isBitNo1Set*IsBitSet(no2[i2], j2))AddOneAt(result, iR, jR);
		}
	}
}

void Div(uint8_t no1[], uint8_t no2[], uint8_t result[])
{
	int iR = coBytes;
	int jR = 0;
	uint8_t currentDiv[noBytes];
	uint8_t comp[noBytes];
	uint8_t compTmp[noBytes];

	Copy(no2, currentDiv);
	GetZero(comp);
	GetZero(result);

	while (iR >= 0)
	{
		do
		{
			Add(comp, currentDiv, compTmp);

			int isHigher = IsHigher(no1, compTmp);

			if (isHigher < 0) break;

			Copy(compTmp, comp);
			AddOneAt(result, iR, jR);

			if (isHigher == 0) return;
		} while (true);

		jR--;

		if (jR <= 0)
		{
			jR = siBits - 1;
			iR--;
		}

		ShiftRight(currentDiv, 1);
	}
}

int IsHigher(uint8_t no1[], uint8_t no2[])
{
	for (int i = noBytes - 1; i >= 0; i--)
	{
		if (no1[i] > no2[i])return 1;
		if (no1[i] < no2[i])return -1;

		/*
		for (int j = siBits - 1; j >= 0; j--)
		{
			uint8_t bit1 = IsBitSet(no1[i], j);
			uint8_t bit2 = IsBitSet(no2[i], j);

			if (bit1 > bit2)return 1;
			if (bit1 < bit2)return -1;
		}									//			*/
	}

	return 0;
}

int IsHigherZero(uint8_t no[])
{
	for (int i = noBytes - 1; i >= 0; i--)
	{
		if (no[i] > 0)return 1;
	}

	return 0;
}

void Shift(uint8_t no[], int by)
{
	if (by > 0)ShiftLeft(no, by);
	if (by < 0)ShiftRight(no, by*-1);
}

void ShiftRight(uint8_t no[], int by)
{
	uint8_t carry = 0;

	for (int i = noBytes - 1; i >= 0; i--)
	{
		uint8_t tmp = no[i] << (siBits - by);

		no[i] = (no[i] >> by) | carry;
		carry = tmp;
	}
}

void ShiftLeft(uint8_t no[], int by)
{
	uint8_t carry = 0;

	for (int i = 0; i < noBytes; i++)
	{
		uint8_t tmp = no[i] >> (siBits - by);

		no[i] = (no[i] << by) | carry;
		carry = tmp;
	}
}

uint8_t IsBitSet(uint8_t item, uint8_t index)
{
	return (item & (1 << index)) > 0;
}

void SetBit(uint8_t no[], int arrayIndex, int bitIndex, uint8_t value)
{
	no[arrayIndex] = (no[arrayIndex] & (~(1 << bitIndex))) | (value << bitIndex);
}