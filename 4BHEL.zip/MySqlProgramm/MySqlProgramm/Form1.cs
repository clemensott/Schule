﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MySqlProgramm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSchuelerAnzeigen_Click(object sender, EventArgs e)
        {
            lblErgebnis.Text = Commend("SELECT schueler.nachname, schueler.vorname, abteilung.name FROM schueler, abteilung where schueler.abteilung_id = abteilung.id");
        }

        private string Commend(string commandText)
        {
            string ergebnis = "";
            string myConnectionString = "Server=localhost;" + "DATABASE=4BHEL;" + "UID=root;" + "PASSWORD=;";

            MySqlConnection connection = new MySqlConnection(myConnectionString);
            MySqlCommand command = connection.CreateCommand();

            command.CommandText = commandText;
            connection.Open();

            MySqlDataReader reader = command.ExecuteReader();

            lblErgebnis.Text = "";

            while (reader.Read())
            {
                for (int i = 0; i < reader.FieldCount; i++) ergebnis += reader.GetValue(i) + " | ";

                ergebnis = ergebnis.TrimEnd(' ', '|') + "\n";
            }

            connection.Close();

            return ergebnis;
        }
    }
}
