﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace VigenereVerschluesselungKnacken
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string encryptedText = "EYRYC FWLJH  FHSIU  BHMJO\r\nUCSEG TNEER  FLJLV  SXMVY\r\nSSTKC  MIKZS  JHZVB  FXMXK\r\nPMMVW OZSIA  FCRVF  TNERH\r\nMCGYS OVYVF  PNEVH  JAOVW\r\n\r\nUUYJU  FOISH  XOVUS  FMKRP\r\nTWLCI  FMWVZ TYOIS  UUIIS\r\nECIZV  ZVYVF  PCQUC HYRGO\r\nMUWKV BNXVB  YHHWI  FLMYF\r\nFNEVH  JAOVW JLYER  AYLER\r\n\r\nVEEKS  OCQD  OUXSS  LUQVB\r\nFMALF  EYHRT  VYVXS  TIVXH\r\nEUWJG JYARS  ILIER  JBVVF\r\nBLFVW  UHMTV UAIJH  PYVKK\r\nVLHVB  TCIUI  SZXVB  JBVVP\r\n\r\nVYVFG  BVIIO  VWLEW DBXMS\r\nSFRJG  FHFVJ  PLWZS  FCRVU\r\nFMXVZ  MNIRI  GAESS  HYPFS\r\nTNLRH  UYR\r\n";

        private char[] haufLangChar = new char[] { 'E', 'N' };
        private double[] haufLangPer = new double[] { 27 };

        private Tuple<char, double>[] GetHaufLang()
        {
            Tuple<char, double>[] haeufLang = new Tuple<char, double>[26];

            haeufLang[00] = new Tuple<char, double>('E', 27);
            haeufLang[01] = new Tuple<char, double>('E', 27);
            haeufLang[02] = new Tuple<char, double>('E', 27);
            haeufLang[03] = new Tuple<char, double>('E', 27);
            haeufLang[04] = new Tuple<char, double>('E', 27);
            haeufLang[05] = new Tuple<char, double>('E', 27);
            haeufLang[06] = new Tuple<char, double>('E', 27);
            haeufLang[07] = new Tuple<char, double>('E', 27);
            haeufLang[08] = new Tuple<char, double>('E', 27);
            haeufLang[09] = new Tuple<char, double>('E', 27);
            haeufLang[10] = new Tuple<char, double>('E', 27);
            haeufLang[11] = new Tuple<char, double>('E', 27);
            haeufLang[12] = new Tuple<char, double>('E', 27);
            haeufLang[13] = new Tuple<char, double>('E', 27);
            haeufLang[14] = new Tuple<char, double>('E', 27);
            haeufLang[15] = new Tuple<char, double>('E', 27);
            haeufLang[16] = new Tuple<char, double>('E', 27);
            haeufLang[17] = new Tuple<char, double>('E', 27);
            haeufLang[18] = new Tuple<char, double>('E', 27);
            haeufLang[19] = new Tuple<char, double>('E', 27);
            haeufLang[20] = new Tuple<char, double>('E', 27);
            haeufLang[21] = new Tuple<char, double>('E', 27);
            haeufLang[22] = new Tuple<char, double>('E', 27);
            haeufLang[23] = new Tuple<char, double>('E', 27);
            haeufLang[24] = new Tuple<char, double>('E', 27);
            haeufLang[25] = new Tuple<char, double>('E', 27);

            return haeufLang;
        }

        public MainWindow()
        {
            InitializeComponent();

            tbxVer.Text = encryptedText;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string text = tbxVer.Text.Replace(" ", "").Replace("\n", "").Replace("\t", "").Replace("\r", "");
            string textBackup = text;
            List<Tuple<int, int>> distances = new List<Tuple<int, int>>();

            for (int l = text.Length / 2; l > 2; l--)
            {
                for (int i = 0; i + 2 * l < text.Length; i++)
                {
                    string doublePart = text.Remove(0, i).Remove(l);

                    if (!doublePart.Contains(" "))
                    {
                        List<int> indexes = new List<int>();

                        indexes.Add(i);

                        for (int j = i + l; j + l < text.Length; j++)
                        {
                            string second = text.Remove(0, j).Remove(l);

                            if (second == doublePart) indexes.Add(j);
                        }

                        if (indexes.Count > 1)
                        {
                            int preIndex = indexes[0];

                            foreach (int index in indexes)
                            {
                                if (index != preIndex) distances.Add(new Tuple<int, int>(index - preIndex, l * l));
                            }

                            text = text.Replace(doublePart, GetSpaces(doublePart.Length));
                        }
                    }
                }
            }

            ShortDistancesList(ref distances);

            Tuple<int, int> probablyDistance = new Tuple<int, int>(1, 1);

            for (int i = 1; i < distances.Count - 1; i++)
            {
                if (GetPriority(i, distances) > distances[i + 1].Item2 * 10 || (i == distances.Count - 2))
                {
                    int priority = 0;

                    priority = distances.Where(x => distances.IndexOf(x) < i).Sum(x => x.Item2);
                    int ggt = GGT(distances.Where(x => distances.IndexOf(x) < i).Select(x => x.Item1));

                    probablyDistance = new Tuple<int, int>(ggt, priority);

                    break;
                }
            }

            int keyboardLength = probablyDistance.Item1;

            for (int i = 1; i < keyboardLength; i++)
            {
                if (keyboardLength % i == 0)
                {
                    TryEncrypt(textBackup, keyboardLength / i);
                }
            }
        }

        private int GetPriority(int count, List<Tuple<int, int>> list)
        {
            int priority = 0;

            for (int i = 0; i < count; i++) priority += list[i].Item2;

            return priority;
        }

        private string GetSpaces(int lenght)
        {
            string spaces = "";

            for (int i = 0; i < lenght; i++) spaces += " ";

            return spaces;
        }

        private void ShortDistancesList(ref List<Tuple<int, int>> distancens)
        {
            var ordered = distancens.OrderBy(x => x.Item1).ToList();
            List<Tuple<int, int>> shortList = new List<Tuple<int, int>>();

            shortList.Add(new Tuple<int, int>(ordered[0].Item1, 0));

            foreach (Tuple<int, int> distance in ordered)
            {
                int priority = shortList.Last().Item2 + distance.Item2;

                if (distance.Item1 == shortList.Last().Item1)
                {
                    shortList[shortList.Count - 1] = new Tuple<int, int>(distance.Item1, priority);
                }
                else shortList.Add(distance);
            }

            distancens = shortList.OrderBy(x => x.Item2 * -1).ToList();
        }

        private int GGT(IEnumerable<int> nums)
        {
            int ggt = nums.Min();

            foreach (int num in nums)
            {
                int oldGgt = ggt;

                if (num % ggt > 0) ggt = NewGGT(ggt, num);
                if (ggt == 1) break;
            }

            return ggt;
        }

        private int NewGGT(int ggt, int num)
        {
            for (int i = 2; i < ggt; i++)
            {
                if (ggt % i == 0 && num % (ggt / i) == 0) return ggt / i;
            }

            return 1;
        }

        private void TryEncrypt(string text, int keylenght)
        {
            List<List<Tuple<char, double>>> haeufText = new List<List<Tuple<char, double>>>();

            for (int i = 0; i < keylenght; i++)
            {
                haeufText.Add(GetHaeuf(text.Where(x => x % keylenght == i)));


            }
        }

        private List<Tuple<char, double>> GetHaeuf(IEnumerable<char> text)
        {
            List<Tuple<char, double>> haeufText = new List<Tuple<char, double>>();

            foreach (char c in text)
            {
                int index = haeufText.FindIndex(x => x.Item1 == c);

                if (index != -1) haeufText[index] = new Tuple<char, double>(c, haeufText[index].Item2 + 1);
                else haeufText.Add(new Tuple<char, double>(c, 1));
            }

            double textLenght = text.Count();

            for (int i = 0; i < haeufText.Count; i++)
            {
                haeufText[i] = new Tuple<char, double>(haeufText[i].Item1, haeufText[i].Item2 / textLenght);
            }

            return haeufText.OrderBy(x => x.Item2 * -1).ToList();
        }
    }
}
