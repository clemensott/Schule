﻿using System;
using System.Linq;
using System.Threading;
using Windows.Devices.Bluetooth.Rfcomm;
using Windows.Devices.Enumeration;
using Windows.Networking.Sockets;
using Windows.Storage.Streams;

namespace WerkstattProjektTestenUWA
{
    public class ConnectionManager
    {
        private static ConnectionManager current;

        public static ConnectionManager Current
        {
            get
            {
                if (current == null) current = new ConnectionManager();

                return current;
            }
        }

        private string getMessage;
        private Timer timer;
        private DataWriter writer;
        private DataReader reader;
        private StreamSocket socket;

        public delegate void MessageReceivedHandler(string message);

        public event MessageReceivedHandler MessageReceived;

        private ConnectionManager()
        {
            getMessage = "";
            //timer = new Timer(new TimerCallback(GetMessages), 0, 1000, 1000);

            RefreshBluetoothDevicesList();
        }

        private async void GetMessages(object obj)
        {
            if (reader == null) return;

            getMessage = "";

            try
            {
                while (true)
                {
                    await reader.LoadAsync(1);
                    byte b = reader.ReadByte();

                    if (b == 10 && getMessage != "")
                    {
                        MessageReceived?.Invoke(getMessage);

                        return;
                    }
                    else if (b != 10) getMessage += b;
                }
            }
            catch { }
        }

        public static void Create()
        {
            current = new ConnectionManager();
        }

        public async void RefreshBluetoothDevicesList()
        {
            try
            {
                var bluetoothDevices = await DeviceInformation.FindAllAsync(RfcommDeviceService.
                    GetDeviceSelector(RfcommServiceId.SerialPort));

                Connect(bluetoothDevices.ToList()[0]);
            }
            catch { }
        }

        public async void Connect(DeviceInformation bluetoothDevice)
        {
            try
            {
                socket = new StreamSocket();

                var serviceRfcomm = await RfcommDeviceService.FromIdAsync(bluetoothDevice.Id);

                await socket.ConnectAsync(serviceRfcomm.ConnectionHostName, serviceRfcomm.ConnectionServiceName,
                    SocketProtectionLevel.BluetoothEncryptionAllowNullAuthentication);

                writer = new DataWriter(socket.OutputStream);
                reader = new DataReader(socket.InputStream);
            }
            catch { }
        }

        public async void Send(byte[] array)
        {
            try
            {
                if (writer == null) return;

                writer.WriteBytes(array);
                await writer.StoreAsync();
            }
            catch { }
        }
    }
}
