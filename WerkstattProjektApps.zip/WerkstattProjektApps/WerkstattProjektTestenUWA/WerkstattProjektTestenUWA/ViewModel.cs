﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Networking.Proximity;

namespace WerkstattProjektTestenUWA
{
    public class ViewModel : INotifyPropertyChanged
    {
        private bool sendAuto;
        private byte bValue;
        
        public bool SendAuto
        {
            get { return sendAuto; }
            set
            {
                if (sendAuto == value) return;

                sendAuto = value;
                NotifyPropertyChanged("SendAuto");
            }
        }

        public double Value
        {
            get { return Convert.ToDouble(bValue); }
            set
            {
                if (Value == value) return;

                try
                {
                    bValue = Convert.ToByte(value);
                    NotifyPropertyChanged("Value");
                    NotifyPropertyChanged("ValueText");

                    if (sendAuto) ConnectionManager.Current.Send(new byte[] { bValue });
                }
                catch { }
            }
        }

        public string ValueText { get { return bValue.ToString(); } }

        public ViewModel()
        {
            bValue = 128;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(String propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
