﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Networking.Proximity;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// Die Vorlage "Leere Seite" ist unter http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409 dokumentiert.

namespace WerkstattProjektTestenUWA
{
    /// <summary>
    /// Eine leere Seite, die eigenständig verwendet oder zu der innerhalb eines Rahmens navigiert werden kann.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        private ViewModel viewModel;

        public MainPage()
        {
            this.InitializeComponent();

            viewModel = new ViewModel();
            DataContext = viewModel;

            ConnectionManager.Create();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {

        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void Plus_Click(object sender, RoutedEventArgs e)
        {
            viewModel.Value++;
        }

        private void Middle_Click(object sender, RoutedEventArgs e)
        {
            viewModel.Value = 128;
        }

        private void Minus_Click(object sender, RoutedEventArgs e)
        {
            viewModel.Value--;
        }

        private void Connect_Click(object sender, RoutedEventArgs e)
        {
            ConnectionManager.Current.RefreshBluetoothDevicesList();
        }

        private void Send_Click(object sender, RoutedEventArgs e)
        {
            ConnectionManager.Current.Send(new byte[] { Convert.ToByte(viewModel.Value) });
        }
    }
}
