﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using WerkstattProjektTesten.Resources;
using Windows.Networking.Proximity;

namespace WerkstattProjektTesten.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        private char sendValue;
        private int count, time;
        private List<PeerInformation> bluetoothDevices;

        public char SendChar
        {
            get { return sendValue; }
        }

        public string SendIntText
        {
            get { return Convert.ToInt32(sendValue).ToString(); }
            set
            {
                int intValue;

                if (value == "") value = "0";
                if (SendIntText == value || !int.TryParse(value, out intValue)) return;

                if (intValue >= 0 && intValue < 256) sendValue = Convert.ToChar(intValue);

                NotifyPropertyChanged("SendIntText");
                NotifyPropertyChanged("SendCharText");
                NotifyPropertyChanged("SendBitText");
            }
        }

        public string SendCharText
        {
            get { return sendValue.ToString(); }
        }

        public string SendBitText
        {
            get
            {
                int value = sendValue;
                string bits = "";

                for (int i = 0; i < 8; i++)
                {
                    bits = (value % 2).ToString() + bits;
                    value /= 2;
                }

                return bits;
            }
        }

        public int Count { get { return count; } }

        public int Time { get { return time; } }

        public string CountText
        {
            get { return count.ToString(); }
            set
            {
                int valueInt;

                if (!int.TryParse(value, out valueInt) && valueInt > 0) return;

                count = valueInt;
            }
        }

        public string TimeText
        {
            get { return time.ToString(); }
            set
            {
                int valueInt;

                if (!int.TryParse(value, out valueInt) && valueInt > 0) return;

                time = valueInt;
            }
        }

        public List<PeerInformation> BluetoothDevices
        {
            get { return bluetoothDevices; }
            set
            {
                if (bluetoothDevices == value) return;

                bluetoothDevices = value;

                NotifyPropertyChanged("BluetoothDevices");
            }
        }

        public MainViewModel()
        {
            bluetoothDevices = new List<PeerInformation>();
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged(String propertyName)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (null != handler)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}