﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Tasks;
using Windows.Networking.Proximity;
using System.Windows.Controls;
using System.Windows.Input;
using System.Threading.Tasks;

namespace WerkstattProjektTesten
{
    public partial class MainPage : PhoneApplicationPage
    {
        public ConnectionManager connectionManager;

        public static ConnectionManager instance { get; set; }

        public MainPage()
        {
            InitializeComponent();

            DataContext = App.ViewModel;

            connectionManager = new ConnectionManager();
            connectionManager.MessageReceived += connectionManager_MessageReceived;

            instance = connectionManager;
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            connectionManager.Initialize();
        }

        private void PhoneApplicationPage_Loaded(object sender, RoutedEventArgs e)
        {
            RefreshPairedDevicesList();
        }

        private async void RefreshPairedDevicesList()
        {
            try
            {
                PeerFinder.Start();
                PeerFinder.AlternateIdentities["Bluetooth:Paired"] = "";
                var peers = await PeerFinder.FindAllPeersAsync();

                if (peers.Count == 0) MessageBox.Show("Bluetooth ist deaktiviert");
                else App.ViewModel.BluetoothDevices = peers.ToList();
            }
            catch (Exception ex)
            {
                if ((uint)ex.HResult == 0x8007048F)
                {
                    var result = MessageBox.Show("Bluetooth off", "Bluetooth Off", MessageBoxButton.OKCancel);

                    if (result == MessageBoxResult.OK) ShowBluetoothcControlPanel();
                }
                else if ((uint)ex.HResult == 0x80070005) MessageBox.Show("missing caps");
                else MessageBox.Show(ex.Message);
            }
        }


        private void ShowBluetoothcControlPanel()
        {
            ConnectionSettingsTask connectionSettingsTask = new ConnectionSettingsTask();
            connectionSettingsTask.ConnectionSettingsType = ConnectionSettingsType.Bluetooth;
            connectionSettingsTask.Show();
        }

        private void connectionManager_MessageReceived(string message)
        {
            System.Diagnostics.Debug.WriteLine("Message received:" + message);
        }

        private async void TextBlock_Tap(object sender, GestureEventArgs e)
        {
            bool result = await connectionManager.Connect(((sender as TextBlock).DataContext as PeerInformation).HostName);
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            App.ViewModel.SendIntText = (sender as TextBox).Text;
        }

        private async void Send_Tap(object sender, GestureEventArgs e)
        {
            await connectionManager.SendCommand(App.ViewModel.SendChar.ToString());
        }

        private async void SendP_Tap(object sender, GestureEventArgs e)
        {
            for (int i = 0; i < App.ViewModel.Count; i++)
            {
                await Task.Delay(App.ViewModel.Time);
                await connectionManager.SendCommand(App.ViewModel.SendChar.ToString());
            }
        }
    }
}