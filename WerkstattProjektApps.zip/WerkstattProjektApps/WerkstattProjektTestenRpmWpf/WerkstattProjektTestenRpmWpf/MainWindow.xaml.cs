﻿using System.Collections.Generic;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Xml.Serialization;

namespace WerkstattProjektTestenRpmWpf
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<int> list;
        List<List<int>> listList;
        ViewModel viewModel;
        Timer timer;
        SerialPort serial;

        public MainWindow()
        {
            InitializeComponent();

            timer = new Timer(new TimerCallback(ReadSerial), 0, 100, 30);

            serial = new SerialPort();
            serial.BaudRate = 115200;
            serial.PortName = "COM7";
            
            serial.Open();

            viewModel = new ViewModel();
            DataContext = viewModel;

            list = new List<int>();
            listList = new List<List<int>>();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void ReadSerial(object obj)
        {
            try
            {
                while (serial.BytesToRead > 0) list.Add(serial.ReadByte());

                if (list.Count < 500) return;

                viewModel.SetData(list);

                list.Remove(0);
                listList.Add(list);

                list = new List<int>();
            }
            catch { }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            XmlSerializer seriallizer = new XmlSerializer(listList.GetType());

            StreamWriter sw = new StreamWriter("ListList.xml");
            seriallizer.Serialize(sw, listList);

            sw.Close();
        }
    }
}
