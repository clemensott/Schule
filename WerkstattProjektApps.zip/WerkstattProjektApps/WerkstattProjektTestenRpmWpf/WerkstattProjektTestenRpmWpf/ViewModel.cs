﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Media;

namespace WerkstattProjektTestenRpmWpf
{
    public class ViewModel : INotifyPropertyChanged
    {
        int micros;
        string data = "M 0 0";

        public string MicrosText { get { return "Micros: " + micros.ToString(); } }

        public Geometry PathData { get { return Geometry.Parse(data); } }

        public void SetData(List<int> list)
        {
            if (list.Count < 2) return;

            string newData = "M ";

            micros = list[0] * 1000;

            for (int i = 1; i < list.Count; i++)
            {
                newData += string.Format("{0} {1} ", (i * 1500 / list.Count).ToString().Replace(",", "."),
                    (500 - list[i] / 255.0 * 500).ToString().Replace(",", "."));
            }

            data = newData;

            int count = 0;

            for (int i = 1; i < list.Count; i++)
            {

            }

            NotifyPropertyChanged("Micros");
            NotifyPropertyChanged("PathData");
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(String propertyName)
        {
            if (null == PropertyChanged) return;

            PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
