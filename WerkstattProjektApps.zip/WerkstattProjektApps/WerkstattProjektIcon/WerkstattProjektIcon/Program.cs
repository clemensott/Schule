﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Imaging;

namespace WerkstattProjektIcon
{
    class Program
    {
        static void Main(string[] args)
        {
            Bitmap bmpOriginal = new Bitmap("Original.png");
            List<Size> sizes = new List<Size>();

            sizes.Add(new Size(284, 284));
            sizes.Add(new Size(142, 142));
            sizes.Add(new Size(71, 71));
            sizes.Add(new Size(107, 107));
            sizes.Add(new Size(89, 89));
            sizes.Add(new Size(600, 600));
            sizes.Add(new Size(300, 300));
            sizes.Add(new Size(150, 150));
            sizes.Add(new Size(225, 225));
            sizes.Add(new Size(188, 188));
            sizes.Add(new Size(1240, 600));
            sizes.Add(new Size(620, 300));
            sizes.Add(new Size(310, 150));
            sizes.Add(new Size(465, 225));
            sizes.Add(new Size(388, 188));
            sizes.Add(new Size(1240, 1240));
            sizes.Add(new Size(620, 620));
            sizes.Add(new Size(310, 310));
            sizes.Add(new Size(465, 465));
            sizes.Add(new Size(388, 388));
            sizes.Add(new Size(176, 176));
            sizes.Add(new Size(88, 88));
            sizes.Add(new Size(44, 44));
            sizes.Add(new Size(66, 66));
            sizes.Add(new Size(55, 55));
            sizes.Add(new Size(200, 200));
            sizes.Add(new Size(100, 100));
            sizes.Add(new Size(75, 75));
            sizes.Add(new Size(63, 63));
            sizes.Add(new Size(50, 50));
            sizes.Add(new Size(24, 24));
            sizes.Add(new Size(96, 96));
            sizes.Add(new Size(2480, 1200));
            sizes.Add(new Size(930, 450));
            sizes.Add(new Size(775, 375));
            sizes.Add(new Size(48, 48));
            sizes.Add(new Size(36, 36));
            sizes.Add(new Size(30, 30));
            sizes.Add(new Size(24, 24));

            foreach (Size size in sizes)
            {
                using (Bitmap bmp = new Bitmap(size.Width, size.Height))
                {
                    string filename = string.Format("WerkstattProjektIcon {0}x{1}.png", size.Width, size.Height);
                    Rectangle iconRect = new Rectangle();
                    Graphics g = Graphics.FromImage(bmp);

                    if (bmpOriginal.Width * size.Height > bmpOriginal.Height * size.Width)
                    {
                        iconRect.Width = size.Width;
                        iconRect.Height = Convert.ToInt32(bmpOriginal.Height * size.Width / Convert.ToDouble(bmpOriginal.Width));
                        iconRect.X = 0;
                        iconRect.Y = Convert.ToInt32((size.Height - iconRect.Height) / 2.0);
                    }
                    else
                    {
                        iconRect.Width = Convert.ToInt32(bmpOriginal.Width * size.Height / Convert.ToDouble(bmpOriginal.Height));
                        iconRect.Height = size.Height;
                        iconRect.X = Convert.ToInt32((size.Width - iconRect.Width) / 2.0);
                        iconRect.Y = 0;
                    }

                    g.DrawImage(bmpOriginal, iconRect);

                    bmp.Save(filename, System.Drawing.Imaging.ImageFormat.Png);
                }
            }
        }
    }
}
