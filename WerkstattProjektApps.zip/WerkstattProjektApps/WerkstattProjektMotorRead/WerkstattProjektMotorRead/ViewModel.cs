﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Serialization;
using Windows.Storage;
using Windows.UI.Core;
using Windows.UI.Xaml.Markup;
using Windows.UI.Xaml.Media;

namespace WerkstattProjektMotorRead
{
    public class ViewModel : INotifyPropertyChanged
    {
        private const double height = 500, deltaXDefault = 1;

        private int listIndex;
        private double deltaXSlider = 1;
        private List<List<int>> listList;

        public double DeltaXSlider
        {
            get { return deltaXSlider; }
            set
            {
                if (deltaXSlider == value) return;

                deltaXSlider = value;
                NotifyPropertyChanged("PathData");
                NotifyPropertyChanged("PathDataInt");
            }
        }

        public int ListIndex
        {
            get { return listIndex; }
            set
            {
                if (listIndex == value || listList.Count <= value) return;

                listIndex = value;
                NotifyPropertyChanged("ListIndex");
                NotifyPropertyChanged("PathData");
                NotifyPropertyChanged("MinVoltage");
                NotifyPropertyChanged("MaxVoltage");
                NotifyPropertyChanged("AveVoltage");
                NotifyPropertyChanged("BetVoltage");
            }
        }

        public string MinVoltage
        {
            get { return listList.Count == 0 ? "Min: 0" : "Min:" + listList[listIndex].Min().ToString(); }
        }

        public string MaxVoltage
        {
            get { return listList.Count == 0 ? "Max: 0" : "Max:" + listList[listIndex].Max().ToString(); }
        }

        public string AveVoltage
        {
            get
            {
                return listList.Count == 0 ? "Ave: 0" : 
                    "Ave:" + (listList[listIndex].Sum() / Convert.ToDouble(listList[listIndex].Count)).ToString();
            }
        }

        public string BetVoltage
        {
            get
            {
                return listList.Count == 0 ? "Bet: 0" :
                  "Bet:" + ((listList[listIndex].Max() + listList[listIndex].Min()) / 2.0).ToString();
            }
        }

        public Geometry PathData
        {
            get { return GetGeometry(listList, listIndex, GetDeltaX()); }
        }

        public ViewModel()
        {
            listList = new List<List<int>>();
            listIndex = -1;

            Refresh();
        }

        public async Task Refresh()
        {
            try
            {
                StorageFile file = await StorageFile.GetFileFromApplicationUriAsync(new Uri(@"ms-appx:///ListList.xml"));
                var input = await FileIO.ReadTextAsync(file);

                XmlSerializer serializer = new XmlSerializer(typeof(List<List<int>>));
                TextReader reader= new StringReader(input);

                object obj = serializer.Deserialize(reader);
                List<List<int>> listList = obj as List<List<int>>;

                for (int i = listList.Count - 1; i >= 0; i--)
                {
                    if (listList[i].Count == 0) listList.RemoveAt(i);
                    else
                    {
                        listList[i].RemoveAt(0);

                        if (listList[i].Max() == 0) listList.RemoveAt(i);
                        else
                        {
                            System.Diagnostics.Debug.WriteLine("Min: " + listList[i].Min());
                            System.Diagnostics.Debug.WriteLine("Max: " + listList[i].Max());
                            System.Diagnostics.Debug.WriteLine("Ave: " + listList[i].Sum() / listList.Count);
                        }
                    }
                }

                this.listList = listList;
                if (listList.Count > 0) listIndex = 0;

                NotifyPropertyChanged("Minimum");
                NotifyPropertyChanged("Maximum");
                NotifyPropertyChanged("ListIndex");
                NotifyPropertyChanged("DeltaXSlider");
                NotifyPropertyChanged("PathData");
                NotifyPropertyChanged("MinVoltage");
                NotifyPropertyChanged("MaxVoltage");
                NotifyPropertyChanged("AveVoltage");
                NotifyPropertyChanged("BetVoltage");
            }
            catch { }
        }

        private double GetDeltaX()
        {
            return deltaXSlider / 19.5;
        }

        private Geometry GetGeometry(List<List<int>> listList, int listIndex, double deltaX)
        {
            if (listList.Count == 0) return new PathGeometry();

            string data = "M ";

            for (int i = 1; i < listList[listIndex].Count; i++)
            {
                data += string.Format("{0} {1} ", (i * deltaX).ToString().Replace(",", "."),
                    (height - listList[listIndex][i] / 255.0 * height).ToString().Replace(",", "."));
            }

            return GetGeometry(data);
        }

        private Geometry GetGeometry(string data)
        {
            try
            {
                data = "<Geometry xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'>" + data;
                data += "</Geometry>";

                return (Geometry)XamlReader.Load(data);
            }
            catch { }

            return new PathGeometry();
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private async void NotifyPropertyChanged(String propertyName)
        {
            try
            {
                if (null == PropertyChanged) return;

                await Windows.ApplicationModel.Core.CoreApplication.MainView.
                    CoreWindow.Dispatcher.RunAsync(CoreDispatcherPriority.Normal,
                    () => { PropertyChanged(this, new PropertyChangedEventArgs(propertyName)); });
            }
            catch { }
        }
    }
}
