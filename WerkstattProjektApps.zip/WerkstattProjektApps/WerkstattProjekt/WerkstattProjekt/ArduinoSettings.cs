﻿using System;
using System.ComponentModel;
using System.IO;
using System.Xml.Serialization;
using Windows.UI.Core;

namespace WerkstattProjekt
{
    public class ArduinoSettings : INotifyPropertyChanged
    {
        private static string filename = "ArduinoSettings.xml";

        private const int reglerAmplitudeMax = 15, reglerOffsetMax = 127, reglerCurveMax = 63;
        private const int servoAmplitudeMax = 15, servoOffsetMax = 127, servoCurveMax = 63;
        private const int frontBrightnessMax = 7, upBrightnessMax = 7, backBrightnessMax = 7;

        private byte reglerAmplitude, reglerOffset, reglerCurve;
        private byte servoAmplitude, servoOffset, servoCurve;
        private byte frontBrightness, upBrightness, backBrightness;

        private bool useRemotetWithoutBluetooth, doBlink, useApp;

        public bool UseApp
        {
            get { return useApp; }
            set
            {
                if (useApp == value) return;

                useApp = value;
                NotifyPropertyChanged("UseApp");
                NotifyPropertyChanged("JustRemoteIsEnabled");

                NotifyPropertyChanged("ReglerRemoteIsChecked");
                NotifyPropertyChanged("ReglerOffsetAndCurveSliderIsEnabled");
                NotifyPropertyChanged("ReglerGraphVisibility");

                NotifyPropertyChanged("ServoRemoteIsChecked");
                NotifyPropertyChanged("ServoOffsetAndCurveSliderIsEnabled");
                NotifyPropertyChanged("ServoGraphVisibility");
            }
        }

        public bool UseRemotetWithoutBluetooth
        {
            get { return useRemotetWithoutBluetooth; }
            set
            {
                if (useRemotetWithoutBluetooth == value) return;

                useRemotetWithoutBluetooth = value;
                NotifyPropertyChanged("useRemotetWithoutBluetooth");
            }
        }

        public bool DoBlink
        {
            get { return doBlink; }
            set
            {
                if (doBlink == value) return;

                doBlink = value;
                NotifyPropertyChanged("DoBlink");
            }
        }

        public byte ReglerAmplitude
        {
            get { return reglerAmplitude; }
            set
            {
                if (reglerAmplitude == value) return;
                if (reglerAmplitudeMax < value) value = reglerAmplitudeMax;

                reglerAmplitude = value;
                NotifyPropertyChanged("ReglerAmplitude");
            }
        }

        public byte ReglerOffset
        {
            get { return reglerOffset; }
            set
            {
                if (reglerOffset == value) return;
                if (reglerOffsetMax < value) value = reglerOffsetMax;

                reglerOffset = value;
                NotifyPropertyChanged("ReglerOffset");
            }
        }

        public byte ReglerCurve
        {
            get { return reglerCurve; }
            set
            {
                if (reglerCurve == value) return;
                if (reglerCurveMax < value) value = reglerCurveMax;

                reglerCurve = value;
                NotifyPropertyChanged("ReglerCurve");
            }
        }

        public byte ServoAmplitude
        {
            get { return servoAmplitude; }
            set
            {
                if (servoAmplitude == value) return;
                if (servoAmplitudeMax < value) value = servoAmplitudeMax;

                servoAmplitude = value;
                NotifyPropertyChanged("ServoAmplitude");
            }
        }

        public byte ServoOffset
        {
            get { return servoOffset; }
            set
            {
                if (servoOffset == value) return;
                if (servoOffsetMax < value) value = servoOffsetMax;

                servoOffset = value;
                NotifyPropertyChanged("ServoOffset");
            }
        }

        public byte ServoCurve
        {
            get { return servoCurve; }
            set
            {
                if (servoCurve == value) return;
                if (servoCurveMax < value) value = servoCurveMax;

                servoCurve = value;
                NotifyPropertyChanged("ServoCurve");
            }
        }

        public byte FrontBrightness
        {
            get { return frontBrightness; }
            set
            {
                if (frontBrightness == value) return;
                if (frontBrightnessMax < value) value = frontBrightnessMax;

                frontBrightness = value;
                NotifyPropertyChanged("FrontBrightness");
            }
        }

        public byte UpBrightness
        {
            get { return upBrightness; }
            set
            {
                if (upBrightness == value) return;
                if (upBrightnessMax < value) value = upBrightnessMax;

                upBrightness = value;
                NotifyPropertyChanged("UpBrightness");
            }
        }

        public byte BackBrightness
        {
            get { return backBrightness; }
            set
            {
                if (backBrightness == value) return;
                if (backBrightnessMax < value) value = backBrightnessMax;

                backBrightness = value;
                NotifyPropertyChanged("BackBrightness");
            }
        }

        public ArduinoSettings()
        {
            useRemotetWithoutBluetooth = true;
            doBlink = true;

            reglerCurve = 31;
            reglerOffset = 63;

            servoCurve = 31;
            servoOffset = 63;

            frontBrightness = 0;
            upBrightness = 0;
            backBrightness = 0;
        }

        public async void Save()
        {
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(ArduinoSettings));

                TextWriter tw = new StringWriter();
                serializer.Serialize(tw, GetType() == typeof(ArduinoSettings) ? this : Clone());
                string xmlText = tw.ToString();

                TextReader tr = new StringReader(xmlText);
                object deObj = serializer.Deserialize(tr);

                await TextIO.Save(xmlText, filename);
            }
            catch { }
        }

        public ArduinoSettings Clone()
        {
            ArduinoSettings clone = new ArduinoSettings();

            clone.doBlink = doBlink;
            clone.useRemotetWithoutBluetooth = useRemotetWithoutBluetooth;
            clone.useApp = useApp;

            clone.reglerAmplitude = reglerAmplitude;
            clone.reglerOffset = reglerOffset;
            clone.reglerCurve = reglerCurve;

            clone.servoAmplitude = servoAmplitude;
            clone.servoOffset = servoOffset;
            clone.servoCurve = servoCurve;

            clone.frontBrightness = frontBrightness;
            clone.upBrightness = upBrightness;
            clone.backBrightness = backBrightness;

            return clone;
        }

        public async static void Load()
        {
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(ArduinoSettings));
                string xmlText = await TextIO.Load(filename);

                TextReader tr = new StringReader(xmlText);
                object deObj = serializer.Deserialize(tr);

                Arduino.Current.Settings = deObj as ArduinoSettings;
            }
            catch { }
        }

        public void SendToArduino()
        {
            byte b1, b2, b3, b4, b5, b6;
            long byteArray = 0;

            byteArray = GetByteArrayWithAddedData(byteArray, 3, 2);
            byteArray = GetByteArrayWithAddedData(byteArray, useRemotetWithoutBluetooth);
            byteArray = GetByteArrayWithAddedData(byteArray, doBlink);
            byteArray = GetByteArrayWithAddedData(byteArray, frontBrightness, 3);
            byteArray = GetByteArrayWithAddedData(byteArray, upBrightness, 3);
            byteArray = GetByteArrayWithAddedData(byteArray, backBrightness, 3);
            byteArray = GetByteArrayWithAddedData(byteArray, useApp);
            byteArray = GetByteArrayWithAddedData(byteArray, ServoAmplitude, 4);
            byteArray = GetByteArrayWithAddedData(byteArray, servoOffset, 7);
            byteArray = GetByteArrayWithAddedData(byteArray, servoCurve, 6);
            byteArray = GetByteArrayWithAddedData(byteArray, ReglerAmplitude, 4);
            byteArray = GetByteArrayWithAddedData(byteArray, reglerOffset, 7);
            byteArray = GetByteArrayWithAddedData(byteArray, reglerCurve, 6);

            b1 = Convert.ToByte((byteArray >> 40) % 256);
            b2 = Convert.ToByte((byteArray >> 32) % 256);
            b3 = Convert.ToByte((byteArray >> 24) % 256);
            b4 = Convert.ToByte((byteArray >> 16) % 256);
            b5 = Convert.ToByte((byteArray >> 8) % 256);
            b6 = Convert.ToByte((byteArray) % 256);

            ConnectionManager.Current.Send(b1, b2, b3, b4, b5, b6);
        }

        private long GetByteArrayWithAddedData(long array, bool data)
        {
            return GetByteArrayWithAddedData(array, Convert.ToInt32(data), 1);
        }

        private long GetByteArrayWithAddedData(long array, int data, int dataLength)
        {
            return (array << dataLength) + data;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected async void NotifyPropertyChanged(string propertyName)
        {
            if (null == PropertyChanged) return;

            try
            {
                await Windows.ApplicationModel.Core.CoreApplication.MainView.
                    CoreWindow.Dispatcher.RunAsync(CoreDispatcherPriority.Normal,
                    () => { PropertyChanged(this, new PropertyChangedEventArgs(propertyName)); });
            }
            catch { }
        }
    }
}
