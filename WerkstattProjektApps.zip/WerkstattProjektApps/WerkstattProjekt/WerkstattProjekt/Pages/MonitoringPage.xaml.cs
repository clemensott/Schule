﻿using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;

// Die Elementvorlage "Leere Seite" ist unter http://go.microsoft.com/fwlink/?LinkId=234238 dokumentiert.

namespace WerkstattProjekt
{
    /// <summary>
    /// Eine leere Seite, die eigenständig verwendet oder zu der innerhalb eines Rahmens navigiert werden kann.
    /// </summary>
    public sealed partial class MonitoringPage : Page
    {
        public MonitoringPage()
        {
            this.InitializeComponent();
            this.NavigationCacheMode = NavigationCacheMode.Disabled;

            DataContext = ViewModel.Current;
            PageManager.Current.SetCurrentPage(this);
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            var statusBar = StatusBar.GetForCurrentView();
            statusBar.HideAsync();

            if (Arduino.Current.Settings.UseApp) Frame.Navigate(typeof(MainPage));
            if (!ConnectionManager.Current.IsConnected) ConnectionManager.Current.RefreshBluetoothDevicesList();
        }

        private void gRPM_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            Grid grid = sender as Grid;

            ViewModel.Current.SetRpmGridWidthAndHeight(grid.ActualWidth, grid.ActualHeight - 100);
        }

        private void gBattery_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            Grid grid = sender as Grid;

            ViewModel.Current.SetBatteryGridWidthAndHeight(grid.ActualWidth, grid.ActualHeight);
        }

        private void Settings_Click(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(SettingsPage));
        }
    }
}
