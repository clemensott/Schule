﻿using Windows.Gaming.Input;
using Windows.System;
using Windows.UI.Core;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Navigation;

// Die Vorlage "Leere Seite" ist unter http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409 dokumentiert.

namespace WerkstattProjekt
{
    /// <summary>
    /// Eine leere Seite, die eigenständig verwendet oder zu der innerhalb eines Rahmens navigiert werden kann.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
            this.NavigationCacheMode = NavigationCacheMode.Disabled;

            DataContext = ViewModel.Current;
            PageManager.Current.SetCurrentPage(this);

            Window.Current.CoreWindow.KeyDown += CoreWindow_KeyDown;
            Window.Current.CoreWindow.KeyUp += CoreWindow_KeyUp;
        }

        private void CoreWindow_KeyUp(CoreWindow sender, KeyEventArgs args)
        {
            if (args.VirtualKey == VirtualKey.Up || args.VirtualKey == VirtualKey.Down) Steering.Current.SetRValue(63.5);
            else if (args.VirtualKey == VirtualKey.Right || args.VirtualKey == VirtualKey.Left) Steering.Current.SetSValue(63.5);

            else if (args.VirtualKey == VirtualKey.GamepadLeftThumbstickLeft || args.VirtualKey ==
                VirtualKey.GamepadLeftThumbstickRight
                || args.VirtualKey == VirtualKey.GamepadLeftThumbstickDown || args.VirtualKey == VirtualKey.GamepadLeftThumbstickUp)
            {
                try
                {
                    var val = Gamepad.Gamepads[Gamepad.Gamepads.Count - 1].GetCurrentReading();

                    Steering.Current.SetSValue((val.LeftThumbstickX + 1) * 63.5);
                }
                catch { }
            }
            else if (args.VirtualKey == VirtualKey.GamepadLeftTrigger || args.VirtualKey == VirtualKey.GamepadRightTrigger)
            {
                try
                {
                    var val = Gamepad.Gamepads[Gamepad.Gamepads.Count - 1].GetCurrentReading();

                    Steering.Current.SetRValue((val.RightTrigger - val.LeftTrigger + 1) * 63.5);
                }
                catch { }
            }
            else if (args.VirtualKey == VirtualKey.S) Frame.Navigate(typeof(SettingsPage));
        }

        private void CoreWindow_KeyDown(CoreWindow sender, KeyEventArgs args)
        {
            if (args.VirtualKey == VirtualKey.Up) Steering.Current.SetRValue(127);
            else if (args.VirtualKey == VirtualKey.Down) Steering.Current.SetRValue(0);
            else if (args.VirtualKey == VirtualKey.Right) Steering.Current.SetSValue(127);
            else if (args.VirtualKey == VirtualKey.Left) Steering.Current.SetSValue(0);

            else if (args.VirtualKey == VirtualKey.GamepadLeftThumbstickLeft || 
                args.VirtualKey == VirtualKey.GamepadLeftThumbstickRight || 
                args.VirtualKey == VirtualKey.GamepadLeftThumbstickDown || 
                args.VirtualKey == VirtualKey.GamepadLeftThumbstickUp)
            {
                try
                {
                    var val = Gamepad.Gamepads[Gamepad.Gamepads.Count - 1].GetCurrentReading();

                    Steering.Current.SetSValue((val.LeftThumbstickX + 1) * 63.5);
                }
                catch { }
            }
            else if (args.VirtualKey == VirtualKey.GamepadLeftTrigger||args.VirtualKey== VirtualKey.GamepadRightTrigger)
            {
                try
                {
                    var val = Gamepad.Gamepads[Gamepad.Gamepads.Count - 1].GetCurrentReading();

                    Steering.Current.SetRValue((val.RightTrigger - val.LeftTrigger + 1) * 63.5);
                }
                catch { }
            }
        }


        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            ConnectionManager.Current.ChangeDrive(false);
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            var statusBar = StatusBar.GetForCurrentView();
            statusBar.HideAsync();

            if (!Arduino.Current.Settings.UseApp) Frame.Navigate(typeof(MonitoringPage));
            else
            {
                Steering.Current.SetLinesAndPageEvents(this, gRegler, gServo);

                EnterSettings.Current.SetPageEvents(this);

                ConnectionManager.Current.ChangeDrive(true);
            }

            if (!ConnectionManager.Current.IsConnected) ConnectionManager.Current.RefreshBluetoothDevicesList();
        }

        private void gServoArrow_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            lServoArrow.Y2 = (sender as Grid).ActualHeight - 60;
        }

        private void gReglerArrow_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            lReglerArrow.X2 = (sender as Grid).ActualWidth - 60;
        }
    }
}
