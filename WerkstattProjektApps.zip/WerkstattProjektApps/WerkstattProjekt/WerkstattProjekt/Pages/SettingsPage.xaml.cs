﻿using Windows.Foundation;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;

namespace WerkstattProjekt
{
    public sealed partial class SettingsPage : Page
    {
        private const double coordinationSystemThickness = 2;

        public SettingsPage()
        {
            this.InitializeComponent();
            this.NavigationCacheMode = NavigationCacheMode.Disabled;

            PageManager.Current.SetCurrentPage(this);
            DataContext = ViewModel.Current;
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {

        }
        
        private Point GetPoint(int i)
        {
            double x = i;
            double y = i * i / 100;

            return new Point(x, y);
        }

        private void GRegler_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            Grid grid = sender as Grid;

            lReglerX.X1 = lReglerY.Y1 = 0;
            lReglerX.Y1 = lReglerX.Y2 = lReglerY.X1 = lReglerY.X2 = coordinationSystemThickness / 2.0;
            lReglerX.StrokeThickness = lReglerY.StrokeThickness = coordinationSystemThickness;

            lReglerX.X2 = lReglerY.Y2 = grid.ActualWidth;

            ViewModel.Current.ArduinoSettingsViewModel.ReglerCoordinateSystemSize = grid.ActualWidth;
        }

        private void GServo_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            Grid grid = sender as Grid;

            lServoX.X1 = lServoY.Y1 = 0;
            lServoX.Y1 = lServoX.Y2 = lServoY.X1 = lServoY.X2 = coordinationSystemThickness / 2.0;
            lServoX.StrokeThickness = lServoY.StrokeThickness = coordinationSystemThickness;

            lServoX.X2 = lServoY.Y2 = grid.ActualWidth;

            ViewModel.Current.ArduinoSettingsViewModel.ServoCoordinateSystemSize = grid.ActualWidth;
        }

        private async void Ok_Click(object sender, RoutedEventArgs e)
        {
            Arduino.Current.Settings = ArduinoSettingsViewModel.Current;

            await PageManager.Current.GoBack();
        }

        private async void Cancel_Click(object sender, RoutedEventArgs e)
        {
            await PageManager.Current.GoBack();
        }

        private async void BluetoothDevice_Click(object sender, RoutedEventArgs e)
        {
            await PageManager.Current.Navigate(typeof(BluetoothPage));
            ConnectionManager.Current.RefreshBluetoothDevicesList();
        }

        private void Help_Tapped(object sender, Windows.UI.Xaml.Input.TappedRoutedEventArgs e)
        {
            Frame.Navigate(typeof(HelpPage));
        }
    }
}
