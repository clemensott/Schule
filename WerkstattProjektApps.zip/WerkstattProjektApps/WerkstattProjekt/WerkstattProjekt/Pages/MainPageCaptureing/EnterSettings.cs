﻿using System;
using System.Collections.Generic;
using System.Linq;
using Windows.Foundation;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Input;

namespace WerkstattProjekt
{
    public class EnterSettings
    {
        enum Position {Left, Middle, Right };

        private const long ticksMax = 30000000;
        private const double goBackMax = 5, deltaHeightMax = 150;
        private static EnterSettings current;

        public static EnterSettings Current
        {
            get
            {
                if (current == null) current = new EnterSettings();

                return current;
            }
        }

        private int currentFails;
        private long startTicks;
        private List<Point> points;

        private EnterSettings()
        {
            points = new List<Point>();
        }

        public void SetPageEvents(Page page)
        {
            page.PointerPressed += Page_PointerPressed;
            page.PointerMoved += Page_PointerMoved;
            page.PointerReleased += Page_PointerReleased;
        }

        public void ResetPointers()
        {
            points = new List<Point>();
            currentFails = 0;
        }

        private void Page_PointerPressed(object sender, PointerRoutedEventArgs e)
        {
            Page p = sender as Page;
            
            if (points.Count == 0 && currentFails == 0)
            {
                Point startPoint = e.GetCurrentPoint(p).Position;

                if (GetPosition(startPoint.X, p) == Position.Middle) return;

                points = new List<Point>();
                points.Add(startPoint);
                startTicks = DateTime.Now.Ticks;
                return;
            }
            else if (points.Count != 0) currentFails++;

            currentFails++;
            points = new List<Point>();
        }

        private void Page_PointerMoved(object sender, PointerRoutedEventArgs e)
        {
            if (currentFails > 0 || points.Count == 0) return;

            points.Add(e.GetCurrentPoint(sender as Page).Position);
        }

        private async void Page_PointerReleased(object sender, PointerRoutedEventArgs e)
        {
            long deltaTicks = DateTime.Now.Ticks - startTicks;
            List<Point> points = this.points;
            this.points = new List<Point>();

            if (currentFails-- > 0) return;

            currentFails++;

            if (points.Count < 3) return;
            //if (deltaTicks > ticksMax) return;

            List<double> yValues = points.Select(x => x.Y).ToList();

            if (yValues.Max() - yValues.Min() > deltaHeightMax) return;

            List<double> xValues = points.Select(x => x.X).ToList();

            Page page = (sender as Page);
            bool leftStart = GetPosition(xValues[0], page) == Position.Left, turned = false;
            double xMax = leftStart ? 0 : page.ActualWidth, xEnd = leftStart ? xValues.Max() : xValues.Min();

            if ((GetPosition(xEnd, page) != Position.Right && leftStart) || (GetPosition(xEnd, page) != Position.Left && !leftStart)) return;
            if ((GetPosition(xValues[xValues.Count - 1], page) == Position.Right && leftStart) ||
                (GetPosition(xValues[xValues.Count - 1], page) == Position.Left && !leftStart)) return;

            foreach (double x in xValues)
            {
                xMax = GetMax(turned ? !leftStart : leftStart, x, xMax);

                if (x == xEnd) turned = true;
                if (Math.Abs(x - xMax) > goBackMax) return;
            }

            await PageManager.Current.Navigate(typeof(SettingsPage));
            ConnectionManager.Current.SendBrake();
        }

        private double GetMax(bool leftStart, double currentValue, double currentMax)
        {
            return currentMax < currentValue && leftStart || currentMax > currentValue && !leftStart ? currentValue : currentMax;
        }

        private Position GetPosition(double x, Page page)
        {
            if (x < page.ActualWidth / 3.0) return Position.Left;

            return x > page.ActualWidth * 2 / 3.0 ? Position.Right : Position.Middle;
        }
    }
}
