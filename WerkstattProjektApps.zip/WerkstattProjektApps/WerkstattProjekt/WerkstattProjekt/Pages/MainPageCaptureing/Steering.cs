﻿using System;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.System.Profile;
using Windows.UI.Input;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Input;

namespace WerkstattProjekt
{
    public class Steering
    {
        private const double borderLineThickness = 4, vibrationStart = -10, defaultValue = 63.5;
        private static Steering current;

        public static Steering Current
        {
            get
            {
                if (current == null) current = new Steering();

                return current;
            }
        }


        private volatile bool doReglerVibrate, doServoVibrate;
        private Windows.Phone.Devices.Notification.VibrationDevice vibrator;

        private Grid gRegler, gServo;

        private bool reglerIsPressedMouse, reglerIsPressedManuel, servoIsPressedMouse, servoIsPressedManuel;
        private uint rId, sId;
        private volatile byte[] driveData;
        private double rValue = defaultValue, sValue = defaultValue;
        private Point reglerOrigin, servoOrigin;

        public byte[] DriveData { get { return driveData; } }

        private Steering()
        {
            if ("Windows.Mobile" == AnalyticsInfo.VersionInfo.DeviceFamily)
            {
                vibrator = Windows.Phone.Devices.Notification.VibrationDevice.GetDefault();
            }

            driveData = new byte[2];

            UpdateDriveDataWithReglerValue(rValue);
            UpdateDriveDataWithServoValue(sValue);
        }

        private void UpdateDriveDataWithReglerValue(double reglerValue)
        {
            rValue = GetDoubleMinOne(reglerValue);

            driveData[1] = DoubleToByte(((Convert.ToInt32(sValue) & 1) << 7) + rValue);
        }

        private void UpdateDriveDataWithServoValue(double servoValue)
        {
            sValue = GetDoubleMinOne(servoValue);

            driveData[0] = DoubleToByte(Convert.ToInt32(sValue) >> 1);

            UpdateDriveDataWithReglerValue(rValue);
        }

        private double GetDoubleMinOne(double value)
        {
            return value < 1 ? 1 : value;
        }

        private byte DoubleToByte(double value)
        {
            if (value < 0) return 0;
            else if (value > 255) return 255;

            return Convert.ToByte(value);
        }

        public void SetLinesAndPageEvents(Page page, Grid gRegler, Grid gServo)
        {
            page.PointerPressed += Page_PointerPressed;
            page.PointerMoved += Page_PointerMoved;
            page.PointerReleased += Page_PointerReleasedOrExited;
            page.PointerExited += Page_PointerReleasedOrExited;

            this.gRegler = gRegler;
            this.gServo = gServo;

            gRegler.SizeChanged += GRegler_SizeChanged;
            gServo.SizeChanged += GServo_SizeChanged;

            ViewModel.Current.UpdateReglerSteeringAll();
            ViewModel.Current.UpdateServoSteeringAll();
        }

        public void ResetPointers()
        {
            if (reglerIsPressedMouse) SetReglerDefault();
            if (servoIsPressedMouse) SetServoDefault();

            SetRValue(defaultValue);
            SetSValue(defaultValue);
        }

        private void Page_PointerPressed(object sender, PointerRoutedEventArgs e)
        {
            if (IsRegler(e)) return;
            else if (IsServo(e)) return;
        }

        private bool IsRegler(PointerRoutedEventArgs e)
        {
            if (reglerIsPressedMouse) return false;

            PointerPoint pp = e.GetCurrentPoint(gRegler);

            if (pp.Position.Y < GetReglerBasicTopY() || pp.Position.Y > GetReglerBasicBottomY() ||
                pp.Position.X < 0 || pp.Position.X > gRegler.ActualWidth) return false;

            reglerOrigin = new Point(pp.Position.X, pp.Position.Y);
            rId = pp.PointerId;
            reglerIsPressedMouse = true;
            UpdateDriveDataWithReglerValue(defaultValue);

            ViewModel.Current.UpdateReglerSteeringAll();

            return true;
        }

        private bool IsServo(PointerRoutedEventArgs e)
        {
            if (servoIsPressedMouse) return false;

            PointerPoint pp = e.GetCurrentPoint(gServo);

            if (pp.Position.X < GetServoBasicLeftX() || pp.Position.X > GetServoBasicRightX() ||
                pp.Position.Y < 0 || pp.Position.Y > gServo.ActualHeight) return false;

            servoOrigin = new Point(pp.Position.X, pp.Position.Y);
            sId = pp.PointerId;
            servoIsPressedMouse = true;
            UpdateDriveDataWithServoValue(defaultValue);

            ViewModel.Current.UpdateServoSteeringAll();

            return true;
        }

        private void Page_PointerMoved(object sender, PointerRoutedEventArgs e)
        {
            if ((gRegler.PointerCaptures != null)) { }
            if (e.Pointer.PointerId == rId && reglerIsPressedMouse) MoveRegler(e);
            else if (e.Pointer.PointerId == sId && servoIsPressedMouse) MoveServo(e);
        }

        private void MoveRegler(PointerRoutedEventArgs e)
        {
            double steerTopY = GetReglerSteerTopY(), steerBottomY = GetReglerSteerBottomY(), y;
            bool vibrate = false;
            PointerPoint pp = e.GetCurrentPoint(gRegler);

            if (pp.Position.Y < steerTopY)
            {
                y = steerTopY;

                if (pp.Position.Y + vibrationStart < steerTopY) vibrate = true;
            }
            else if (pp.Position.Y > steerBottomY)
            {
                y = steerBottomY;

                if (pp.Position.Y - vibrationStart > steerBottomY) vibrate = true;
            }
            else y = pp.Position.Y;

            if (vibrate) StartReglerVabrating();
            else StopReglerVabrating();

            UpdateDriveDataWithReglerValue((y - steerBottomY) / (steerTopY - steerBottomY) * 127);

            ViewModel.Current.UpdateReglerSteer();
        }

        private void MoveServo(PointerRoutedEventArgs e)
        {
            double steerLeftX = GetServoSteerLeftX(), steerRightX = GetServoSteerRightX(), x;
            bool vibrate = false;
            PointerPoint pp = e.GetCurrentPoint(gServo);

            if (pp.Position.X < steerLeftX)
            {
                x = steerLeftX;

                if (pp.Position.X + vibrationStart < steerLeftX) vibrate = true;
            }
            else if (pp.Position.X > steerRightX)
            {
                x = steerRightX;

                if (pp.Position.X - vibrationStart > steerRightX) vibrate = true;
            }
            else x = pp.Position.X;

            if (vibrate) StartServoVabrating();
            else StopServoVabrating();

            UpdateDriveDataWithServoValue((x - steerLeftX) / (steerRightX - steerLeftX) * 127);

            ViewModel.Current.UpdateServoSteer();
        }

        private void Page_PointerReleasedOrExited(object sender, PointerRoutedEventArgs e)
        {
            if (e.Pointer.PointerId == rId && reglerIsPressedMouse) SetReglerDefault();
            else if (e.Pointer.PointerId == sId && servoIsPressedMouse) SetServoDefault();
        }

        private void SetReglerDefault()
        {
            reglerIsPressedMouse = false;
            UpdateDriveDataWithReglerValue(defaultValue);

            StopReglerVabrating();
            ViewModel.Current.UpdateReglerSteeringAll();
        }

        private void SetServoDefault()
        {
            servoIsPressedMouse = false;
            UpdateDriveDataWithServoValue(defaultValue);

            StopServoVabrating();
            ViewModel.Current.UpdateServoSteeringAll();
        }

        public void SetRValue(double value)
        {
            if (reglerIsPressedMouse || gRegler == null) return;

            reglerOrigin = new Point(gRegler.ActualWidth / 2.0, gRegler.ActualHeight / 2.0);
            UpdateDriveDataWithReglerValue(value);
            reglerIsPressedManuel = value != defaultValue;

            ViewModel.Current.UpdateReglerSteeringAll();
        }

        public void SetSValue(double value)
        {
            if (servoIsPressedMouse || gServo == null) return;

            servoOrigin = new Point(gServo.ActualWidth / 2.0, gServo.ActualHeight / 2.0);
            UpdateDriveDataWithServoValue(value);
            servoIsPressedManuel = value != defaultValue;

            ViewModel.Current.UpdateServoSteeringAll();
        }

        private void GRegler_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            ViewModel.Current.UpdateReglerSteeringAll();
        }

        private void GServo_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            ViewModel.Current.UpdateServoSteeringAll();
        }

        private double GetReglerBasicTopY()
        {
            if (gRegler == null) return 0;

            return (gRegler.ActualHeight - borderLineThickness) / 3.0 + borderLineThickness / 2.0;
        }

        private double GetReglerBasicBottomY()
        {
            if (gRegler == null) return 0;

            return (gRegler.ActualHeight - borderLineThickness) / 3.0 * 2 + borderLineThickness / 2.0;
        }

        private double GetReglerSteerTopY()
        {
            if (gRegler == null) return 0;

            return reglerOrigin.Y - (gRegler.ActualHeight - borderLineThickness) / 3.0;
        }

        private double GetReglerSteerBottomY()
        {
            if (gRegler == null) return 0;

            return reglerOrigin.Y + (gRegler.ActualHeight - borderLineThickness) / 3.0;
        }

        private double GetServoBasicLeftX()
        {
            if (gServo == null) return 0;

            return (gServo.ActualWidth - borderLineThickness) / 3.0 + borderLineThickness / 2.0;
        }

        private double GetServoBasicRightX()
        {
            if (gServo == null) return 0;

            return (gServo.ActualWidth - borderLineThickness) / 3.0 * 2 + borderLineThickness / 2.0;
        }

        private double GetServoSteerLeftX()
        {
            if (gServo == null) return 0;

            return servoOrigin.X - (gServo.ActualWidth - borderLineThickness) / 3.0;
        }

        private double GetServoSteerRightX()
        {
            if (gServo == null) return 0;

            return servoOrigin.X + (gServo.ActualWidth - borderLineThickness) / 3.0;
        }

        public string GetReglerBasicTopData()
        {
            if (reglerIsPressedMouse || reglerIsPressedManuel || gRegler == null) return "";

            string data = "M 0 ";

            data += GetAsString(GetReglerBasicTopY()) + " h ";
            data += GetAsString(gRegler.ActualWidth);

            return data;
        }

        public string GetReglerBasicBottomData()
        {
            if (reglerIsPressedMouse || reglerIsPressedManuel || gRegler == null) return "";

            string data = "M 0 ";

            data += GetAsString(GetReglerBasicBottomY()) + " h ";
            data += GetAsString(gRegler.ActualWidth);

            return data;
        }

        public string GetReglerSteerData()
        {
            if (!(reglerIsPressedMouse || reglerIsPressedManuel) || gRegler == null) return "";

            string data = "M ";

            data += GetAsString(reglerOrigin.X) + " ";
            data += GetAsString(reglerOrigin.Y) + " v ";
            data += GetAsString((rValue - defaultValue) / 127 * (GetReglerSteerTopY() - GetReglerSteerBottomY()));

            return data;
        }

        public string GetReglerSteerTopData()
        {
            if (!(reglerIsPressedMouse || reglerIsPressedManuel) || gRegler == null) return "";

            string data = "M 0 ";

            data += GetAsString(GetReglerSteerTopY()) + " h ";
            data += GetAsString(gRegler.ActualWidth);

            return data;
        }

        public string GetReglerSteerBottomData()
        {
            if (!(reglerIsPressedMouse || reglerIsPressedManuel) || gRegler == null) return "";

            string data = "M 0 ";

            data += GetAsString(GetReglerSteerBottomY()) + " h ";
            data += GetAsString(gRegler.ActualWidth);

            return data;
        }

        public string GetServoBasicLeftData()
        {
            if (servoIsPressedMouse || servoIsPressedManuel || gServo == null) return "";

            string data = "M ";

            data += GetAsString(GetServoBasicLeftX()) + " ";
            data += GetAsString(0) + " v ";
            data += GetAsString(gServo.ActualHeight);

            return data;
        }

        public string GetServoBasicRightData()
        {
            if (servoIsPressedMouse || servoIsPressedManuel || gServo == null) return "";

            string data = "M ";

            data += GetAsString(GetServoBasicRightX()) + " ";
            data += GetAsString(0) + " v ";
            data += GetAsString(gServo.ActualHeight);

            return data;
        }

        public string GetServoSteerData()
        {
            if (!(servoIsPressedMouse || servoIsPressedManuel) || gServo == null) return "";

            string data = "M ";

            data += GetAsString(servoOrigin.X) + " ";
            data += GetAsString(servoOrigin.Y) + " h ";
            data += GetAsString((sValue - defaultValue) / 127 * (GetServoSteerRightX() - GetServoSteerLeftX()));
            
            return data;
        }

        public string GetServoSteerLeftData()
        {
            if (!(servoIsPressedMouse || servoIsPressedManuel) || gServo == null) return "";

            string data = "M ";

            data += GetAsString(GetServoSteerLeftX()) + " ";
            data += GetAsString(0) + " v ";
            data += GetAsString(gServo.ActualHeight);

            return data;
        }

        public string GetServoSteerRightData()
        {
            if (!(servoIsPressedMouse || servoIsPressedManuel) || gServo == null) return "";

            string data = "M ";

            data += GetAsString(GetServoSteerRightX()) + " ";
            data += GetAsString(0) + " v ";
            data += GetAsString(gServo.ActualHeight);

            return data;
        }

        private string GetAsString(double value)
        {
            return value.ToString().Replace(",", ".");
        }

        private void StartReglerVabrating()
        {
            doReglerVibrate = true;

            if (!doServoVibrate) Vibrate();
        }

        private void StartServoVabrating()
        {
            doServoVibrate = true;

            if (!doReglerVibrate) Vibrate();
        }

        private void StopReglerVabrating()
        {
            if (!doReglerVibrate) return;
            doReglerVibrate = false;

            if (!doServoVibrate && vibrator != null) vibrator.Cancel();
        }

        private void StopServoVabrating()
        {
            if (!doServoVibrate) return;
            doServoVibrate = false;

            if (!doReglerVibrate && vibrator != null) vibrator.Cancel();
        }

        private async Task Vibrate()
        {
            if (vibrator == null) return;

            while (doReglerVibrate || doServoVibrate)
            {
                vibrator.Vibrate(TimeSpan.FromMilliseconds(100));
                await Task.Delay(100);
            }
        }
    }
}
