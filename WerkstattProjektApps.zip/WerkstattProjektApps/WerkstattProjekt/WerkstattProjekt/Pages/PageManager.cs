﻿using System;
using System.Threading.Tasks;
using Windows.UI.Xaml.Controls;
using Windows.Phone.UI.Input;
using Windows.UI.Xaml;
using Windows.UI.Core;
using Windows.System.Profile;

namespace WerkstattProjekt
{
    public class PageManager
    {
        private static PageManager current;

        public static PageManager Current
        {
            get
            {
                if (current == null) current = new PageManager();

                return current;
            }
        }

        private bool isMainPage;
        private Page currentPage;

        public bool IsMainPage { get { return isMainPage; } }

        public Type CurrentPageType { get { return currentPage.GetType(); } }

        private PageManager()
        {
            if ("Windows.Mobile" == AnalyticsInfo.VersionInfo.DeviceFamily)
            {
                HardwareButtons.BackPressed += HardwareButtons_BackPressed;
            }
        }

        private async void HardwareButtons_BackPressed(object sender, BackPressedEventArgs e)
        {
            e.Handled = true;

            if (currentPage.GetType() == typeof(MainPage) || currentPage.GetType() == typeof(MonitoringPage))
            {
                ConnectionManager.Current.Terminate();
                Application.Current.Exit();
            }
            else await GoBack();
        }

        public async Task GoBack()
        {
            try
            {
                currentPage.Frame.GoBack();
                return;
            }
            catch { }

           await Windows.ApplicationModel.Core.CoreApplication.MainView.
                CoreWindow.Dispatcher.RunAsync(CoreDispatcherPriority.Normal,
                () => { currentPage.Frame.GoBack(); });
        }

        public async Task Navigate(Type type)
        {
            if (CurrentPageType == type) return;

            try
            {   
                await Windows.ApplicationModel.Core.CoreApplication.MainView.
                CoreWindow.Dispatcher.RunAsync(CoreDispatcherPriority.Normal,
                () => { currentPage.Frame.Navigate(type); });
            }
            catch { }
        }

        public void SetCurrentPage(Page page)
        {
            currentPage = page;
            isMainPage = CurrentPageType == typeof(MainPage);

            if(!isMainPage)
            {
                Steering.Current.ResetPointers();
                EnterSettings.Current.ResetPointers();
            }
        }
    }
}
