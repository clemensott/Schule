﻿using System;
using System.ComponentModel;

namespace WerkstattProjekt
{
    public class Arduino : INotifyPropertyChanged
    {
        private const double batteryVoltageEmpty1S = 3.2, batteryVoltageFull1S = 4.2;
        private static Arduino current;

        public static Arduino Current
        {
            get
            {
                if (current == null) current = new Arduino();

                return current;
            }
        }

        private const int servoValueMax = 127, reglerValueMax = 127;

        private double batteryPercent = 81.67, rpm = 36839;
        private ArduinoSettings settings;
        
        public double BatteryPercent
        {
            get { return batteryPercent; }
            set
            {
                if (batteryPercent == value) return;

                batteryPercent = value;
                System.Diagnostics.Debug.WriteLine("Akku: " + batteryPercent);
                ViewModel.Current.UpdateBatteryPercent();
            }
        }

        public double RPM
        {
            get { return rpm; }
            set
            {
                if (rpm == value) return;

                rpm = value;
                System.Diagnostics.Debug.WriteLine("RPM: " + rpm);
                ViewModel.Current.UpdateRevolutionCounterPointerGeometry();
            }
        }

        public ArduinoSettings Settings
        {
            get { return settings; }
            set
            {
                if (settings == value) return;

                settings = value.GetType()==typeof(ArduinoSettings)? value: value.Clone();
                settings.Save();
                settings.SendToArduino();
                NotifyPropertyChanged("SettingsViewModel");
            }
        }

        public ArduinoSettingsViewModel SettingsViewModel { get { return ArduinoSettingsViewModel.Current; } }

        private Arduino()
        {
            settings = new ArduinoSettings();
        }

        public void SetBatteryVoltage(int voltageValue)
        {
            double voltage = 5 / 1024.0 * voltageValue / 10.0 * 32;
            int cells = GetBatteryCellsCount(voltage);

            BatteryPercent = (voltage - batteryVoltageEmpty1S * cells) / (batteryVoltageFull1S * cells - batteryVoltageEmpty1S * cells) * 100;
        }

        private int GetBatteryCellsCount(double referenceVoltage)
        {
            int i = 0;

            do
            {
                i++;
            } while (batteryVoltageFull1S * i < referenceVoltage);

            return i;
        }

        public void SetRPM(int rpm14Bits)
        {
            RPM = rpm14Bits * 3.1;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(String propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
