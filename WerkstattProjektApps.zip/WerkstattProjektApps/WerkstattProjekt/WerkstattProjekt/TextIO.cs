﻿using System;
using System.IO;
using System.Threading.Tasks;
using Windows.Storage;

namespace WerkstattProjekt
{
    class TextIO
    {
        public async static Task<string> Load(string filenameWithExtention)
        {
            string path = ApplicationData.Current.LocalFolder.Path + "\\" + filenameWithExtention;

            return await PathIO.ReadTextAsync(path);
        }

        public async static Task Save(string text, string filenameWithExtention)
        {
            string path = ApplicationData.Current.LocalFolder.Path + "\\" + filenameWithExtention;

            try
            {
                await PathIO.WriteTextAsync(path, text);
            }
            catch (FileNotFoundException)
            {
                try
                {
                    await ApplicationData.Current.LocalFolder.CreateFileAsync(filenameWithExtention);

                    await PathIO.WriteTextAsync(path, text);
                }
                catch { }
            }
        }
    }
}
