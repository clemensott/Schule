﻿using System;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading;
using Windows.Devices.Bluetooth;
using Windows.Devices.Bluetooth.Rfcomm;
using Windows.Devices.Enumeration;
using Windows.Networking.Sockets;
using Windows.Storage.Streams;

namespace WerkstattProjekt
{
    public class ConnectionManager
    {
        private const int sendTimerIntervall = 50;
        private const string lastNameFilename = "LastName.txt";
        private static ConnectionManager current;

        public static ConnectionManager Current
        {
            get
            {
                if (current == null) current = new ConnectionManager();

                return current;
            }
        }

        private volatile bool isConnecting, endReading;
        private Timer sendTimer;
        private DataWriter writer;
        private StreamSocket socket;
        private RfcommDeviceService serviceRfcomm;

        public bool IsConnected
        {
            get
            {
                return serviceRfcomm != null ? 
                    serviceRfcomm.Device.ConnectionStatus == BluetoothConnectionStatus.Connected : false;
            }
        }

        public bool IsConnecting
        {
            get { return isConnecting; }
            private set
            {
                if (isConnecting = value) return;

                isConnecting = value;
                ViewModel.Current.UpdateDeviceName();
            }
        }

        private ConnectionManager()
        {
            sendTimer = new Timer(new TimerCallback(SendDrive), 0, Timeout.Infinite, sendTimerIntervall);
        }

        public async void RefreshBluetoothDevicesList()
        {
            try
            {
                DeviceInformationCollection bluetoothDevices = await DeviceInformation.FindAllAsync(RfcommDeviceService.
                    GetDeviceSelector(RfcommServiceId.SerialPort));

                ViewModel.Current.BluetoothDevices = bluetoothDevices.ToList();

                if (bluetoothDevices.Count == 1) ViewModel.Current.BluetoothDeviceIndex = 0;
                else if (bluetoothDevices.Count > 1)
                {
                    string lastName = await TextIO.Load(lastNameFilename);
                    DeviceInformation[] devices = bluetoothDevices.Where(x => x.Name == lastName).ToArray();

                    if (devices.Length == 1) ViewModel.Current.BluetoothDeviceIndex = bluetoothDevices.ToList().IndexOf(devices[0]);
                }
                else
                {
                    await PageManager.Current.Navigate(typeof(BluetoothPage));
                }
            }
            catch { }
        }

        public void Terminate()
        {
            if (socket != null) socket.Dispose();
            endReading = true;
        }

        public async void Connect(DeviceInformation bluetoothDevice)
        {
            if (isConnecting) return;
            IsConnecting = true;

            try
            {
                socket = new StreamSocket();

                serviceRfcomm = await RfcommDeviceService.FromIdAsync(bluetoothDevice.Id);
                serviceRfcomm.Device.ConnectionStatusChanged += Device_ConnectionStatusChanged;

                await socket.ConnectAsync(serviceRfcomm.ConnectionHostName, serviceRfcomm.ConnectionServiceName, 
                    SocketProtectionLevel.BluetoothEncryptionAllowNullAuthentication);

                writer = new DataWriter(socket.OutputStream);

                await TextIO.Save(bluetoothDevice.Name, lastNameFilename);

                if (PageManager.Current.CurrentPageType == typeof(BluetoothPage)) await PageManager.Current.GoBack();

                GetMessages();
                Arduino.Current.Settings.SendToArduino();

                System.Diagnostics.Debug.WriteLine("Connected");
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
                ViewModel.Current.UpdateBluetoothDeviceIndex();

                await PageManager.Current.Navigate(typeof(BluetoothPage));
            }

            IsConnecting = false;
        }

        private async void Device_ConnectionStatusChanged(BluetoothDevice sender, object args)
        {
            if (sender.ConnectionStatus == BluetoothConnectionStatus.Disconnected)
            {
                //Terminate();
                //writer = null;

                //await PageManager.Current.Navigate(typeof(BluetoothPage));
            }

            System.Diagnostics.Debug.WriteLine("Changed:" + sender.ConnectionStatus);
        }

        private async void GetMessages()
        {
            try
            {
                while (true)
                {
                    IBuffer ib = new byte[3].AsBuffer();
                    var result = await socket.InputStream.ReadAsync(ib, ib.Capacity, InputStreamOptions.ReadAhead);
                    byte[] ba = result.ToArray();
                    int rpm = 0, battery = 0;

                    rpm = (ba[0] << 6) + (ba[1] >> 2);
                    battery = ((ba[1] % 4) << 8) + ba[2];

                    Arduino.Current.SetBatteryVoltage(battery);
                    Arduino.Current.SetRPM(rpm);

                    if (endReading) return;
                }
            }
            catch { }
        }

        public void ChangeDrive(bool activate)
        {
            int timeOut = activate ? 0 : Timeout.Infinite;
            sendTimer.Change(timeOut, sendTimerIntervall);
        }

        private void SendDrive(object obj)
        {
            if (!PageManager.Current.IsMainPage || !Arduino.Current.Settings.UseApp) return;

            Send(Steering.Current.DriveData);
        }

        public void SendBrake()
        {
            byte b = 128;
            Send(b, b, b, b, b);
        }

        public async void Send(params byte[] array)
        {
            try
            {
                if (writer == null) return;
                
                writer.WriteBytes(array);
                await writer.StoreAsync();
            }
            catch { }
        }
    }
}
