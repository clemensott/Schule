﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using Windows.Devices.Enumeration;
using Windows.UI.Core;
using Windows.UI.Xaml.Markup;
using Windows.UI.Xaml.Media;

namespace WerkstattProjekt
{
    public class ViewModel : INotifyPropertyChanged
    {
        private const double startEndX = 2.5, borderDistance = 7.5;
        private const string noDeviceName = "No Device";
        private static ViewModel current;

        public static ViewModel Current
        {
            get
            {
                if (current == null) current = new ViewModel();

                return current;
            }
        }

        private double rpmGridWidth, rpmGridHeight, batteryGridWidth, batteryGridHeight;
        private string deviceName;
        private List<DeviceInformation> bluetoothDevices;

        public string DeviceName
        {
            get
            {
                if (ConnectionManager.Current.IsConnecting) return "Connecting";

                return ConnectionManager.Current.IsConnected ? deviceName : noDeviceName;
            }
        }

        public string BatteryPercentText
        {
            get { return Math.Round(Arduino.Current.BatteryPercent, 0).ToString() + " %"; }
        }

        public Geometry ReglerBasicTopGeometry { get { return GetGeometry(Steering.Current.GetReglerBasicTopData()); } }

        public Geometry ReglerBasicBottomGeometry { get { return GetGeometry(Steering.Current.GetReglerBasicBottomData()); } }

        public Geometry ReglerSteerGeometry { get { return GetGeometry(Steering.Current.GetReglerSteerData()); } }

        public Geometry ReglerSteerTopGeometry { get { return GetGeometry(Steering.Current.GetReglerSteerTopData()); } }

        public Geometry ReglerSteerBottomGeometry { get { return GetGeometry(Steering.Current.GetReglerSteerBottomData()); } }

        public Geometry ServoBasicLeftGeometry { get { return GetGeometry(Steering.Current.GetServoBasicLeftData()); } }

        public Geometry ServoBasicRightGeometry { get { return GetGeometry(Steering.Current.GetServoBasicRightData()); } }

        public Geometry ServoSteerGeometry { get { return GetGeometry(Steering.Current.GetServoSteerData()); } }

        public Geometry ServoSteerLeftGeometry { get { return GetGeometry(Steering.Current.GetServoSteerLeftData()); } }

        public Geometry ServoSteerRightGeometry { get { return GetGeometry(Steering.Current.GetServoSteerRightData()); } }


        public int BluetoothDeviceIndex
        {
            get { return -1; }
            set
            {
                if (BluetoothDeviceIndex == value) return;

                if (bluetoothDevices.Count == 0)
                {
                    NotifyPropertyChanged("BluetoothDeviceIndex");
                    return;
                }

                deviceName = bluetoothDevices[value].Name;
                ConnectionManager.Current.Connect(bluetoothDevices[value]);
            }
        }

        public List<string> BluetoothDeviceNames { get { return GetDeviceList(); } }

        public List<DeviceInformation> BluetoothDevices
        {
            get { return bluetoothDevices; }
            set
            {
                if (bluetoothDevices == value) return;

                bluetoothDevices = value;

                NotifyPropertyChanged("BluetoothDevices");
            }
        }

        public ArduinoSettingsViewModel ArduinoSettingsViewModel { get { return Arduino.Current.SettingsViewModel; } }

        public Geometry RevolutionCounterGeometry { get { return GetRevolutionCounterGeometry(); } }

        public Geometry RevolutionCounterPointerGeometry { get { return GetRevolutionCounterPointerGeometry(); } }

        public Geometry BatteryGeometry { get { return GetBatteryGeometry(); } }

        public Geometry BatteryStateGeometry { get { return GetBatteryStateGeometry(); } }

        private ViewModel()
        {
            deviceName = noDeviceName;
            bluetoothDevices = new List<DeviceInformation>();
        }

        private List<string> GetDeviceList()
        {
            if (bluetoothDevices.Count > 0) return bluetoothDevices.Select(x=>x.Name).ToList();

            List<string> noDevices = new List<string>();
            noDevices.Add("No Devices");

            return noDevices;
        }

        private Geometry GetRevolutionCounterGeometry()
        {
            string data = "M";
            double widthHeight = (rpmGridWidth < rpmGridHeight ? rpmGridWidth : rpmGridHeight) - borderDistance * 2;
            double radius = Math.Sqrt(widthHeight * widthHeight) / 2.0;
            double originX = rpmGridWidth / 2.0;
            double originY = rpmGridHeight / 2.0;
            double startAngle, endAngle;
            int arcCount = 500, lineCount = 6;

            startAngle = Math.Acos(2 / startEndX) + Math.PI;
            endAngle = -1 * Math.Acos(2 / startEndX);

            originY += (Math.Cos(startAngle) * radius + radius) / 2.0;

            for (int i = 0; i < arcCount; i++)
            {
                double angle = startAngle - i / Convert.ToDouble(arcCount) * (startAngle - endAngle);

                data += string.Format(" {0} {1}", GetAsString(originX + Math.Cos(angle) * radius), 
                    GetAsString(originY - Math.Sin(angle) * radius));
            }

            for (int i = 0; i < lineCount; i++)
            {
                double angle = startAngle - i / Convert.ToDouble(lineCount - 1) * (startAngle - endAngle);

                data += string.Format("M {0} {1} ", GetAsString(Math.Cos(angle) * (radius - borderDistance) + originX), 
                    GetAsString(originY - Math.Sin(angle) * (radius - borderDistance)));

                data += string.Format("L {0} {1} ", GetAsString(Math.Cos(angle) * (radius + borderDistance) + originX),
                    GetAsString(originY - Math.Sin(angle) * (radius + borderDistance)));
            }

            return GetGeometry(data);
        }

        private Geometry GetRevolutionCounterPointerGeometry()
        {
            string data;
            double widthHeight = (rpmGridWidth < rpmGridHeight ? rpmGridWidth : rpmGridHeight) - borderDistance * 2;
            double radius = Math.Sqrt(widthHeight * widthHeight) / 2.0;
            double originX = rpmGridWidth / 2.0;
            double originY = rpmGridHeight / 2.0;
            double startAngle, endAngle, pointerAngle;

            startAngle = Math.Acos(2 / startEndX) + Math.PI;
            endAngle = -1 * Math.Acos(2 / startEndX);
            pointerAngle = startAngle - Arduino.Current.RPM / 50000.0 * (startAngle - endAngle);

            originY += (Math.Cos(startAngle) * radius + radius) / 2.0;

            data = string.Format("M {0} {1}", GetAsString(originX), GetAsString(originY));
            data += string.Format("L {0} {1} ", GetAsString(originX + Math.Cos(pointerAngle) * (radius + borderDistance)),
                    GetAsString(originY - Math.Sin(pointerAngle) * (radius + borderDistance)));

            return GetGeometry(data);
        }

        private Geometry GetBatteryGeometry()
        {
            string data;
            double width = batteryGridWidth * 2 < batteryGridHeight ? batteryGridWidth / 2.0 : batteryGridHeight / 4.0;
            double height = width * 2;
            double originX = (batteryGridWidth - width) / 2.0;
            double originY = (batteryGridHeight - height) / 4.0 + 10;

            data = string.Format("M {0} {1} h {2} v {3} h {4} z", GetAsString(originX),
                GetAsString(originY), GetAsString(width), GetAsString(height), GetAsString(-width));

            data += string.Format(" M {0} {1} h {2}", GetAsString(originX + width / 4.0),
                GetAsString(originY - 5), GetAsString(width / 2.0));
            data += string.Format(" M {0} {1} h {2}", GetAsString(originX + width / 4.0),
                GetAsString(originY - 10), GetAsString(width / 2.0));

            return GetGeometry(data);
        }

        private Geometry GetBatteryStateGeometry()
        {
            string data;
            double width = (batteryGridWidth * 2 < batteryGridHeight ? batteryGridWidth / 2.0 : batteryGridHeight / 4.0);
            double height = width * 2;
            double originX = (batteryGridWidth - width) / 2.0 + 5;
            double originY = (batteryGridHeight - height) / 4.0 + height + 5;

            width -= 10;
            height = (height - 10) / 100.0 * Arduino.Current.BatteryPercent;

            data = string.Format("M {0} {1} h {2} v {3} h {4} z", GetAsString(originX),
                GetAsString(originY), GetAsString(width), GetAsString(-height), GetAsString(-width));

            return GetGeometry(data);
        }

        private string GetAsString(double value)
        {
            return value.ToString().Replace(",", ".");
        }

        private Geometry GetGeometry(string data)
        {
            if (data == "") return new PathGeometry();

            try
            {
                data = "<Geometry xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'>" + data;
                data += "</Geometry>";

                return (Geometry)XamlReader.Load(data);
            }
            catch { }

            return new PathGeometry();
        }

        public void SetRpmGridWidthAndHeight(double width, double height)
        {
            rpmGridWidth = width;
            rpmGridHeight = height;

            UpdateRevolutionCounterGeometry();
            UpdateRevolutionCounterPointerGeometry();
        }

        public void SetBatteryGridWidthAndHeight(double width, double height)
        {
            batteryGridWidth = width;
            batteryGridHeight = height;

            UpdateBatteryGeometry();
            UpdateBatteryStateGeometry();
        }

        public void UpdateDeviceName()
        {
            NotifyPropertyChanged("DeviceName");
        }

        public void UpdateBluetoothDeviceIndex()
        {
            NotifyPropertyChanged("BluetoothDeviceIndex");
        }

        public void UpdateArduinoSettingsViewModel()
        {
            NotifyPropertyChanged("ArduinoSettingsViewModel");
        }

        public void UpdateBatteryPercent()
        {
            NotifyPropertyChanged("BatteryPercentText");
        }

        public void UpdateRevolutionCounterGeometry()
        {
            NotifyPropertyChanged("RevolutionCounterGeometry");
        }

        public void UpdateRevolutionCounterPointerGeometry()
        {
            NotifyPropertyChanged("RevolutionCounterPointerGeometry");
        }

        public void UpdateBatteryGeometry()
        {
            NotifyPropertyChanged("BatteryGeometry");
        }

        public void UpdateBatteryStateGeometry()
        {
            NotifyPropertyChanged("BatteryStateGeometry");
        }

        public void UpdateReglerSteeringAll()
        {
            NotifyPropertyChanged("ReglerBasicTopGeometry");
            NotifyPropertyChanged("ReglerBasicBottomGeometry");
            NotifyPropertyChanged("ReglerSteerTopGeometry");
            NotifyPropertyChanged("ReglerSteerBottomGeometry");

            UpdateReglerSteer();
        }

        public void UpdateReglerSteer()
        {
            NotifyPropertyChanged("ReglerSteerGeometry");
        }

        public void UpdateServoSteeringAll()
        {
            NotifyPropertyChanged("ServoBasicLeftGeometry");
            NotifyPropertyChanged("ServoBasicRightGeometry");
            NotifyPropertyChanged("ServoSteerLeftGeometry");
            NotifyPropertyChanged("ServoSteerRightGeometry");

            UpdateServoSteer();
        }

        public void UpdateServoSteer()
        {
            NotifyPropertyChanged("ServoSteerGeometry");
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private async void NotifyPropertyChanged(String propertyName)
        {
            try
            {
                if (null == PropertyChanged) return;

                await Windows.ApplicationModel.Core.CoreApplication.MainView.
                    CoreWindow.Dispatcher.RunAsync(CoreDispatcherPriority.Normal,
                    () => { PropertyChanged(this, new PropertyChangedEventArgs(propertyName)); });
            }
            catch { }
        }
    }
}
