﻿using System;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Markup;
using Windows.UI.Xaml.Media;

namespace WerkstattProjekt
{
    public class ArduinoSettingsViewModel : ArduinoSettings
    {
        private static ArduinoSettingsViewModel current;

        public static ArduinoSettingsViewModel Current
        {
            get
            {
                if (current == null || current == Arduino.Current.Settings)
                {
                    current = new ArduinoSettingsViewModel();
                    ViewModel.Current.UpdateArduinoSettingsViewModel();
                }

                return current;
            }
        }

        private byte reglerOffset, servoOffset, frontBrightness, upBrightness, backBrightness;
        private double reglerCoordinateSystemSize, servoCoordinateSystemSize;

        public bool JustRemoteIsEnabled { get { return !UseApp; } }

        public bool ReglerRemoteIsChecked
        {
            get { return ReglerOffset == 127&&!UseApp; }
            set
            {
                if ((ReglerOffset == 127) == value || UseApp) return;

                ReglerOffset = Convert.ToByte(value ? 127 : reglerOffset);

                NotifyPropertyChanged("ReglerRemoteIsChecked");
                NotifyPropertyChanged("ReglerHandleIsChecked");
                NotifyPropertyChanged("ReglerOffsetAndCurveSliderIsEnabled");
                NotifyPropertyChanged("ReglerGraphVisibility");
            }
        }

        public bool ReglerOffsetAndCurveSliderIsEnabled
        {
            get { return !ReglerRemoteIsChecked || UseApp; }
        }

        public bool ServoRemoteIsChecked
        {
            get { return ServoOffset == 127 && !UseApp; }
            set
            {
                if ((ServoOffset == 127) == value || UseApp) return;

                ServoOffset = Convert.ToByte(value ? 127 : servoOffset);

                NotifyPropertyChanged("ServoRemoteIsChecked");
                NotifyPropertyChanged("ServoHandleIsChecked");
                NotifyPropertyChanged("ServoOffsetAndCurveSliderIsEnabled");
                NotifyPropertyChanged("ServoGraphVisibility");
            }
        }

        public bool ServoOffsetAndCurveSliderIsEnabled
        {
            get { return !ServoRemoteIsChecked || UseApp; }
        }

        public bool FrontBrightnessAuto
        {
            get { return FrontBrightness == 7; }
            set
            {
                if (FrontBrightnessAuto == value) return;

                FrontBrightness = Convert.ToByte(value ? 7 : frontBrightness);

                NotifyPropertyChanged("FrontBrightnessAuto");
                NotifyPropertyChanged("FrontBrightnessIsEnabled");
                NotifyPropertyChanged("FrontBrightness");
        }
    }

        public bool FrontBrightnessIsEnabled { get { return !FrontBrightnessAuto; } }

        public bool UpBrightnessAuto
        {
            get { return UpBrightness == 7; }
            set
            {
                if (UpBrightnessAuto == value) return;

                UpBrightness = Convert.ToByte(value ? 7 : upBrightness);

                NotifyPropertyChanged("UpBrightnessAuto");
                NotifyPropertyChanged("UpBrightnessIsEnabled");
                NotifyPropertyChanged("UpBrightness");
            }
        }

        public bool UpBrightnessIsEnabled { get { return !UpBrightnessAuto; } }

        public bool BackBrightnessAuto
        {
            get { return BackBrightness == 7; }
            set
            {
                if (BackBrightnessAuto == value) return;

                BackBrightness = Convert.ToByte(value ? 7: backBrightness);

                NotifyPropertyChanged("BackBrightnessAuto");
                NotifyPropertyChanged("BackBrightnessIsEnabled");
                NotifyPropertyChanged("BackBrightness");
            }
        }

        public bool BackBrightnessIsEnabled { get { return !BackBrightnessAuto; } }

        public double ReglerAmplitudeDouble
        {
            get { return Convert.ToDouble(ReglerAmplitude); }
            set
            {
                if (ReglerAmplitudeDouble == value) return;

                ReglerAmplitude = Convert.ToByte(value);
                NotifyPropertyChanged("ReglerAmplitudeDouble");
                NotifyPropertyChanged("ReglerGraphGeometry");
            }
        }

        public double ReglerOffsetDouble
        {
            get { return Convert.ToDouble(ReglerOffset); }
            set
            {
                if (ReglerOffsetDouble == value) return;

                reglerOffset = ReglerOffset = Convert.ToByte(value);
                NotifyPropertyChanged("ReglerOffsetDouble");
                NotifyPropertyChanged("ReglerGraphGeometry");
            }
        }

        public double ReglerCurveDouble
        {
            get { return Convert.ToDouble(ReglerCurve); }
            set
            {
                if (ReglerCurveDouble == value) return;

                ReglerCurve = Convert.ToByte(value);
                NotifyPropertyChanged("ReglerCurveDouble");
                NotifyPropertyChanged("ReglerGraphGeometry");
            }
        }

        public double ServoAmplitudeDouble
        {
            get { return Convert.ToDouble(ServoAmplitude); }
            set
            {
                if (ServoAmplitudeDouble == value) return;

                ServoAmplitude = Convert.ToByte(value);
                NotifyPropertyChanged("ServoAmplitudeDouble");
                NotifyPropertyChanged("ServoGraphGeometry");
            }
        }

        public double ServoOffsetDouble
        {
            get { return Convert.ToDouble(ServoOffset); }
            set
            {
                if (ServoOffset == value) return;

                servoOffset = ServoOffset = Convert.ToByte(value);
                NotifyPropertyChanged("ServoOffsetDouble");
                NotifyPropertyChanged("ServoGraphGeometry");
            }
        }

        public double ServoCurveDouble
        {
            get { return Convert.ToDouble(ServoCurve); }
            set
            {
                if (ServoCurveDouble == value) return;

                ServoCurve = Convert.ToByte(value);
                NotifyPropertyChanged("ServoCurveDouble");
                NotifyPropertyChanged("ServoGraphGeometry");
            }
        }

        public double FrontBrightnessDouble
        {
            get { return FrontBrightnessAuto ? frontBrightness : FrontBrightness - 1; }
            set
            {
                if (FrontBrightnessDouble == value) return;

                frontBrightness = Convert.ToByte(value);
                FrontBrightness = Convert.ToByte(value + 1);
                NotifyPropertyChanged("FrontBrightnessDouble");
            }
        }

        public double UpBrightnessDouble
        {
            get { return UpBrightnessAuto ? upBrightness: UpBrightness - 1; }
            set
            {
                if (UpBrightnessDouble == value) return;

                upBrightness = Convert.ToByte(value);
                UpBrightness = Convert.ToByte(value + 1);
                NotifyPropertyChanged("UpBrightnessDouble");
            }
        }

        public double BackBrightnessDouble
        {
            get { return BackBrightnessAuto ? backBrightness : BackBrightness - 1; }
            set
            {
                if (BackBrightnessDouble == value) return;

                backBrightness = Convert.ToByte(value);
                BackBrightness = Convert.ToByte(value + 1);
                NotifyPropertyChanged("BackBrightnessDouble");
            }
        }

        public double ReglerCoordinateSystemSize
        {
            get { return reglerCoordinateSystemSize; }
            set
            {
                if (reglerCoordinateSystemSize == value) return;

                reglerCoordinateSystemSize = value;
                NotifyPropertyChanged("ReglerGraphGeometry");
            }
        }

        public double ServoCoordinateSystemSize
        {
            get { return servoCoordinateSystemSize; }
            set
            {
                if (servoCoordinateSystemSize == value) return;

                servoCoordinateSystemSize = value;
                NotifyPropertyChanged("ServoGraphGeometry");
            }
        }

        public Visibility ReglerGraphVisibility
        {
            get { return ReglerRemoteIsChecked ? Visibility.Collapsed : Visibility.Visible; }
        }

        public Visibility ServoGraphVisibility
        {
            get { return ServoRemoteIsChecked ? Visibility.Collapsed : Visibility.Visible; }
        }

        public Geometry ReglerGraphGeometry { get { return GetReglerGraphGeometry(); } }

        public Geometry ServoGraphGeometry { get { return GetServoGraphGeometry(); } }

        private ArduinoSettingsViewModel()
        {
            UseRemotetWithoutBluetooth = Arduino.Current.Settings.UseRemotetWithoutBluetooth;
            DoBlink = Arduino.Current.Settings.DoBlink;
            UseApp = Arduino.Current.Settings.UseApp;

            ReglerAmplitude = Arduino.Current.Settings.ReglerAmplitude;
            ReglerOffset = Arduino.Current.Settings.ReglerOffset;
            ReglerCurve = Arduino.Current.Settings.ReglerCurve;

            ServoAmplitude = Arduino.Current.Settings.ServoAmplitude;
            ServoOffset = Arduino.Current.Settings.ServoOffset;
            ServoCurve = Arduino.Current.Settings.ServoCurve;

            FrontBrightness = Arduino.Current.Settings.FrontBrightness;
            UpBrightness = Arduino.Current.Settings.UpBrightness;
            BackBrightness = Arduino.Current.Settings.BackBrightness;
        }

        private Geometry GetReglerGraphGeometry()
        {
            if (servoCoordinateSystemSize == 0) return GetGeometry("");

            string data = "M";

            for (int i = 0; i < reglerCoordinateSystemSize; i++)
            {
                data += string.Format(" {0} {1}", i, GetYValue(i, 
                    reglerCoordinateSystemSize, ReglerOffset, ReglerCurve, ReglerAmplitude));
            }

            return GetGeometry(data);
        }

        private Geometry GetServoGraphGeometry()
        {
            if (servoCoordinateSystemSize == 0) return GetGeometry("");

            string data = "M";

            for (int i = 0; i < servoCoordinateSystemSize; i++)
            {
                data += string.Format(" {0} {1}", i, GetYValue(i, 
                    servoCoordinateSystemSize, ServoOffset, ServoCurve, ServoAmplitude));
            }

            return GetGeometry(data);
        }

        private string GetYValue(double x, double max, double offset, double curve, double amplitude)
        {
            double outY, effectivX, xMax1 = (x - max / 2) / max * 2;

            effectivX = (0.5 - offset / 126) * xMax1 * xMax1 + xMax1 + offset / 126 - 0.5;

            double c = 4 / Math.Pow(Math.Pow(16, 1 / 63.0), curve);

            if (effectivX > 0) outY = Math.Pow(effectivX, c);
            else outY = 0 - Math.Pow(0 - effectivX, c);

            outY = max / 2.0 - outY * (amplitude - 7.5) / 7.5 * max / 2.0;

            return outY.ToString().Replace(",", ".");
        }

        private Geometry GetGeometry(string data)
        {
            if (data == "") return new PathGeometry();

            try
            {
                data = "<Geometry xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'>" + data;
                data += "</Geometry>";

                return (Geometry)XamlReader.Load(data);
            }
            catch { }

            return new PathGeometry();
        }
    }
}
