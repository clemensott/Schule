﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WerkstattProjektDataZeiger
{
    public partial class Form1 : Form
    {
        int t;
        Points points;

        public Form1()
        {
            InitializeComponent();

            points = new Points(Convert.ToInt32(nud_Width.Value), Convert.ToInt32(nud_Height.Value));
        }

        private void pbx_Data_Paint(object sender, PaintEventArgs e)
        {
            Pen pen = new Pen(Color.Black, t);

            for (int i = 0; i < points.Length; i++)
            {
                e.Graphics.DrawLines(pen, points[i]);
            }
        }

        private void tbx_Data_TextChanged(object sender, EventArgs e)
        {
            points.Set(tbx_Data.Text);
            pbx_Data.Invalidate();
        }

        private void nud_Width_ValueChanged(object sender, EventArgs e)
        {
            points.W = Convert.ToInt32(nud_Width.Value);
            pbx_Data.Invalidate();
        }

        private void nud_Height_ValueChanged(object sender, EventArgs e)
        {
            points.H = Convert.ToInt32(nud_Height.Value);
            pbx_Data.Invalidate();
        }

        private void nud_Thickness_ValueChanged(object sender, EventArgs e)
        {
            t = Convert.ToInt32(nud_Thickness.Value);
            pbx_Data.Invalidate();
        }
    }

    class Points
    {
        int h, w;
        List<int> values;

        public Point[] this[int index] { get { return GetPaar(index); } }

        public int Length { get { return values.Count; } }

        public int H { get { return h; } set { h = value; } }

        public int W { get { return w; } set { w = value; } }

        public Points(int w, int h)
        {
            this.w = w;
            this.h = h;

            values = new List<int>();
        }

        public void Set(string dataString)
        {
            int valueInt;
            string[] valuesString = dataString.Split('\n');

            values = new List<int>();

            foreach (string valueString in valuesString)
            {
                if (int.TryParse(valueString, out valueInt)) values.Add(valueInt);
            }
        }

        private Point[] GetPaar(int x)
        {
            return new Point[] { new Point(x * w, values[x] * h), new Point(x * w + w, values[x] * h) };
        }
    }
}
