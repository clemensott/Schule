﻿namespace WerkstattProjektDataZeiger
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbx_Data = new System.Windows.Forms.TextBox();
            this.pbx_Data = new System.Windows.Forms.PictureBox();
            this.nud_Width = new System.Windows.Forms.NumericUpDown();
            this.nud_Height = new System.Windows.Forms.NumericUpDown();
            this.nud_Thickness = new System.Windows.Forms.NumericUpDown();
            this.lbl_W = new System.Windows.Forms.Label();
            this.lbl_H = new System.Windows.Forms.Label();
            this.lbl_T = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_Data)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Width)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Height)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Thickness)).BeginInit();
            this.SuspendLayout();
            // 
            // tbx_Data
            // 
            this.tbx_Data.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.tbx_Data.Location = new System.Drawing.Point(12, 91);
            this.tbx_Data.Multiline = true;
            this.tbx_Data.Name = "tbx_Data";
            this.tbx_Data.Size = new System.Drawing.Size(100, 340);
            this.tbx_Data.TabIndex = 0;
            this.tbx_Data.TextChanged += new System.EventHandler(this.tbx_Data_TextChanged);
            // 
            // pbx_Data
            // 
            this.pbx_Data.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pbx_Data.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbx_Data.Location = new System.Drawing.Point(119, 13);
            this.pbx_Data.Name = "pbx_Data";
            this.pbx_Data.Size = new System.Drawing.Size(585, 418);
            this.pbx_Data.TabIndex = 1;
            this.pbx_Data.TabStop = false;
            this.pbx_Data.Paint += new System.Windows.Forms.PaintEventHandler(this.pbx_Data_Paint);
            // 
            // nud_Width
            // 
            this.nud_Width.Location = new System.Drawing.Point(36, 13);
            this.nud_Width.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_Width.Name = "nud_Width";
            this.nud_Width.Size = new System.Drawing.Size(76, 20);
            this.nud_Width.TabIndex = 2;
            this.nud_Width.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_Width.ValueChanged += new System.EventHandler(this.nud_Width_ValueChanged);
            // 
            // nud_Height
            // 
            this.nud_Height.Location = new System.Drawing.Point(36, 39);
            this.nud_Height.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_Height.Name = "nud_Height";
            this.nud_Height.Size = new System.Drawing.Size(76, 20);
            this.nud_Height.TabIndex = 2;
            this.nud_Height.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_Height.ValueChanged += new System.EventHandler(this.nud_Height_ValueChanged);
            // 
            // nud_Thickness
            // 
            this.nud_Thickness.Location = new System.Drawing.Point(36, 65);
            this.nud_Thickness.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud_Thickness.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_Thickness.Name = "nud_Thickness";
            this.nud_Thickness.Size = new System.Drawing.Size(76, 20);
            this.nud_Thickness.TabIndex = 2;
            this.nud_Thickness.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_Thickness.ValueChanged += new System.EventHandler(this.nud_Thickness_ValueChanged);
            // 
            // lbl_W
            // 
            this.lbl_W.AutoSize = true;
            this.lbl_W.Location = new System.Drawing.Point(12, 15);
            this.lbl_W.Name = "lbl_W";
            this.lbl_W.Size = new System.Drawing.Size(18, 13);
            this.lbl_W.TabIndex = 3;
            this.lbl_W.Text = "W";
            // 
            // lbl_H
            // 
            this.lbl_H.AutoSize = true;
            this.lbl_H.Location = new System.Drawing.Point(12, 41);
            this.lbl_H.Name = "lbl_H";
            this.lbl_H.Size = new System.Drawing.Size(15, 13);
            this.lbl_H.TabIndex = 3;
            this.lbl_H.Text = "H";
            // 
            // lbl_T
            // 
            this.lbl_T.AutoSize = true;
            this.lbl_T.Location = new System.Drawing.Point(12, 67);
            this.lbl_T.Name = "lbl_T";
            this.lbl_T.Size = new System.Drawing.Size(14, 13);
            this.lbl_T.TabIndex = 3;
            this.lbl_T.Text = "T";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(716, 443);
            this.Controls.Add(this.lbl_T);
            this.Controls.Add(this.lbl_H);
            this.Controls.Add(this.lbl_W);
            this.Controls.Add(this.nud_Thickness);
            this.Controls.Add(this.nud_Height);
            this.Controls.Add(this.nud_Width);
            this.Controls.Add(this.pbx_Data);
            this.Controls.Add(this.tbx_Data);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pbx_Data)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Width)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Height)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Thickness)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbx_Data;
        private System.Windows.Forms.PictureBox pbx_Data;
        private System.Windows.Forms.NumericUpDown nud_Width;
        private System.Windows.Forms.NumericUpDown nud_Height;
        private System.Windows.Forms.NumericUpDown nud_Thickness;
        private System.Windows.Forms.Label lbl_W;
        private System.Windows.Forms.Label lbl_H;
        private System.Windows.Forms.Label lbl_T;
    }
}

