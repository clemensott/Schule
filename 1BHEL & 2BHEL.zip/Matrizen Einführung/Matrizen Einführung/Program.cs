﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Matrizen_Einführung
{
    class Program
    {
        static void Main(string[] args)
        {
            int z = 10, s = 10;

            int[,] a = new int[z, s];

            Random zz = new Random();

            for (int i = 0; i < z; i++)
            {
                for (int j = 0; j < s; j++)
                {
                    a[i, j] = (i + 11) * (j + 11);
                }
            }

            for (int i = 0; i < z; i++)
            {
                for (int j = 0; j < s; j++)
                {
                    Console.Write("{0,4}", a[i,j]); //{0,4}...Es die Zahl benutzt 4 Zeichen
                }
                Console.WriteLine();
            }

            Console.WriteLine();

            int z1, z2;

            Console.Write("Zahl 1 (11-20): ");
            z1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Zahl 2 (11-20): ");
            z2 = Convert.ToInt32(Console.ReadLine());

            if (!(z1 < 11 || z1 > 20 || z2 < 11 || z2 > 20))
            {
                Console.WriteLine("Das Produkt aus {0} und {1} ist {2}", z1, z2, a[(z1 - 11), (z2 - 11)]);
                Console.ReadLine();
            }

            
        }
    }
}
