﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Schleife
{
    class Program
    {
        static void Main(string[] args)
        {
            int grenze, zahl;

            Console.Write("Zählen bis: ");
            grenze = Convert.ToInt32(Console.ReadLine());

            for (zahl = 0; zahl <= grenze; zahl = zahl+1)
            {
                Console.WriteLine(zahl);
            }

            Console.ReadLine();
        }
    }
}
