// C++ testen.cpp : Definiert den Einstiegspunkt f�r die Konsolenanwendung.
//

#include "stdafx.h"
#include "time.h"
#include "stdlib.h"

int einlesen(char text[])
{
	int zahl;

	printf(text);
	scanf("%d",&zahl);

	return zahl;
}

void main()
{
	int* po;
	int wert = 23;

	po = &wert;

	printf("%d, %d, %d, %d\n", po, &wert, *po, wert);
}