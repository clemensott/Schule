﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kassensystem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_hinzu_Click(object sender, EventArgs e)
        {
            hinzu();
        }
      private void hinzu()
    {
        int i;
        double ein = 0, ergbnis = 0;
        double[] zahl = new double[7];
        string strich, speich1, speich2;
        char[] euro = { ' ', '€' };
        bool fehler = false;

        try
        {
            ein = Convert.ToDouble(tbx_hinzu.Text);
        }
        catch
        {
            MessageBox.Show("Nicht möglich", "Fehler");

            fehler = true;
        }

        if (!fehler)
        {

            try
            {
                speich1 = lbl_1.Text;
                speich2 = speich1.TrimEnd(euro);

                zahl[0] = Convert.ToDouble(speich2);
            }
            catch
            {
                zahl[0] = 0;
            }

            try
            {
                speich1 = lbl_2.Text;
                speich2 = speich1.TrimEnd(euro);

                zahl[1] = Convert.ToDouble(speich2);
            }
            catch
            {
                zahl[1] = 0;
            }

            try
            {
                speich1 = lbl_3.Text;
                speich2 = speich1.TrimEnd(euro);

                zahl[2] = Convert.ToDouble(speich2);
            }
            catch
            {
                zahl[2] = 0;
            }

            try
            {
                speich1 = lbl_4.Text;
                speich2 = speich1.TrimEnd(euro);

                zahl[3] = Convert.ToDouble(speich2);
            }
            catch
            {
                zahl[3] = 0;
            }

            try
            {
                speich1 = lbl_5.Text;
                speich2 = speich1.TrimEnd(euro);

                zahl[4] = Convert.ToDouble(speich2);
            }
            catch
            {
                zahl[4] = 0;
            }

            try
            {
                speich1 = lbl_6.Text;
                speich2 = speich1.TrimEnd(euro);

                zahl[5] = Convert.ToDouble(speich2);
            }
            catch
            {
                zahl[5] = 0;
            }

            try
            {
                speich1 = lbl_7.Text;
                speich2 = speich1.TrimEnd(euro);

                zahl[6] = Convert.ToDouble(speich2);
            }
            catch
            {
                zahl[6] = 0;
            }

            zahl[0] = zahl[0] + zahl[1];

            for (i = 1; i < 6; i++)
            {
                zahl[i] = zahl[(i + 1)];
            }

            zahl[6] = ein;

            for (i = 0; i < 7; i++)
            {
                ergbnis = ergbnis + zahl[i];
            }

            for (i = 0; i < 7; i++)
            {
                zahl[i] = Math.Round(zahl[i], 2);
            }

            ergbnis = Math.Round(ergbnis, 2);

            if (zahl[0] != 0)
                lbl_1.Text = Convert.ToString(zahl[0]) + " €";

            if (zahl[1] != 0)
                lbl_2.Text = Convert.ToString(zahl[1]) + " €";

            if (zahl[2] != 0)
                lbl_3.Text = Convert.ToString(zahl[2]) + " €";

            if (zahl[3] != 0)
                lbl_4.Text = Convert.ToString(zahl[3]) + " €";

            if (zahl[4] != 0)
                lbl_5.Text = Convert.ToString(zahl[4]) + " €";

            if (zahl[5] != 0)
                lbl_6.Text = Convert.ToString(zahl[5]) + " €";

            lbl_7.Text = Convert.ToString(zahl[6]) + " €";

            lbl_ergebnis.Text = Convert.ToString(ergbnis) + " €";

            strich = "---------";

            for (i = 10; i <= ergbnis; i = i * 10)
            {
                strich = strich + "--";
            }

            lbl_strich.Text = strich;

        }
            tbx_hinzu.Text = "";
    }

      private void btn_fertig_Click(object sender, EventArgs e)
      {
          MessageBox.Show("Summe: " + lbl_ergebnis.Text, "Rechnung");

          lbl_1.Text = "";
          lbl_2.Text = "";
          lbl_3.Text = "";
          lbl_4.Text = "";
          lbl_5.Text = "";
          lbl_6.Text = "";
          lbl_7.Text = "";

          lbl_ergebnis.Text = "";

          lbl_strich.Text = "";

          tbx_hinzu.Text = "";
      }
    
    }
}
