﻿namespace Kassensystem
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbx_hinzu = new System.Windows.Forms.TextBox();
            this.btn_hinzu = new System.Windows.Forms.Button();
            this.btn_fertig = new System.Windows.Forms.Button();
            this.lbl_4 = new System.Windows.Forms.Label();
            this.lbl_5 = new System.Windows.Forms.Label();
            this.lbl_6 = new System.Windows.Forms.Label();
            this.lbl_strich = new System.Windows.Forms.Label();
            this.lbl_ergebnis = new System.Windows.Forms.Label();
            this.lbl_3 = new System.Windows.Forms.Label();
            this.lbl_2 = new System.Windows.Forms.Label();
            this.lbl_1 = new System.Windows.Forms.Label();
            this.lbl_7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tbx_hinzu
            // 
            this.tbx_hinzu.Location = new System.Drawing.Point(30, 25);
            this.tbx_hinzu.Name = "tbx_hinzu";
            this.tbx_hinzu.Size = new System.Drawing.Size(100, 20);
            this.tbx_hinzu.TabIndex = 0;
            // 
            // btn_hinzu
            // 
            this.btn_hinzu.Location = new System.Drawing.Point(186, 18);
            this.btn_hinzu.Name = "btn_hinzu";
            this.btn_hinzu.Size = new System.Drawing.Size(75, 33);
            this.btn_hinzu.TabIndex = 1;
            this.btn_hinzu.Text = "Hinzufügen";
            this.btn_hinzu.UseVisualStyleBackColor = true;
            this.btn_hinzu.Click += new System.EventHandler(this.btn_hinzu_Click);
            // 
            // btn_fertig
            // 
            this.btn_fertig.Location = new System.Drawing.Point(186, 87);
            this.btn_fertig.Name = "btn_fertig";
            this.btn_fertig.Size = new System.Drawing.Size(75, 34);
            this.btn_fertig.TabIndex = 2;
            this.btn_fertig.Text = "Fertig";
            this.btn_fertig.UseVisualStyleBackColor = true;
            this.btn_fertig.Click += new System.EventHandler(this.btn_fertig_Click);
            // 
            // lbl_4
            // 
            this.lbl_4.AutoSize = true;
            this.lbl_4.Location = new System.Drawing.Point(28, 132);
            this.lbl_4.Name = "lbl_4";
            this.lbl_4.Size = new System.Drawing.Size(0, 13);
            this.lbl_4.TabIndex = 3;
            // 
            // lbl_5
            // 
            this.lbl_5.AutoSize = true;
            this.lbl_5.Location = new System.Drawing.Point(28, 154);
            this.lbl_5.Name = "lbl_5";
            this.lbl_5.Size = new System.Drawing.Size(0, 13);
            this.lbl_5.TabIndex = 4;
            // 
            // lbl_6
            // 
            this.lbl_6.AutoSize = true;
            this.lbl_6.Location = new System.Drawing.Point(28, 176);
            this.lbl_6.Name = "lbl_6";
            this.lbl_6.Size = new System.Drawing.Size(0, 13);
            this.lbl_6.TabIndex = 5;
            // 
            // lbl_strich
            // 
            this.lbl_strich.AutoSize = true;
            this.lbl_strich.Location = new System.Drawing.Point(27, 212);
            this.lbl_strich.Name = "lbl_strich";
            this.lbl_strich.Size = new System.Drawing.Size(0, 13);
            this.lbl_strich.TabIndex = 6;
            // 
            // lbl_ergebnis
            // 
            this.lbl_ergebnis.AutoSize = true;
            this.lbl_ergebnis.Location = new System.Drawing.Point(28, 225);
            this.lbl_ergebnis.Name = "lbl_ergebnis";
            this.lbl_ergebnis.Size = new System.Drawing.Size(0, 13);
            this.lbl_ergebnis.TabIndex = 7;
            // 
            // lbl_3
            // 
            this.lbl_3.AutoSize = true;
            this.lbl_3.Location = new System.Drawing.Point(28, 109);
            this.lbl_3.Name = "lbl_3";
            this.lbl_3.Size = new System.Drawing.Size(0, 13);
            this.lbl_3.TabIndex = 9;
            // 
            // lbl_2
            // 
            this.lbl_2.AutoSize = true;
            this.lbl_2.Location = new System.Drawing.Point(28, 87);
            this.lbl_2.Name = "lbl_2";
            this.lbl_2.Size = new System.Drawing.Size(0, 13);
            this.lbl_2.TabIndex = 11;
            // 
            // lbl_1
            // 
            this.lbl_1.AutoSize = true;
            this.lbl_1.Location = new System.Drawing.Point(28, 64);
            this.lbl_1.Name = "lbl_1";
            this.lbl_1.Size = new System.Drawing.Size(0, 13);
            this.lbl_1.TabIndex = 13;
            // 
            // lbl_7
            // 
            this.lbl_7.AutoSize = true;
            this.lbl_7.Location = new System.Drawing.Point(28, 199);
            this.lbl_7.Name = "lbl_7";
            this.lbl_7.Size = new System.Drawing.Size(0, 13);
            this.lbl_7.TabIndex = 15;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.lbl_7);
            this.Controls.Add(this.lbl_1);
            this.Controls.Add(this.lbl_2);
            this.Controls.Add(this.lbl_3);
            this.Controls.Add(this.lbl_ergebnis);
            this.Controls.Add(this.lbl_strich);
            this.Controls.Add(this.lbl_6);
            this.Controls.Add(this.lbl_5);
            this.Controls.Add(this.lbl_4);
            this.Controls.Add(this.btn_fertig);
            this.Controls.Add(this.btn_hinzu);
            this.Controls.Add(this.tbx_hinzu);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Kassensystem";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbx_hinzu;
        private System.Windows.Forms.Button btn_hinzu;
        private System.Windows.Forms.Button btn_fertig;
        private System.Windows.Forms.Label lbl_4;
        private System.Windows.Forms.Label lbl_5;
        private System.Windows.Forms.Label lbl_6;
        private System.Windows.Forms.Label lbl_strich;
        private System.Windows.Forms.Label lbl_ergebnis;
        private System.Windows.Forms.Label lbl_3;
        private System.Windows.Forms.Label lbl_2;
        private System.Windows.Forms.Label lbl_1;
        private System.Windows.Forms.Label lbl_7;
    }
}

