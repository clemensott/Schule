﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Unterricht
{
    class Program
    {
        static void Main(string[] args)
        {
            do
            {
                Console.Clear();

                int zeit, aktuell, i, y = 0, v;

                v = Convert.ToInt32(Console.ReadLine()) % 1000;

                zeit = Convert.ToInt32(DateTime.Now.Millisecond.ToString());

                Console.Clear();

                for (i = 0; i < 20; i = i)
                {
                    aktuell = Convert.ToInt32(DateTime.Now.Millisecond.ToString());
            
                    if (((1000 + zeit + (i - 1) * v) % 1000 > (zeit + i * v) % 1000 && (zeit + i * v) % 1000 < aktuell && (1000 + zeit + (i - 1) * v) % 1000 > aktuell) || ((1000 + zeit + (i - 1) * v) % 1000 < (zeit + i * v) % 1000 && ((zeit + i * v) % 1000 < aktuell || (1000 + zeit + (i - 1) * v) % 1000 > aktuell)))
                    {

                        /*if ((zeit + i * 700) % 1000 < aktuell || (1000 + zeit + (i - 1) * 700) % 1000 > aktuell)
                        {*/
                        i++;

                        Console.WriteLine(i);
                    }
                }

                Console.ReadLine();

            } while (true);
        }
    }
}
