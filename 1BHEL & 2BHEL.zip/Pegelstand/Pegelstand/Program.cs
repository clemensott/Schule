﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pegelstand
{
    class Program
    {
        static void Main(string[] args)
        {
            ConsoleKeyInfo ent;
            
            do
            {
                Console.Clear();

                int t = 7 + 3, w = 4 + 3, y = 0;
                int[,] a = new int[w, t];
                double[,] m = new double[w, t];
                double z = 0;
                Random zz = new Random();

                for (int i = 0; i < w - 3; i++)
                {
                    for (int j = 0; j < t - 3; j++)
                    {
                        a[i, j] = zz.Next(1, 100);
                    }
                }

                //Mittelwert

                for (int i = 0; i < (w - 3); i++)
                {
                    y = 0;

                    for (int j = 0; j < (t - 3); j++)
                    {
                        y += a[i, j];
                    }

                    m[i, 7] = Convert.ToDouble(y) / 7;
                }

                for (int i = 0; i < (t - 3); i++)
                {
                    y = 0;

                    for (int j = 0; j < (w - 3); j++)
                    {
                        y += a[j, i];
                    }

                    m[4, i] = Convert.ToDouble(y) / 4;
                }

                for (int i = 0; i < (w - 3); i++)
                {
                    z += m[i, 7];
                }

                m[4, 7] = z / 4;

                //Maximum

                for (int i = 0; i < w; i++)
                {
                    for (int j = 0; j < t; j++)
                    {
                        if (a[i, j] > a[i, 8])
                        {
                            a[i, 8] = a[i, j];
                        }
                    }
                }

                for (int i = 0; i < t; i++)
                {
                    if (!(i == 7 || i == 9))
                    {
                        for (int j = 0; j < (w - 3); j++)
                        {
                            if (a[j, i] > a[5, i])
                            {
                                a[5, i] = a[j, i];
                            }
                        }
                    }
                }

                //Minimum

                for (int i = 0; i < (w - 3); i++)
                {
                    for (int j = 0; j < (t - 3); j++)
                    {
                        if (a[i, j] < a[i, 9] || j == 0)
                        {
                            a[i, 9] = a[i, j];
                        }
                    }
                }

                for (int i = 0; i < t; i++)
                {
                    if (!(i == 7 || i == 8))
                    {
                        for (int j = 0; j < (w - 3); j++)
                        {
                            if (a[j, i] < a[6, i] || j == 0)
                            {
                                a[6, i] = a[j, i];
                            }
                        }
                    }
                }

                Console.Write("        |  Mo  |  Di  |  Mi  |  Do  |  Fr  |  Sa  |  So  | Mittel| Max | Min");

                for (int i = 0; i < (w - 3); i++)
                {
                    Console.WriteLine("\n------------------------------------------------------------------------------");

                    if (i == 0)
                    {
                        Console.Write("Woche 1");
                    }
                    else if (i == 1)
                    {
                        Console.Write("Woche 2");
                    }
                    else if (i == 2)
                    {
                        Console.Write("Woche 3");
                    }
                    else if (i == 3)
                    {
                        Console.Write("Woche 4");
                    }

                    for (int j = 0; j < t; j++)
                    {
                        if (j == 7)
                        {
                            if (m[i, j] < 10)
                            {
                                Console.Write("|  {0:n3}", m[i, j]);
                            }
                            else
                            {
                                Console.Write("|  {0:n2}", m[i, j]);
                            }
                        }
                        else if (j == 0)
                        {
                            Console.Write(" |{0,6}", a[i, j]);
                        }
                        else
                        {
                            if (j < 7)
                            {
                                Console.Write("|{0,6}", a[i, j]);
                            }
                            else
                            {
                                Console.Write("|{0,5}", a[i, j]);
                            }
                        }
                    }
                }

                for (int i = 4; i < w; i++)
                {
                    Console.WriteLine("\n------------------------------------------------------------------------------");

                    if (i == 4)
                    {
                        Console.Write("Mittel  ");
                    }
                    else if (i == 5)
                    {
                        Console.Write("Maximum ");
                    }
                    else
                    {
                        Console.Write("Minimum ");
                    }

                    for (int j = 0; j < (t - 3); j++)
                    {
                        if (i == 4)
                        {
                            if (m[i, j] < 10)
                            {
                                Console.Write("| {0:n3}", m[i, j]);
                            }
                            else
                            {
                                Console.Write("| {0:n2}", m[i, j]);
                            }
                        }
                        else if (i == 0)
                        {
                            Console.Write("|{0,6}", a[i, j]);
                        }
                        else
                        {
                            Console.Write("|{0,6}", a[i, j]);
                        }
                    }

                    if (i == 4)
                    {
                        if (m[i, 7] < 10)
                        {
                            Console.Write("| {0:n3}|      |", m[i, 7]);
                        }
                        else
                        {
                            Console.Write("|  {0:n2}|     |", m[i, 7]);
                        }
                    }
                    else if (i == 5)
                    {
                        Console.Write("|       |{0,5}|", a[i, 8]);
                    }
                    else
                    {
                        Console.Write("|       |     |{0,5}", a[i, 9]);
                    }
                }

                Console.WriteLine();

                ent = Console.ReadKey(true);

            } while (ent.KeyChar == 'j');
        }
    }
}
