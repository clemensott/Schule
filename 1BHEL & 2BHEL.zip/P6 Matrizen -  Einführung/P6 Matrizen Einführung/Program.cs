﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* 2BHEL 6.10.2014 fertig
 * 
 * Einlesen(zuweisen) und Ausgabe von Matrizen
 * 
 * 
 * 
 * 
 * 
 */

namespace P6_Matrizen_Einführung
{
    class Program
    {
        static void Main(string[] args)
        {   int z=10,s=10;      // z ... Anzahl Zeilen  s... Anzahl der Spalten

        int[,] a = new int[z, s];
            // a[0,0] a[0,1] a[0,2] ... a[0,9]
            // a[1,0] a[1,1] 
            // ..
            // a[9,0]                   a[9,9]
            // Der erste Index beschreibt die zeile, der zweite Index die Spalte

            // Zuweisen von Zufallszahlen an alle Zeile
        Random zz = new Random();
        for(int i = 0; i< z;i++)            // i ... Zeilenindex
            for (int j = 0; j < s; j++)     // j ... Spaltenindex
                a[i, j] = zz.Next(1, 100);


// Ausgabe der Matrix
        for (int i = 0; i < z; i++)
        {
            for (int j = 0; j < s; j++)     // Ausgabe einer Zeile
            {
                Console.Write("{0,4}", a[i, j]);    // {0,4}   ... Es werden 4 Plätze reserviert für die Zahl a[i,j]
            }
            Console.WriteLine();
        }

// Übung: Ausgabe des großen 1x1:
            //121  132              220 
            //132
            //...
            //209                   380 
            //220                   400

            // a[0,0] <-- 11*11
            // a[1,0] <-- 12*11
            // a[0,4] <-- 11*15
            // a[i,j] <-- (i+11)*(j+11)

        Console.WriteLine("\nAusgabe des großen 1*1\n\n");
        for (int i = 0; i < z; i++)            // i ... Zeilenindex
        {
            for (int j = 0; j < s; j++)         // j ... Spaltenindex
            {
                a[i, j] = (i + 11) * (j + 11);
                Console.Write("{0,4}", a[i, j]);
            }
            Console.WriteLine();
        }

// Übung: Wir lesen 2 Zahlen z1 und z2 ein (zwischen 11 und 20), datentyp integer
// und berechnen mit Hilfe der Matrix das Produkt von z1 und z2
        Console.WriteLine(" Bitte 2 Zahlen zwischen 11 und 20 eingeben: ");
        int z1 = Convert.ToInt32( Console.ReadLine());
        int z2 = Convert.ToInt32( Console.ReadLine());

        Console.WriteLine("Das Produkt von {0} und {1} lautet {2}",z1,z2,a[z1-11,z2-11]);


        }
    }
}
