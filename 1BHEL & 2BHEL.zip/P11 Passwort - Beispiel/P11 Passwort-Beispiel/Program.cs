﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P11_Passwort_Beispiel
{
    class Program
    {
        static void Main(string[] args)
        {
            // Erzeuge ein zufälliges Passwort mit 10 Zeichen
            // Mit Großbuchstaben, Kleinbuchstaben, Ziffern und druckbaren Sonderzeichen (z.B: Klammern, $, <, - usw)

                byte[] b = new byte[10];
                Random zuf = new Random();
                bool[] passt = new bool[4];

                do
                {
                    for (int i = 0; i < 10; i++)
                    {
                        b[i] = Convert.ToByte(zuf.Next(33, 123));
                    }

                    for (int j = 0; j < 4; j++)
                    {
                        for (int k = 0; k < 10; k++)
                        {
                            if (j == 0 && ((b[k] < 48 && b[k] > 32) || (b[k] < 65 && b[k] > 57)))
                            {
                                passt[j] = true;
                            }
                            else
                            {
                                passt[j] = false;
                            }

                            if (j == 1 && b[k] >= 65 && b[k] > 32)
                            {
                                passt[j] = true;
                            }
                            else
                            {
                                passt[j] = false;
                            }
                        }
                    }

                } while (passt);
                string s = Encoding.ASCII.GetString(b);
                Console.WriteLine("Der String lautet: {0}", s);

                Console.ReadLine();
                     
        }
    }
}
