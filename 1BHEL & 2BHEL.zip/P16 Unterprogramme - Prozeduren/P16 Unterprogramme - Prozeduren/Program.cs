﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P16_Unterprogramme___Prozeduren
{
    // Prozeduren sind Unterprogramme, die keinen Wert zurückliefern deswegen ist ihr Datentyp void

    // Wie bei den Funktionen kennen auch die Prozeduren nur diejenigen

    class Program
    {
        static public int g1 = 17;  // Globale Variable ist überall bekannt
        static void Main(string[] args)
        {
            int i = 100;   // ist eine lokale Variable, nur im HP bekannt
            int n1 = 1, n2 = 2;
            Console.WriteLine("\nWerte von dem Aufruf von up1");
            Console.WriteLine("n1 = {0} n2 = {1}", n1, n2);
            up1(n1, ref n2);
            Console.WriteLine("\nWerte nach dem Aufruf von up1");
            Console.WriteLine("n1 = {0} n2 = {1}", n1, n2);
            Console.WriteLine("\nLokale Variable i = {0}", 1);
            Console.WriteLine("\nGlobale Variable g1 = {0}", g1);
        }
        static void up1(int n1, ref int n2)
        {
            int i = -100;
            n1 = 10;
            n2 = 20;

            Console.ReadLine();
        }
    }
}
