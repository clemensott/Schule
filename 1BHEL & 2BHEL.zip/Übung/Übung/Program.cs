﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Übung
{
    class Program
    {
        static void Main(string[] args)
        {
            double zahl1 = Double.Epsilon;
            int i = 0;

            while (zahl1 < Double.MaxValue)
            {
                Console.WriteLine("{0,4}: {1}", i, zahl1);

                zahl1 *= 2;
                i++;
            }

            Console.WriteLine("{0,4}: {1}", i, zahl1);
            Console.ReadLine();
        }
    }
}
