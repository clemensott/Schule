﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P12_Buchstabenzähler
{
    class Program
    {
        static void Main(string[] args)
        {
            // Wir geben einen Text ein und zählen wieviel Kleinbuchstaben und wieviel Großbuchstaben und wieviele Ziffern in diesem Text vorkommen

            Console.WriteLine("Gebe Sie einen Text ein: ");
            string text1 = Console.ReadLine();
            Console.
            



            Console.ReadLine();

        }
    }
}
