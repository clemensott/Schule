﻿namespace Filmbibliotek
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_pfad = new System.Windows.Forms.Label();
            this.tbx_pfad = new System.Windows.Forms.TextBox();
            this.lbl_name = new System.Windows.Forms.Label();
            this.lbl_regie = new System.Windows.Forms.Label();
            this.tbx_regie = new System.Windows.Forms.TextBox();
            this.lbl_sterne = new System.Windows.Forms.Label();
            this.tbx_jahr = new System.Windows.Forms.TextBox();
            this.tbx_sterne = new System.Windows.Forms.TextBox();
            this.lbl_genre = new System.Windows.Forms.Label();
            this.lbl_jahr = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tbx_genre = new System.Windows.Forms.TextBox();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.cmb_name = new System.Windows.Forms.ComboBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.btn_vorheriger = new System.Windows.Forms.Button();
            this.btn_nachste = new System.Windows.Forms.Button();
            this.btn_plus = new System.Windows.Forms.Button();
            this.btn_loschen = new System.Windows.Forms.Button();
            this.btn_Save = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.dateiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.neuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.öffnenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.speichernToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.speichernUnterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dateiImEditorÖffnenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.beendenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_pfad
            // 
            this.lbl_pfad.AutoSize = true;
            this.lbl_pfad.Location = new System.Drawing.Point(12, 33);
            this.lbl_pfad.Name = "lbl_pfad";
            this.lbl_pfad.Size = new System.Drawing.Size(29, 13);
            this.lbl_pfad.TabIndex = 0;
            this.lbl_pfad.Text = "Pfad";
            // 
            // tbx_pfad
            // 
            this.tbx_pfad.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbx_pfad.Location = new System.Drawing.Point(15, 57);
            this.tbx_pfad.Name = "tbx_pfad";
            this.tbx_pfad.Size = new System.Drawing.Size(296, 20);
            this.tbx_pfad.TabIndex = 1;
            this.tbx_pfad.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbx_pfad_KeyPress);
            // 
            // lbl_name
            // 
            this.lbl_name.AutoSize = true;
            this.lbl_name.Location = new System.Drawing.Point(12, 100);
            this.lbl_name.Name = "lbl_name";
            this.lbl_name.Size = new System.Drawing.Size(35, 13);
            this.lbl_name.TabIndex = 2;
            this.lbl_name.Text = "Name";
            // 
            // lbl_regie
            // 
            this.lbl_regie.AutoSize = true;
            this.lbl_regie.Location = new System.Drawing.Point(12, 130);
            this.lbl_regie.Name = "lbl_regie";
            this.lbl_regie.Size = new System.Drawing.Size(35, 13);
            this.lbl_regie.TabIndex = 4;
            this.lbl_regie.Text = "Regie";
            // 
            // tbx_regie
            // 
            this.tbx_regie.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbx_regie.Location = new System.Drawing.Point(53, 127);
            this.tbx_regie.Name = "tbx_regie";
            this.tbx_regie.Size = new System.Drawing.Size(258, 20);
            this.tbx_regie.TabIndex = 5;
            // 
            // lbl_sterne
            // 
            this.lbl_sterne.AutoSize = true;
            this.lbl_sterne.Location = new System.Drawing.Point(12, 190);
            this.lbl_sterne.Name = "lbl_sterne";
            this.lbl_sterne.Size = new System.Drawing.Size(38, 13);
            this.lbl_sterne.TabIndex = 6;
            this.lbl_sterne.Text = "Sterne";
            // 
            // tbx_jahr
            // 
            this.tbx_jahr.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbx_jahr.Location = new System.Drawing.Point(53, 157);
            this.tbx_jahr.Name = "tbx_jahr";
            this.tbx_jahr.Size = new System.Drawing.Size(258, 20);
            this.tbx_jahr.TabIndex = 7;
            // 
            // tbx_sterne
            // 
            this.tbx_sterne.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbx_sterne.Location = new System.Drawing.Point(53, 187);
            this.tbx_sterne.Name = "tbx_sterne";
            this.tbx_sterne.Size = new System.Drawing.Size(258, 20);
            this.tbx_sterne.TabIndex = 8;
            // 
            // lbl_genre
            // 
            this.lbl_genre.AutoSize = true;
            this.lbl_genre.Location = new System.Drawing.Point(12, 220);
            this.lbl_genre.Name = "lbl_genre";
            this.lbl_genre.Size = new System.Drawing.Size(36, 13);
            this.lbl_genre.TabIndex = 9;
            this.lbl_genre.Text = "Genre";
            // 
            // lbl_jahr
            // 
            this.lbl_jahr.AutoSize = true;
            this.lbl_jahr.Location = new System.Drawing.Point(12, 160);
            this.lbl_jahr.Name = "lbl_jahr";
            this.lbl_jahr.Size = new System.Drawing.Size(27, 13);
            this.lbl_jahr.TabIndex = 10;
            this.lbl_jahr.Text = "Jahr";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 250);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 13);
            this.label7.TabIndex = 11;
            // 
            // tbx_genre
            // 
            this.tbx_genre.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbx_genre.Location = new System.Drawing.Point(53, 217);
            this.tbx_genre.Name = "tbx_genre";
            this.tbx_genre.Size = new System.Drawing.Size(258, 20);
            this.tbx_genre.TabIndex = 13;
            // 
            // cmb_name
            // 
            this.cmb_name.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmb_name.FormattingEnabled = true;
            this.cmb_name.Location = new System.Drawing.Point(53, 97);
            this.cmb_name.Name = "cmb_name";
            this.cmb_name.Size = new System.Drawing.Size(258, 21);
            this.cmb_name.TabIndex = 2;
            this.cmb_name.SelectedIndexChanged += new System.EventHandler(this.cmb_name_SelectedIndexChanged);
            // 
            // btn_vorheriger
            // 
            this.btn_vorheriger.Location = new System.Drawing.Point(11, 260);
            this.btn_vorheriger.Name = "btn_vorheriger";
            this.btn_vorheriger.Size = new System.Drawing.Size(45, 23);
            this.btn_vorheriger.TabIndex = 19;
            this.btn_vorheriger.Text = "<";
            this.btn_vorheriger.UseVisualStyleBackColor = true;
            this.btn_vorheriger.Click += new System.EventHandler(this.btn_vorheriger_Click);
            // 
            // btn_nachste
            // 
            this.btn_nachste.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_nachste.Location = new System.Drawing.Point(266, 260);
            this.btn_nachste.Name = "btn_nachste";
            this.btn_nachste.Size = new System.Drawing.Size(45, 23);
            this.btn_nachste.TabIndex = 24;
            this.btn_nachste.Text = ">";
            this.btn_nachste.UseVisualStyleBackColor = true;
            this.btn_nachste.Click += new System.EventHandler(this.btn_nachste_Click);
            // 
            // btn_plus
            // 
            this.btn_plus.Location = new System.Drawing.Point(62, 260);
            this.btn_plus.Name = "btn_plus";
            this.btn_plus.Size = new System.Drawing.Size(45, 23);
            this.btn_plus.TabIndex = 20;
            this.btn_plus.Text = "+";
            this.btn_plus.UseVisualStyleBackColor = true;
            this.btn_plus.Click += new System.EventHandler(this.btn_plus_Click);
            // 
            // btn_loschen
            // 
            this.btn_loschen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_loschen.Location = new System.Drawing.Point(215, 260);
            this.btn_loschen.Name = "btn_loschen";
            this.btn_loschen.Size = new System.Drawing.Size(45, 23);
            this.btn_loschen.TabIndex = 23;
            this.btn_loschen.Text = "X";
            this.btn_loschen.UseVisualStyleBackColor = true;
            this.btn_loschen.Click += new System.EventHandler(this.btn_loschen_Click);
            // 
            // btn_Save
            // 
            this.btn_Save.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Save.Location = new System.Drawing.Point(113, 260);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(96, 23);
            this.btn_Save.TabIndex = 21;
            this.btn_Save.Text = "Speichern";
            this.btn_Save.UseVisualStyleBackColor = true;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dateiToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(324, 24);
            this.menuStrip1.TabIndex = 24;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // dateiToolStripMenuItem
            // 
            this.dateiToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.neuToolStripMenuItem,
            this.öffnenToolStripMenuItem,
            this.speichernToolStripMenuItem,
            this.speichernUnterToolStripMenuItem,
            this.dateiImEditorÖffnenToolStripMenuItem,
            this.beendenToolStripMenuItem});
            this.dateiToolStripMenuItem.Name = "dateiToolStripMenuItem";
            this.dateiToolStripMenuItem.Size = new System.Drawing.Size(46, 20);
            this.dateiToolStripMenuItem.Text = "Datei";
            // 
            // neuToolStripMenuItem
            // 
            this.neuToolStripMenuItem.Name = "neuToolStripMenuItem";
            this.neuToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.neuToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.neuToolStripMenuItem.Text = "Neu...";
            this.neuToolStripMenuItem.Click += new System.EventHandler(this.neuToolStripMenuItem_Click);
            // 
            // öffnenToolStripMenuItem
            // 
            this.öffnenToolStripMenuItem.Name = "öffnenToolStripMenuItem";
            this.öffnenToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.öffnenToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.öffnenToolStripMenuItem.Text = "Öffnen...";
            this.öffnenToolStripMenuItem.Click += new System.EventHandler(this.btn_andern_Click);
            // 
            // speichernToolStripMenuItem
            // 
            this.speichernToolStripMenuItem.Name = "speichernToolStripMenuItem";
            this.speichernToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.speichernToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.speichernToolStripMenuItem.Text = "Speichern";
            this.speichernToolStripMenuItem.Click += new System.EventHandler(this.speichernToolStripMenuItem_Click);
            // 
            // speichernUnterToolStripMenuItem
            // 
            this.speichernUnterToolStripMenuItem.Name = "speichernUnterToolStripMenuItem";
            this.speichernUnterToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.speichernUnterToolStripMenuItem.Text = "Speichern unter...";
            this.speichernUnterToolStripMenuItem.Click += new System.EventHandler(this.speichernUnterToolStripMenuItem_Click);
            // 
            // dateiImEditorÖffnenToolStripMenuItem
            // 
            this.dateiImEditorÖffnenToolStripMenuItem.Name = "dateiImEditorÖffnenToolStripMenuItem";
            this.dateiImEditorÖffnenToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.dateiImEditorÖffnenToolStripMenuItem.Text = "Datei im Editor öffnen";
            this.dateiImEditorÖffnenToolStripMenuItem.Click += new System.EventHandler(this.btn_offnen_Click);
            // 
            // beendenToolStripMenuItem
            // 
            this.beendenToolStripMenuItem.Name = "beendenToolStripMenuItem";
            this.beendenToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.beendenToolStripMenuItem.Text = "Beenden";
            this.beendenToolStripMenuItem.Click += new System.EventHandler(this.beendenToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(324, 310);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.btn_loschen);
            this.Controls.Add(this.btn_plus);
            this.Controls.Add(this.btn_nachste);
            this.Controls.Add(this.btn_vorheriger);
            this.Controls.Add(this.cmb_name);
            this.Controls.Add(this.tbx_genre);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lbl_jahr);
            this.Controls.Add(this.lbl_genre);
            this.Controls.Add(this.tbx_sterne);
            this.Controls.Add(this.tbx_jahr);
            this.Controls.Add(this.lbl_sterne);
            this.Controls.Add(this.tbx_regie);
            this.Controls.Add(this.lbl_regie);
            this.Controls.Add(this.lbl_name);
            this.Controls.Add(this.tbx_pfad);
            this.Controls.Add(this.lbl_pfad);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Fimbibliothek";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_pfad;
        private System.Windows.Forms.TextBox tbx_pfad;
        private System.Windows.Forms.Label lbl_name;
        private System.Windows.Forms.Label lbl_regie;
        private System.Windows.Forms.TextBox tbx_regie;
        private System.Windows.Forms.Label lbl_sterne;
        private System.Windows.Forms.TextBox tbx_jahr;
        private System.Windows.Forms.TextBox tbx_sterne;
        private System.Windows.Forms.Label lbl_genre;
        private System.Windows.Forms.Label lbl_jahr;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbx_genre;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.ComboBox cmb_name;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Button btn_vorheriger;
        private System.Windows.Forms.Button btn_nachste;
        private System.Windows.Forms.Button btn_plus;
        private System.Windows.Forms.Button btn_loschen;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem dateiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem neuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem öffnenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem speichernUnterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dateiImEditorÖffnenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem beendenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem speichernToolStripMenuItem;
    }
}

