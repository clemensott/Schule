﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;

namespace Filmbibliotek
{
    public partial class Form1 : Form
    {
        string[,] filme_data = new string[1001, 5];
        int[,] filme_nrn = new int[1001, 2];
        int filmnr = 0, cmb_nr = -1;
        bool cmb_name_ab = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void btn_offnen_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(System.Environment.SystemDirectory + "\\notepad.exe", tbx_pfad.Text);
        }

        private static void OpenExplorer(string path)
        {
            if (Directory.Exists(path))
                Process.Start("notepad.exe", path);
        }

        private void btn_andern_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                tbx_pfad.Text = openFileDialog1.FileName;

                lesen();
            }
        }

        private void cmb_name_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!cmb_name_ab)
            {
                int count = cmb_name.Items.Count;
                bool passt = false;

                for (int i = 0; i < count; i++)
                {
                    cmb_name.Items.RemoveAt(0);

                    if ((cmb_name.Text == "" || i + 1 == count) && !passt)
                    {
                        cmb_nr = i;
                        passt = true;
                    }
                }

                cmb_name.Items.Clear();

                for (int i = 0; i < count; i++)
                { 
                    for (int j = 1; true; j++)
                    {
                        if (i == filme_nrn[j, 1])
                        {
                            cmb_name.Items.Add(filme_data[j, 0]);
                            break;
                        }
                    }
                }

                for (int i = 0; i < filme_data.GetLength(0); i++)
                {
                    if (filme_nrn[i, 1] == cmb_nr)
                    {
                        filmnr = i;
                        break;
                    }
                }

                anzeigen();
            }

            cmb_name_ab = false;
        }

        private void lesen()
        {
            for (int i = 0; i < filme_data.GetLength(0); i++)
            {
                for (int j = 0; j < filme_data.GetLength(1); j++)
                {
                    filme_data[i, j] = "";
                }

                filme_nrn[i, 0] = 0;
                filme_nrn[i, 1] = -1;
            }

            bool fehler = false;
            string[] text_o = new string[1];

            try
            {
                StreamReader text_dokument = new System.IO.StreamReader(tbx_pfad.Text);

                text_o[0] = text_dokument.ReadLine();

                for (int i = 1; text_o[i - 1] != null; i++)
                {
                    Array.Resize(ref text_o, text_o.Length + 1);
                    text_o[i] = text_dokument.ReadLine();
                }

                text_dokument.Close();
            }
            catch
            {
                fehler = true;
                MessageBox.Show("Datei exestiert nicht oder kann nicht geöffnet werden", "Fehler");
            }

            if (!fehler)
            {
                cmb_name.Items.Clear();

                try
                {
                    for (int i = 0; true; i++)
                    {
                        string cache, zeile = text_o[i * 6];

                        cache = zeile.Remove(0, 6);
                        cache = cache.Remove(cache.Length - 1, 1);

                        if (Convert.ToInt32(cache) <= 1000)
                        {
                            int nr = Convert.ToInt32(cache);

                            filme_data[nr, 0] = text_o[1 + 6 * i].Remove(0, 6);
                            filme_data[nr, 1] = text_o[2 + 6 * i].Remove(0, 6);
                            filme_data[nr, 2] = text_o[3 + 6 * i].Remove(0, 5);
                            filme_data[nr, 3] = text_o[4 + 6 * i].Remove(0, 7);
                            filme_data[nr, 4] = text_o[5 + 6 * i].Remove(0, 6);
                            filme_nrn[nr, 0] = 1;

                            cmb_name.Items.Add(filme_data[nr, 0]);
                            filme_nrn[nr, 1] = i;
                        }
                    }
                }
                catch { }
            }

            filmnr = 0;
            cmb_nr = -1;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            for (int i = 1; i < filme_data.GetLength(0); i++)
            {
                filme_nrn[i, 0] = 0;
                filme_nrn[i, 1] = -1;
            }
        }

        private void anzeigen()
        {
            cmb_name_ab = true;

            cmb_name.Text = filme_data[filmnr, 0];
            tbx_regie.Text = filme_data[filmnr, 1];
            tbx_jahr.Text = filme_data[filmnr, 2];
            tbx_sterne.Text = filme_data[filmnr, 3];
            tbx_genre.Text = filme_data[filmnr, 4];
        }

        private void btn_nachste_Click(object sender, EventArgs e)
        {
            bool passt = false;

            for (int i = filmnr + 1; !passt; i = (i + 1) % 1000)
            {
                if (filme_nrn[i, 0] == 1)
                {
                    passt = true;
                    filmnr = i;
                }
            }

            cmb_nr = filme_nrn[filmnr, 1];

            anzeigen();
        }

        private void btn_vorheriger_Click(object sender, EventArgs e)
        {
            vorherige();
        }

        private void vorherige()
        {
            bool passt = false;

            for (int i = filmnr - 1; !passt; i--)
            {
                if (i < 1)
                {
                    i = 1000;
                }

                if (filme_nrn[i, 0] == 1)
                {
                    passt = true;
                    filmnr = i;
                }
            }

            cmb_nr = filme_nrn[filmnr, 1];

            anzeigen();
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            speichern();
        }

        private void speichern()
        {
            string[] aus = new string[6];

            for (int i = 1; i < 1000; i++)
            {
                if (filme_nrn[i, 0] == 0 && filmnr == 0 && cmb_nr == -1)
                {
                    filme_nrn[i, 0] = 1;
                    filme_data[i, 0] = cmb_name.Text;
                    filme_data[i, 1] = tbx_regie.Text;
                    filme_data[i, 2] = tbx_jahr.Text;
                    filme_data[i, 3] = tbx_sterne.Text;
                    filme_data[i, 4] = tbx_genre.Text;

                    break;
                }
                else if (filmnr > 0)
                {
                    filme_data[filmnr, 0] = cmb_name.Text;
                    filme_data[filmnr, 1] = tbx_regie.Text;
                    filme_data[filmnr, 2] = tbx_jahr.Text;
                    filme_data[filmnr, 3] = tbx_sterne.Text;
                    filme_data[filmnr, 4] = tbx_genre.Text;

                    break;
                }
            }

            int j = 0;

            for (int i = 1; i < 1000; i++)
            {
                if (filme_nrn[i, 0] == 1)
                {
                    aus[j * 6] = "[Film " + Convert.ToString(i) + "]";
                    aus[1 + j * 6] = "Titel=" + filme_data[i, 0];
                    aus[2 + j * 6] = "Regie=" + filme_data[i, 1];
                    aus[3 + j * 6] = "Jahr=" + filme_data[i, 2];
                    aus[4 + j * 6] = "Sterne=" + filme_data[i, 3];
                    aus[5 + j * 6] = "Genre=" + filme_data[i, 4];

                    j++;

                    Array.Resize(ref aus, aus.Length + 6);
                }
            }

            try
            {
                StreamWriter schreiben = new StreamWriter(@tbx_pfad.Text, false);

                for (int i = 0; aus[i] != null; i++)
                {
                    schreiben.WriteLine(aus[i]);
                }

                schreiben.Close();

                lesen();
            }
            catch
            {
                MessageBox.Show("Kein Speicherort gewählt", "Fehler");
            }
        }

        private void btn_loschen_Click(object sender, EventArgs e)
        {
            filme_nrn[filmnr, 0] = 0;

            for (int i = 1; i < filme_data.GetLength(0); i++)
            {
                if (filme_nrn[i, 1] > cmb_nr)
                {
                    filme_nrn[i, 1] = filme_nrn[i, 1] - 1;
                }
            }

            if (cmb_name.Items.Count > 1)
            {
                cmb_name.Items.RemoveAt(cmb_nr);
                vorherige();
            }
            else
            {
                tbx_genre.Text = "";
                tbx_jahr.Text = "";
                tbx_regie.Text = "";
                tbx_sterne.Text = "";

                if (cmb_name.Items.Count == 1)
                {
                    cmb_name.Items.RemoveAt(0);
                }

                cmb_name_ab = true;
                cmb_name.Text = "";

                cmb_nr = -1;
                filmnr = 0;
            }

            
        }

        private void btn_plus_Click(object sender, EventArgs e)
        {
            filmnr = 0;
            cmb_nr = -1;

            cmb_name_ab = true;
            cmb_name.Text = "";
            tbx_genre.Text = "";
            tbx_jahr.Text = "";
            tbx_regie.Text = "";
            tbx_sterne.Text = "";
        }

        private void neuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cmb_name_ab = true;
            cmb_name.Items.Clear();
            cmb_name.Text = "";

            tbx_genre.Text = "";
            tbx_jahr.Text = "";
            tbx_pfad.Text = "";
            tbx_regie.Text = "";
            tbx_sterne.Text = "";

            for (int i = 0; i < filme_data.GetLength(0); i++)
            {
                filme_nrn[i, 0] = 0;
            }

            filmnr = 0;
            cmb_nr = -1;
        }

        private void speichernUnterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                tbx_pfad.Text = openFileDialog1.FileName;

                speichern();
            }
        }

        private void beendenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void speichernToolStripMenuItem_Click(object sender, EventArgs e)
        {
            speichern();
        }

        private void tbx_pfad_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                lesen();
            }
        }
    }
}
