﻿namespace Timer
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbl_uhr = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lbl_zeit = new System.Windows.Forms.Label();
            this.btn_start = new System.Windows.Forms.Button();
            this.btn_neu = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_uhr
            // 
            this.lbl_uhr.AutoSize = true;
            this.lbl_uhr.Font = new System.Drawing.Font("Comic Sans MS", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_uhr.Location = new System.Drawing.Point(9, 9);
            this.lbl_uhr.Name = "lbl_uhr";
            this.lbl_uhr.Size = new System.Drawing.Size(310, 90);
            this.lbl_uhr.TabIndex = 0;
            this.lbl_uhr.Text = "00:00:00";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lbl_zeit
            // 
            this.lbl_zeit.Font = new System.Drawing.Font("Comic Sans MS", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_zeit.Location = new System.Drawing.Point(12, 117);
            this.lbl_zeit.Name = "lbl_zeit";
            this.lbl_zeit.Size = new System.Drawing.Size(310, 90);
            this.lbl_zeit.TabIndex = 0;
            this.lbl_zeit.Text = "0";
            this.lbl_zeit.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // btn_start
            // 
            this.btn_start.Location = new System.Drawing.Point(46, 237);
            this.btn_start.Name = "btn_start";
            this.btn_start.Size = new System.Drawing.Size(75, 23);
            this.btn_start.TabIndex = 1;
            this.btn_start.Text = "Start";
            this.btn_start.UseVisualStyleBackColor = true;
            this.btn_start.Click += new System.EventHandler(this.btn_start_Click);
            // 
            // btn_neu
            // 
            this.btn_neu.Location = new System.Drawing.Point(203, 237);
            this.btn_neu.Name = "btn_neu";
            this.btn_neu.Size = new System.Drawing.Size(88, 23);
            this.btn_neu.TabIndex = 2;
            this.btn_neu.Text = "Zurücksetzten";
            this.btn_neu.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(331, 284);
            this.Controls.Add(this.btn_neu);
            this.Controls.Add(this.btn_start);
            this.Controls.Add(this.lbl_zeit);
            this.Controls.Add(this.lbl_uhr);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Uhr";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_uhr;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lbl_zeit;
        private System.Windows.Forms.Button btn_start;
        private System.Windows.Forms.Button btn_neu;
    }
}

