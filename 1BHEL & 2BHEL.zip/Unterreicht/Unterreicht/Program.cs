﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Unterreicht
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] texte = new string[2];
            bool gleich;
            int max;

            for (int i = 0; i < 2; i++)
            {
                Console.WriteLine("Text {0} eingeben:", i);
                texte[i] = Console.ReadLine();

                Console.WriteLine();
            }

            if (texte[0].Length >= texte[1].Length)
            {
                max = texte[0].Length;
            }
            else
            {
                max = texte[1].Length;
            }

            char[,] zeichen = new char[2,texte[1].Length];

            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < texte[i].Length; j++)
                {
                    zeichen[i, j] = Convert.ToChar(texte[j]);
                }
            }

            gleich = gleich_prufen(zeichen);

            if (gleich)
            {
                Console.WriteLine("Wahr");
            }
            else
            {
                Console.WriteLine("Falsch");
            }

            Console.ReadLine();
        }

        static Boolean gleich_prufen(char[,] zeichenfolge)
        {
            bool passt = false;

            for (int i = 0; i < zeichenfolge.GetLength(0); i++)
            {
                bool runde = false;

                for (int j = 0; j < zeichenfolge.GetLength(1); j++)
                {
                    if (zeichenfolge[0, j] == zeichenfolge[1, i])
                    {
                        runde = true;
                    }
                }

                if (!runde)
                {
                    passt = false;
                }
            }

            for (int i = 0; i < zeichenfolge.GetLength(1) && passt; i++)
            {
                bool runde = false;

                for (int j = 0; j < zeichenfolge.GetLength(0); j++)
                {
                    if (zeichenfolge[0, j] == zeichenfolge[1, i])
                    {
                        runde = true;
                    }
                }

                if (!runde)
                {
                    passt = false;
                }
            }

            return passt;
        }

    }
}
