﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace P18_Files___Felder___Prozeduren
{
    // Wir lesen ein im Unterprogramm eingabe Integerwerte von einer Datei ein

    // Im Unterprogramm Berechnung ermitteln wir den kleinsten Wert dieses Feldes 

    // Im Unterprogramm ausgabe schreiben wir das Fels mit dem kleinsten Wert auf eine Datei

    class Program
    {
        static void Main(string[] args)
        {
            int[] a = new int[20]; // Werte die auf der Datei stehen
            int klein, na = 0;                // Anzahl der Werte von a

            // Auf der Datei a.txt steht der Wert von a
            string filename_a = @"C:\Users\Clemens\Documents\Visual Studio 2012\Projects\P18 Files - Felder - Prozeduren\a.txt";

            klein = einlesen(a, ref na, filename_a);
            Console.ReadLine();

            // Wir berechnen nun die kleinste Zahl von a und geben diese auch im Unterprogramm ausgabe aus
            

            ausgabe(a, na, klein);

        }
        /* Unterprogramme einlesen:
         *    Sinn und Zweck:    Einlesen eines Feldes von einer Datei
         *    
         *  Eingabe:    filename   .... Name der Datei
         *  
         * Ausgabe:     a          .... Das Feld a mit den Werten der Datei
         *              n          .... Anzahl der Elemente von a
         */

        static int einlesen(int[] a, ref int n, string filename)
        {
            string[] zahlen;               // Enthält die zahl des Feldes als string
            n = 0;                         // Anzahl der Elemente von a
            string line;                   // Enthält eine Zeile der Datei
            int kleinste = 0;

            // Wir öffnen die datei mit dem StreamReader
            System.IO.StreamReader file = new System.IO.StreamReader(filename);

            // Solange das Dateiende nicht erreicht wurde, lesen wir Zeile für Zeile 
            // Die Zahlen in der Datei sind durch EIN Leerzeichen voneinander getrennt
            while ((line = file.ReadLine()) != null)
            {
                // Die Zeile (line) wird nun aufgetrennt in die Zahlen und auf das Stringfeld zahlen geschrieben
                zahlen = line.Split(' ');

                // Nun konvertieren wir das Stringfeld zahlen in das Integerfeld a
                foreach (string s in zahlen)
                {
                    a[n] = Convert.ToInt32(s);

                    if (n == 0)
                    {
                        kleinste = a[n];
                    }
                    else if (a[n] < kleinste)
                    {
                        kleinste = a[n];
                    }

                    n++;
                }
                // Zur Kontrolle geben wir das Feld a aus
                Console.WriteLine("Das Feld: ");
                for (int i = 0; i < n; i++) Console.Write("{0}", a[i]);
            }

            return kleinste;
        }
         /* Unterprogramme einlesen:
         *    Sinn und Zweck:    Ausgabe eines Feldes auf eine Datei
         *    
         *  Eingabe:    filename   .... Name der Datei
         *  
         * Input:       a          .... Das Feld a mit den Werten der Datei
         *              n          .... Anzahl der Elemente von a
         * Output:      keine Outputparameter
         */

        static void ausgabe(int[] a, int n, int klein)
        {
            // Ausgabe auf eine Datei mit dem StreamWriter
            // Wir hängen die Ausgabe auf die Datei an, falls sie Datei existiert
            using (StreamWriter sw = File.AppendText("a.out"))
            {
                sw.WriteLine("Das Feld: ");
                for (int i = 0; i < n; i++) sw.Write("{0}", a[i]);
                Console.Write("\nKleinste Zahl von Feld a: {0}", klein);
            }
            Console.ReadLine();
        }
      }
    }

