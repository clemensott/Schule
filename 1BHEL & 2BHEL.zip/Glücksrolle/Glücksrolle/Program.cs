﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Glücksrolle
{
    class Program
    {
        static void Main(string[] args)
        {// Projekt Spielautomat
            // --------------------
            // 4 Rollen
            // Jede Rolle läuft von 0 bis 9
            // Beim 1. Tastendruck stoppt die 1. Rolle
            // Beim 2. Tastendruck stoppt die 2. Rolle
            // Beim 3. Tastendruck stoppt die 3. Rolle
            // Beim 4. Tastendruck stoppt die 4. Rolle

            // Auswertung wie viele gestoppte Rollen gleich sind

            ConsoleKeyInfo eins;
            int[] zahl = new int[4]{0,0,0,0};
            int d = 0, g = 0;

            do
            {
                if (zahl[3] == 9)
                {
                    for (int i = d; i < 4; i++)
                    {
                        zahl[i] = 0;
                    }
                }
                else
                {
                    for (int i = d; i < 4; i++)
                    {
                        zahl[i]++;
                    }
                }

                if (Console.KeyAvailable)
                {
                    eins = Console.ReadKey(true);
                    //if (eins.KeyChar == 'x')
                    //ende = true;

                    d++;

                    /*eins = Console.ReadKey(true);
                    if (eins.KeyChar == 'x')
                        ende = true;*/
                }

                Console.WriteLine("{0}  {1}  {2}  {3}", zahl[0], zahl[1], zahl[2], zahl[3]);

            }
            while (d != 4);

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    if (zahl[i] == zahl[j])
                    {
                        g++;
                    }
                }

                g--;
            }

            Console.WriteLine("\nDie Zahlen sind:\n{0}  {1}  {2}  {3}\n\nEs sind {4} Zahlen gleich", zahl[0], zahl[1], zahl[2], zahl[3], g);

            Console.ReadLine();

            
        }
    }
}
