﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ü10_Strings___Einführung
{
    class Program
    {
        static void Main(string[] args)
        {
            // Ein Character kann ein beliebiges Zeichen speichern
            // Ein Character benötigt ein Byte Speicherplatz
            // Ein Character wird mit dem ASCII Code gespeichert
            // (Beispiel: 'A' = 65, 'B' = 66, .... 'a' = 97, 'b' = 98;....)

            // Intern wird ein Character als Zahl gespeichert und kann auch als Zahl ausgegeben werden, aber auch als Zeichen

            // Ein String (Zeichenkette) ist ein Feld von Characters
            string text1, text2, text3;
            int i;
            char c1 = 'a';      // Zuweisung eines Zeichens auf eine Charactervariable
            Console.WriteLine("Char a: {0}", c1);

            // Eingabe eimes Textes von der Console
            Console.WriteLine("Bitte einen Text eingeben: ");
            text1 = Console.ReadLine();
            Console.WriteLine("\n\n Ausgabe des Textes, Version 1");
            Console.WriteLine("der eingegebene Text lautet: {0}", text1);

            // Ausgabe des Textes als Feld von Characters
            Console.WriteLine("\n\n Ausgabe des Textes als Feld von Characters: \n");
            for (i = 0; i < text1.Length; i++)
            {
                Console.WriteLine("{0}", text1[i]);
            }

            // Wir geben den Text in umgekehrter Reihenfolge aus
            Console.WriteLine("\n\n Der Text umgedreht: \n");
            for (i = 0; i < text1.Length; i++)
            {
                Console.WriteLine("{0}", text1[text1.Length - i - 1]);
            }

            Console.WriteLine("\n Bitte noch einen Text eingeben: ");
            text2 = Console.ReadLine();

            // Anhängen eines Textes an einen anderen (Verkettung = concatenation) 
            text3 = text1 + text2;
            Console.WriteLine("\n\n Textverkettung : Text1 + Text2: {0}", text3);

            // Abfrage auf Gleichheit wie bei Integerzahlen mit 2 "=="
            if (text1 == text2)
                Console.WriteLine("Text1 und Text2 sind gleich");
            else
                Console.WriteLine("Text1 und Text2 sind ungleich");

            // Suchen eines Characters in einem String
            i = text1.IndexOf('e');
            if (i >= 0)
                Console.WriteLine("Der Buchstabe e kommt an der {0}.ten Stelle vor", i + 1);
            else
                Console.WriteLine("Der Buchstabe e kommt in text1 nicht vor");

            // Umwandlung eines Characters in eine Integerzahl
            i = (int)text1[0];   // (int) Castoperator ... Umwandlung von Char in Integer
            Console.WriteLine("Der ASCII Code von {0} lautet: {1}", text1[0], 1);

            // Umwandlung einer Zahl in einen String
            i = 1423;
            string c = Convert.ToString(i);
            Console.WriteLine("Die Zahl {0} und der entsprechende String: {1}", i, c);

            // Einfügen eines Zeichens in einen String
            c = c.Insert(1, "X");
            Console.WriteLine("Der string mit einfügentem X: {0}", c);

            // Schreibe einen ASCII Code auf einen String
            byte[] = new byte[10];  // Ein byte kann nur Zahlen von 0 bis 255 speichern
            B[0] = 65; B[1] = 66; B[2] = 97;
            string s1 = Encoding.ASCII.GetString(B);  // erzeugt einen String ABa
            Console.WriteLine("Ein String mit ASCII Code erzeugt: {0}", s1);

            Console.ReadLine();
        }
    }
}
