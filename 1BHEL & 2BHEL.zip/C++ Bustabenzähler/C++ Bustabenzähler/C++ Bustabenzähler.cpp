// C++ Bustabenz�hler.cpp : Definiert den Einstiegspunkt f�r die Konsolenanwendung.
//

#include "stdafx.h"

void main()
{
	char text[1000];
	int bust[128];

	gets(text);
	printf("\n");

	for (int i = 0; text[i]!='\0'; i++)
	{
		bust[text[i]]++;
	}

	for (int i = 0; i < 128; i++)
	{
		if(bust[i]>bust[0])
		{
			printf("'%c': %d\n",i,bust[i]-bust[0]);
		}
	}

	printf("\n");
}

