﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Wörter_zählen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_zählen_Click(object sender, EventArgs e)
        {
            bool wort = false;
            int i = 0;

            char[] a = tbx_Text.Text.ToCharArray();

            for (int j = 0; j < a.Length; j++)
            {
                if (!wort)
                {
                    if (a[j] != Convert.ToChar(" ") && j + 1 == a.Length)
                    {
                        wort = true;

                        i++;
                    }
                    else if (a[j] != Convert.ToChar(" ") && j + 1 < a.Length)
                    {
                        if (a[j] == Convert.ToChar("\r") && a[j + 1] == Convert.ToChar("\n"))
                        {
                            j++;
                        }
                        else
                        {
                            wort = true;

                            i++;
                        }
                    }
                }
                else
                {
                    if (a[j] == Convert.ToChar(" "))
                    {
                        wort = false;
                    }
                    else if (j + 1 < a.Length)
                    {
                        if (a[j] == Convert.ToChar("\r") && a[j + 1] == Convert.ToChar("\n"))
                        {
                            j++;

                            wort = false;
                        }
                    }
                }
            }

            MessageBox.Show("Es sind " + i + " Wörter","Wörter");
        }
    }
}
