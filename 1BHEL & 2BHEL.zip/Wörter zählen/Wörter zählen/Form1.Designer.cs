﻿namespace Wörter_zählen
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbx_Text = new System.Windows.Forms.TextBox();
            this.btn_zählen = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tbx_Text
            // 
            this.tbx_Text.Location = new System.Drawing.Point(29, 27);
            this.tbx_Text.Multiline = true;
            this.tbx_Text.Name = "tbx_Text";
            this.tbx_Text.Size = new System.Drawing.Size(228, 83);
            this.tbx_Text.TabIndex = 0;
            this.tbx_Text.Text = "Text";
            // 
            // btn_zählen
            // 
            this.btn_zählen.Location = new System.Drawing.Point(29, 157);
            this.btn_zählen.Name = "btn_zählen";
            this.btn_zählen.Size = new System.Drawing.Size(93, 23);
            this.btn_zählen.TabIndex = 1;
            this.btn_zählen.Text = "Wörter zählen";
            this.btn_zählen.UseVisualStyleBackColor = true;
            this.btn_zählen.Click += new System.EventHandler(this.btn_zählen_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.btn_zählen);
            this.Controls.Add(this.tbx_Text);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbx_Text;
        private System.Windows.Forms.Button btn_zählen;
    }
}

