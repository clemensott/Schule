﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Schleifenbeispiele
{
    class Program
    {
        static void Main(string[] args)
        {
            // Projekt Spielautomat
            // --------------------
            // 4 Rollen
            // Jede Rolle läuft von 0 bis 9
            // Beim 1. Tastendruck stoppt die 1. Rolle
            // Beim 2. Tastendruck stoppt die 2. Rolle
            // Beim 3. Tastendruck stoppt die 3. Rolle
            // Beim 4. Tastendruck stoppt die 4. Rolle

            // Auswertung wie viele gestoppte Rollen gleich sind

            ConsoleKeyInfo eins, zwei, drei, vier;
            int[] zahl = new int[4];
            int d = 0;

            do
            {
                if (Console.KeyAvailable)
                {
                    d++;

                    /*eins = Console.ReadKey(true);
                    if (eins.KeyChar == 'x')
                        ende = true;*/
                }

                if (zahl[3] == 9)
                {
                    for (int i = d; i < 4; i++)
                    {
                        zahl[i] = 0;
                    }
                }
                else
                {
                    for (int i = d; i < 4; i++)
                    {
                        zahl[i]++;
                    }
                }

                Console.WriteLine("{0}   {1}  {2}  {3}", zahl[0], zahl[1], zahl[2], zahl[3]);

            }
            while (d == 4);




        }
    }
}
