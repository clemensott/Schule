﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* Buch Seite 30 Übung 40
 * 
 * 2BHEL 25.09.2014 nicht fertig, wird am nächsten Do 2.10. fertig macht
 * 
 * 1) Man lese 2 n (max 10) dimensionale Vektoren ein auf die Felder v1 und v2 (double)
 * 
 * 2) Man berechne Summe der Vektoren
 * 3) man berechne die Differenz
 * 4) Man berechne das Skalarprodukt
 * 
 * Bsp:   v1=(2,5,6)   v2=(3,1,2)
 *          
 *      vsumme=(5,6,7)
 *      vdifferenz = (-1,4,4)
 *      skalarprodukt= 2*3 + 5*1 + 6*2 = 23
 * 
 */

namespace P3_Vektoren
{
    class Program
    {
        static void Main(string[] args)
        {
            int n;
            Console.Write("Bitte Dimension eingeben: ");
            n = Convert.ToInt32(Console.ReadLine());

            double[] v1 = new double[n];
            double[] v2 = new double[n];
            double[] vs = new double[n];        // vs ... VektorSumme
            double[] vd = new double[n];        // vd ... VektorDifferenz
            double vp = 0;                      // vp ... Vektorprodukt


            for (int i = 0; i < n; i++)
            {
                Console.Write("Bitte Wert fuer vektor 1 eingeben: ");
                v1[i]= Convert.ToInt32(Console.ReadLine()); 
            }

            for (int i = 0; i < n; i++)
			{
                Console.Write("Bitte Wert fuer vektor 2 eingeben: ");
                 v2[i]=Convert.ToInt32(Console.ReadLine());
			}

            for (int i = 0; i < n; i++)
            {
               
                vs[i] = v1[i] + v2[i];
                
                vd[i] = v1[i] - v2[i];
                vp = vp + v1[i] * v2[i];
                
            }
            Console.WriteLine("Vektorensumme: \n");
            for (int i = 0; i < n; i++)
            {
                Console.Write(" {0} ", vs[i]);
            }
            Console.WriteLine();

            Console.WriteLine("Vektorendifferenz: \n");
            for (int i = 0; i < n; i++)
            {
                Console.Write(" {0} ", vd[i]);
            }
            Console.WriteLine();

            Console.WriteLine("Vektorprodukt:  {0} ", vp);
            

            


           // Console.WriteLine("Summe =  {0} ", vs[i]);
           // Console.WriteLine("Differenz =  {0} ", vd[i]);
            Console.ReadLine();

            


        }
    }
}
