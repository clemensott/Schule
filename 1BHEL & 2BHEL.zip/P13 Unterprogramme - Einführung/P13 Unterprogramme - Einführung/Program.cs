﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P13_Unterprogramme___Einführung
{
    class Program
    {
        static void Main(string[] args)
        {
            // Unetprogramme 

            // Es gibt 2 Arten von Unterprogrammen: Funktionen und Prozeduren

            // Funktionen liefern immer einen Wert zurück

            // Wir schreiben eine Funktion, die das Doppelte einer Zahl zurücjgibt




            int eingabe, ergebnis;
            Console.WriteLine("Bitte eine Zahl eingeben: ");
            eingabe = Convert.ToInt32(Console.ReadLine());

            // Aufruf der Funktion MalZwei, der Funktionswert wird an die Variable ergebnis überwiesen
            ergebnis = MalZwei(eingabe);
            Console.WriteLine("Das Doppelte von {0} ist {1}\n", eingabe, ergebnis);

        }

        // static   ... jede Funktion beginnt mit static 
        // int      ... der Rückgabewert der Funktion ist vom Typ integer
        // MalZwei  ... der Nenner der Funktion# 
        // int zahl ... zahl ist das Argument der Funktion
        //              Der Wert der Variable eingabe wir auf zahl überwiesen
        // Mit return 2*zahl wird der Funktionswert berechnet unf im Hp auf die Variable ergebnis überwiesen

        static int MalZwei(int zahl)
        {
            return 2 * zahl;
        }
    }
}
