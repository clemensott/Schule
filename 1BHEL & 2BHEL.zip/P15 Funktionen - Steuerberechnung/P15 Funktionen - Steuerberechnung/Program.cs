﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P15_Funktionen___Steuerberechnung
{
    class Program
    {
        static void Main(string[] args)
        {
            // Wir berechnen die Steuer, abhängig vom Verdienst 
            // Eingabe:          die Variable verdienst

            // Ausgabe:          die Lohnsteuer


            // Wir programmieren eine Funktion Steuer vom Typ double


            // static double Steuer(double verdienst)

            // Eingabe verdienst

            double verdienst, steuern;

            // Einlesen verdienst
            Console.WriteLine("Bitte geben Sie Ihren Verdienst ein: ");
            verdienst = Convert.ToDouble(Console.ReadLine());

            //Aufruf der Funktion und Überweisung des Funktionswertes auf steuern
            steuern = berechne_steuern(verdienst);

            //Ausgabe 
            Console.WriteLine("Sie verdienen {0} Euro und zahlen {1} steuern", verdienst, steuern);

        }

        static double berechne_steuern(double verdienst)
        {
            double steuer = 0.0;
            if (verdienst <= 11000)
            {
                steuer = 0;
            }
            else if (verdienst <= 25000)
            {
                steuer = (verdienst - 11000) * 0.365;
            }
            else if (verdienst <= 60000)
            {
                steuer = 0.365 * (25000 - 11000) + (verdienst - 25000) * 0.43;
            }
            else
            {
                steuer = (25000 - 11000) * 0.365 + (60000 - 25000) * 0.43 + (verdienst - 60000) * 0.5;
            }

            return steuer;

        }
    }
}
