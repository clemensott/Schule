﻿using System;
using System.Windows.Forms;

namespace ClemensOtt
{
    class Konto
    {
        private double kontostand;
        private string pin;

        public double Kontostand
        {
            get { return kontostand; }
            set
            {
                if (value < -500)
                {
                    MessageBox.Show("Heute keine Abhebung mehr möglich!");
                    Application.Exit();
                }
                else if (Math.Abs(kontostand - value) > 400)
                {
                    MessageBox.Show("Eingegebener Betrag zu hoch -  Neueingabe notwendig");
                    return;
                }

                kontostand = value;
            }
        }

        public string PIN
        {
            get { return pin; }
            set
            {
                int code;
                if (value.Length == 4 && int.TryParse(value, out code))
                {
                    pin = value;
                }
            }
        }

        public Konto(string pin, double kontostand)
        {
            this.kontostand = kontostand;
            PIN = pin;
        }
    }
}
