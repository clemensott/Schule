﻿using System;
using System.Windows.Forms;

namespace ClemensOtt
{
    class Bankomat
    {
        private Konto konto;

        public Bankomat()
        {
            konto = new Konto("6285", 1000);
        }

        public int Abheben(int betrag)
        {
            double startStand = GetKontostand();
            konto.Kontostand -= Convert.ToDouble(betrag);

            if (GetKontostand() < startStand)
            {
                return betrag;
            }

            return 0;
        }

        public void Laden(int betrag)
        {
            konto.Kontostand += Convert.ToDouble(betrag);
        }

        public bool CheckPinCode(string pin)
        {
            bool fit = konto.PIN == pin;

            if (!fit)
            {
                MessageBox.Show("Eingegebener Pin-Code falsch - Neueingabe notwendig");
            }

            return fit;
        }

        public double GetKontostand()
        {
            return konto.Kontostand;
        }
    }
}
