﻿using System;
using System.Windows.Forms;

namespace ClemensOtt
{
    public partial class Form1 : Form
    {
        private Bankomat bankomat;

        public Form1()
        {
            InitializeComponent();
            bankomat = new Bankomat();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Bitte Pin-Code und den Behebungsbetrag (max. 400€) eingeben");
        }

        private void btnAbheben_Click(object sender, EventArgs e)
        {
            int betrag;

            if (int.TryParse(tbxBetrag.Text, out betrag) && bankomat.CheckPinCode(tbxPinCode.Text))
            {
                if (bankomat.Abheben(betrag) > 0)
                {
                    NeuenKontostandzeigen();
                }
            }
        }

        private void btnEinzahlen_Click(object sender, EventArgs e)
        {
            int betrag;

            if (int.TryParse(tbxBetrag.Text, out betrag) && bankomat.CheckPinCode(tbxPinCode.Text))
            {
                bankomat.Laden(betrag);
                NeuenKontostandzeigen();
            }
        }

        private void NeuenKontostandzeigen()
        {
            lbxInfo.Items.Add("Der neue Kontostand beträgt: € " + bankomat.GetKontostand());
        }
    }
}
