﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


/* 1)  Berechne Maximum, Minimum und die Stellen an denen die Extremwerte vorkommen
 * 
 * 
 * 2)  Berechne die Summe und den Mittelwert
 * 
 * 3)  Diejenigen Werte, die kleiner sind als der Mittelwert, werden auf ein Feld a gespeichert
 *     Diejenigen Werte, die größer sind als der Mittelwert, werden auf ein Feld a gespeichert
 *     
 *          Bsp: Feld p:   23  34   3   35  23 29  8  (Summe =145,  mittelwert=20,7)
 *          Feld A:        3   8
 *          Feld B:        23 24  35 27 23
 *
 * 4) Wir lesen eine Zahl ein und bestimmen, wie oft diese im Feld p vorkommt
 *          Bsp:    Wenn 23 eingelesen wird:
 *                   Ausgabe: Die Zahl 23 kommt 2 Mal vor
 * 
 * 
*/
namespace P2_Niederschlag_Felder
{
    class Program
    {
        static void Main(string[] args)
        {
   //Reserviere Speicherplatz für 7 Variable von Typ double
            double[] p = new double [7];
            double[] a = new double [7];
            double[] b = new double [7];
            double max,min;
            int imax=0,imin=0;
 
// Einlesen eines Feld fast immer mit einer For-Schleife
            for (int i = 0; i < 7; i++)
            {
                Console.Write("Bitte Pegelstand eingeben: ");
                p[i] = Convert.ToDouble(Console.ReadLine());          
            }

            max = p[0]; min = p[0]; double sum=0,mw;
// Berechne das Maximum und das Minimum des Feldes p[]
// Wir berechnen die Stelle, an der MAximumm und das Minimum vorkommen
// Wir berechnen die Summe und den Mittelwert
                
            for (int i = 0; i < 7; i++)
            {
                if (max < p[i]) 
                {   max = p[i];
                    imax = i;
                }
                if (min > p[i]) 
                {   min = p[i];             
                    imin = i;
                }
                sum=sum+p[i];
            }

            mw=sum/7;

// Die Werte unter dem Mittelwert werden auf das Feld a gespeichert
// Die Werte über  dem Mittelwert werden auf das Feld b gespeichert
            int na = 0,nb = 0;
            for (int i = 0; i < 7; i++)
                if (p[i] < mw)
                {
                    a[na] = p[i];
                    na++;           // na ... Anzahl der Werte von Feld a
                }
                else
                {
                    b[nb] = p[i];
                    nb++;           // nb ... Anzahl der Werte von Feld b
                }

// Ausgabe des Feldes (fast) immer mit einer For-Schleife
            Console.WriteLine("Folgende Pegelstaende wurden eingelesen:");
            // Ausgabe eines Feldes fast immer mit einer Forschleife
            for (int i = 0; i < 7; i++)
            {
                Console.Write(" {0} ", p[i]);
            }
            
            Console.WriteLine("\n\nDas Maximum lautet {0} ", max);
            Console.WriteLine("Das Minimum lautet {0} ", min);
            Console.WriteLine("Der Mittelwert lautet {0} ", mw);
            Console.WriteLine("Das Maximum kommt an der {0}.ten Stelle vor", imax+1);
            Console.WriteLine("Das Maximum kommt an der {0}.ten Stelle vor", imin+1);

            Console.WriteLine("\n\nDie Werte unter dem Mittelwert:");
            for (int i = 0; i < na; i++)
                Console.Write("{0}  ", a[i]);

            Console.WriteLine("\n\nDie Werte über dem Mittelwert:");
            for (int i = 0; i < nb; i++)
                Console.Write("{0}  ", b[i]);

            Console.WriteLine("\n\n");
            Console.ReadLine();



// Zusatz: Berechne der Durchschnitt zweier Felder
            int[] A = new int[10]; int nA = 4;
            int[] B = new int[10]; int nB = 5;
            int[] C = new int[10]; int nC = 5;
            int nc = 0;
            for (int i = 0; i < nA; i++)
            {
                Console.Write("Bitte Wert für A eingeben: ");
                A[i] = Convert.ToInt32(Console.ReadLine());

            }
            for (int i = 0; i < nB; i++)
            {
                Console.Write("Bitte Wert für B  eingeben: ");
                B[i] = Convert.ToInt32(Console.ReadLine());

            }
            for (int i = 0; i < nA; i++)
                for (int j = 0; j < nB; j++)
                    if (A[i] == B[j]) C[nc++] = A[i];
          
            Console.WriteLine("\n\nDer Durchschnitt:");
            for (int i = 0; i < nc; i++)
                Console.Write("{0}  ", C[i]);

                Console.ReadLine();
        }
        }
    }

