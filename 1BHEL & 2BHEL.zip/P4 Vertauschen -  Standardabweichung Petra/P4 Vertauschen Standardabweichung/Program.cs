﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
 * 2BHEL 29.9. 
 * 
 * P4 vertauschen Standardabweichung
 * 
 * 
 * 1)   Wir lesen n Werte auf ein Feld a ein
 *      1a) Wir speichern das Feld a in umgekehrter reihenfolge auf ein feld b ab
 *      1b) Wir speichern die Werte von Feld a in umgekehrter Reihenfolge auf dem feld a ab
 * 
 * 2) Wir berechnen die Standardabweichung
 
 * 
 * 
 * 
 * 
 */

 
namespace P4_Vertauschen_Standardabweichung
{
    class Program
    {
        static void Main(string[] args)
        {
            Random zuf = new Random();
            Console.WriteLine("Zahl eingeben: ");
            int n = Convert.ToInt32(Console.ReadLine());

            // Zuweisen des feldes a
            int[] a = new int[n];
            for (int i = 0; i < n; i++)
                a[i] = zuf.Next(0, 10);

            // b[0] <- a[n-1]
            // b[1] <- a[n-2]
            // b[2] <- a[n-3]
            // b[i] <- a[n-(i+1)]

            //  Vertauschen von feld a
            int[] b = new int[n];
            for (int i = 0; i < n; i++)
                b[i] = a[n - (i + 1)];

            // Ausgabe von a 
            Console.WriteLine("Das Feld a\n");
            for (int i = 0; i < n; i++)
            {
                Console.Write(" {0} ", a[i]);
            }
            //Ausgabe von b
            Console.WriteLine("\nDas Feld b\n");
            for (int i = 0; i < n; i++)
            {
                Console.Write(" {0} ", b[i]);
            }

            // Aufgabe 1b) Abspeichern auf Feld a
            // a[0] <- a[n-1]
            // a[1] <- a[n-2]
            // a[2] <- a[n-3]
            // a[i] <- a[n-(i+1)]

            int temp;

            for (int i = 0; i < n/2; i++)
            {
                temp = a[i];

                a[i] = a[n - (i + 1)];
                a[n - (i + 1)] = temp;
            }

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Das Feld a(v1b)\n");
            for (int i = 0; i < n; i++)
            {
                Console.Write(" {0} ", a[i]);
            }

            // Aufgabe 2) Berechnung der Standardabweichung
            /*
             * Beispiel:   feld x = 2   5   3   1   4     (n=5)
             *              Summe:  15
             *              Mittelwert: 3
             *              Standardabweichung = [(Mittelwert-a[0])²+(Mittelwert-a[1])²....]/(n-1)
             * 
             *     s² = ((3-2)² + (3-5)² + (3-3)² + (3-1)² + (3-4)²)/(n-1)
             *      s² = (1  + 4 + 0 + 4 + 1)/4 = 2.5
             */
            double[] x = new double[n];
            double mw = 0,s=0;
            for (int i = 0; i < n; i++)
                x[i] = a[i];
            for (int i = 0; i < n; i++)
                mw = mw + x[i];
            mw = mw / n;
            for (int i = 0; i < n; i++)
                s = s + (x[i] - mw) * (x[i] - mw);
            s = Math.Sqrt(s / (n - 1));


            Console.ReadLine();
        }
    }
}
