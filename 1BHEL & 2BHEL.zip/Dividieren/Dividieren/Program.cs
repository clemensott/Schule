﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dividieren
{
    class Program
    {
        static void Main(string[] args)
        {
            // 2 Werte einlesen (Ganze Zahlen)
            Console.Write("Zähler: ");
            int z = Convert.ToInt32(Console.ReadLine());

            Console.Write("Nenner: ");
            int n = Convert.ToInt32(Console.ReadLine());
        }
    }
}
