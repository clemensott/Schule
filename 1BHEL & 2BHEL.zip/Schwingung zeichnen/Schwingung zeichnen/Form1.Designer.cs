﻿namespace Schwingung_zeichnen
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.hsb_fein = new System.Windows.Forms.HScrollBar();
            this.hsb_grob = new System.Windows.Forms.HScrollBar();
            this.SuspendLayout();
            // 
            // hsb_fein
            // 
            this.hsb_fein.Location = new System.Drawing.Point(13, 13);
            this.hsb_fein.Name = "hsb_fein";
            this.hsb_fein.Size = new System.Drawing.Size(174, 23);
            this.hsb_fein.TabIndex = 0;
            this.hsb_fein.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hsb_fein_Scroll);
            // 
            // hsb_grob
            // 
            this.hsb_grob.Location = new System.Drawing.Point(204, 13);
            this.hsb_grob.Name = "hsb_grob";
            this.hsb_grob.Size = new System.Drawing.Size(174, 23);
            this.hsb_grob.TabIndex = 0;
            this.hsb_grob.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hsb_grob_Scroll);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(415, 406);
            this.Controls.Add(this.hsb_grob);
            this.Controls.Add(this.hsb_fein);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.SizeChanged += new System.EventHandler(this.Form1_SizeChanged);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.HScrollBar hsb_fein;
        private System.Windows.Forms.HScrollBar hsb_grob;

    }
}

