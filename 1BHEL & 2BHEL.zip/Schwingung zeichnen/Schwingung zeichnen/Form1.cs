﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Schwingung_zeichnen
{
    public partial class Form1 : Form
    {
        Point[] pos;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            neu_berechnen();
        }

        private void neu_berechnen()
        {
            pos = new Point[Size.Width - 33];
            
            for (int i = 0; i < pos.Length; i++)
            {
                pos[i] = new Point(i + 10, Convert.ToInt32(Size.Height / 2 - 10 - (Size.Height / 2 - 50) * Math.Sin(2 * Math.PI / Convert.ToDouble(pos.Length) * i * (hsb_grob.Value/5.0 + hsb_fein.Value / 50.0))));
            }

            Invalidate();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            if (pos.Length > 0)
            {
                e.Graphics.DrawCurve(new Pen(Color.Black, 1), pos);
            }
        }

        private void Form1_SizeChanged(object sender, EventArgs e)
        {
            neu_berechnen();
        }

        private void hsb_fein_Scroll(object sender, ScrollEventArgs e)
        {
            neu_berechnen();
        }

        private void hsb_grob_Scroll(object sender, ScrollEventArgs e)
        {
            neu_berechnen();
        }
    }
}
