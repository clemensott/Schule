// C++ Visiten.cpp : Definiert den Einstiegspunkt f�r die Konsolenanwendung.
//

#include "stdafx.h"

typedef struct adresse
{
	char vor[100],nach[100],strase[100],ort[100],geburt[100];
	int nr,plz;
};

void main()
{
	adresse daten;

	printf("Vorname: ");
	gets(daten.vor);

	printf("Nachname: ");
	gets(daten.nach);

	printf("Geburtsdatum: ");
	gets(daten.geburt);

	printf("Strasse: ");
	gets(daten.strase);

	printf("Hausnummer: ");
	scanf("%d",&daten.nr);

	printf("Postleitzahl: ");
	scanf("%d",&daten.plz);

	printf("Ort: ");
	fflush(stdin);
	gets(daten.ort);

	printf("\n");

	printf("%s %s\n",daten.vor,daten.nach);
	printf("%s\n",daten.geburt);
	printf("%s %d\n",daten.strase,daten.nr);
	printf("%d %s\n",daten.plz,daten.ort);
	
	printf("\n");
}

