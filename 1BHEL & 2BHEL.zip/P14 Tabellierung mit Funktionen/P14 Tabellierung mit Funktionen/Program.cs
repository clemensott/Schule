﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P14_Tabellierung_mit_Funktionen
{
    class Program
    {
        static void Main(string[] args)
        {
            // Wir tabellieren eine Funktion y = ax^2 + bx + c

            // Die Tabelle hat folgende Gesalt: (bei y = x^2)
            //          x        y
            //       ---------------
            //          
            // Der Funktionswert ist nun vom Typ double
            // Die Funktion hat 4 Parameter: a, b, c und x

            double a, b, c, x;
            Console.WriteLine("Wir erstellen eine Tabelle von y = ax * x + bx + c");
            Console.WriteLine("Bitte geben sie a ein: ");
            a = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Bitte geben sie b ein: ");
            b = Convert.ToDouble(Console.ReadLine()); 
            Console.WriteLine("Bitte geben sie c ein: ");
            c = Convert.ToDouble(Console.ReadLine());

            x = 0.0;       // Startwert der Tabelle
            double y;      // 
            do
            {
                y = F(a, b, c, x);
                Console.WriteLine("{0,8:N2} {1,8:N2}", x, y);
                // {0,8:N2} .... 8 Stellen insgesamt und 2 Kommastellen
                x = x + 0.1;
            } while (x <= 1.0);

            Console.ReadLine();

        } 
        // double a, double b, double c, double x .... Parameterliste
        // Die Variablea, b, c und x sind die Parameter
        // Die Reihenfolge der Parameter muss der Reihenfolge vom aufrufenden Programm entsprechen
        // Der Datentyp der Parameter muss übereinstimmen
        static double F(double a, double b, double c, double x)
        {
            double y;
            y = a * x * x + b * x + c;
            return y;    
      }
    }
 }

