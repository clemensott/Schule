﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 * 2BHEL 6.10.2014 Als Hausübung, wird eine MK
 * 2BHEL 13.10. fertig gemacht
 * 
 * Programm Pegelstand: Buch Seite 30/31, Beispiel 32, Übung 42
 * 
 * Wir weisen einer 4*7 Matrix die Pegelstände (zwischen 0 und 5) von 4 Wochen zu
 * 
 * Dann berechnen wir die Durchschnittswerte pro Woche und pro Wochentag
 * 
 * Anschließend die jeweiligen Maxima und Minima pro Woche und pro Wochentag
 * 
 * Dann berechnen wir das Gesamtmaximum, Gesamtminimum und Gesamtmittelwert
 * 
 * Die Ausgabe erfolgt folgend:
 * 
 * 
 *      p[0,0]      p[0,1] ... p[0,6]  Mittelwert[0]  Maximum[0]  Minimum[0]
 *      p[1,0]      p[1,1] ... p[1,6]  Mittelwert[1]  Maximum[1]  Minimum[1]
 *      p[2,0]      p[2,1] ... p[2,6]  Mittelwert[3]  Maximum[2]  Minimum[2]
 *      p[3,0]      p[3,1] ... p[3,6]  Mittelwert[4]  Maximum[3]  Minimum[3]
 *      mw_tag[0]   mw_tag[1]           mw_gesamt     
 *      max_tag[0]                                    MaxGesamt
 *      min_tag[0]                                                Mingesamt
 */

namespace P7_Pegelstand
{
    class Program
    {
        static void Main(string[] args)
        {
            int z=4,s=7,i,j;
            Random zfz = new Random();
            int [,]a = new int [z,s];
            //zuweisen der Zufalls-Zahlen
            // i ist der Zeilenzähler,j ist der Spaltenzähler
            for (i=0; i < 4; i++)
            {
                for (j=0; j < 7;j++)
                {
                   a[i,j]= zfz.Next(0,5);
                   
                }
                
            }
            // ausgabe der matrix

            double sum = 0;
            double[] mw = new double[z];        // Feld für Mittelwerte der Zeilen
            int[] maxz = new int[z];            // Feld für Maxima der Zeilen
            int[] minz = new int[z];            // feld für Minima der Zeilen 

 // Berechnung der Mittelwerte 
            // a(0,0)+a(0,1)+a(0,2)......+a(0,6) ... erste Zeile
            for (i = 0; i < z; i++)
            {
                maxz[i] = a[i, 0];          // Das erste Element ist das Maximum
                minz[i] = a[i, 0];          // Das erste Element ist das Minimum
                for (j = 0; j < 7; j++)
                {
                    mw[i] = mw[i] + a[i, j];
                    
                    if (maxz[i] < a[i, j]) maxz[i] = a[i, j];   // Maximumberechnung
                    if (minz[i] > a[i, j]) minz[i] = a[i, j];   // Minimumberechnung
                }
                mw[i] = mw[i] / s;

            }
          
// Ausgabe der Ergebnisse
            Console.Clear();                    // 
            Console.SetCursorPosition(22, 0);   // Setze Cursor auf Spalte 70, zeile 0
            Console.WriteLine("MW   MAX  MIN");
            for (i = 0; i < 36; i++) Console.Write("-");
            Console.WriteLine();
            for (i = 0; i < 4; i++)
            {
                for (j = 0; j < 7; j++)
                {
                    Console.Write("{0}  ", a[i, j]);

                }
                Console.WriteLine("{0:N2}   {1}    {2}", mw[i], maxz[i], minz[i]);

            }
            for (i = 0; i < 36; i++) Console.Write("-");
            Console.WriteLine();
        }
    }
}
