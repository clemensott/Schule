﻿namespace Rechentrainer_2
{
    partial class Rechentrainer
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_prufen = new System.Windows.Forms.Button();
            this.txb_zahl2 = new System.Windows.Forms.TextBox();
            this.txb_ergebnis = new System.Windows.Forms.TextBox();
            this.txb_zahl1 = new System.Windows.Forms.TextBox();
            this.lbl_zahl1 = new System.Windows.Forms.Label();
            this.lbl_zahl2 = new System.Windows.Forms.Label();
            this.lbl_ergebnis = new System.Windows.Forms.Label();
            this.rbt_plus = new System.Windows.Forms.RadioButton();
            this.rbt_minus = new System.Windows.Forms.RadioButton();
            this.rbt_mal = new System.Windows.Forms.RadioButton();
            this.rbt_teilen = new System.Windows.Forms.RadioButton();
            this.txb_bereich_hin = new System.Windows.Forms.TextBox();
            this.btn_neu = new System.Windows.Forms.Button();
            this.txb_bereich_vor = new System.Windows.Forms.TextBox();
            this.lbl_strich = new System.Windows.Forms.Label();
            this.lbl_bereich = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_prufen
            // 
            this.btn_prufen.Location = new System.Drawing.Point(34, 218);
            this.btn_prufen.Name = "btn_prufen";
            this.btn_prufen.Size = new System.Drawing.Size(75, 23);
            this.btn_prufen.TabIndex = 0;
            this.btn_prufen.Text = "Prüfen";
            this.btn_prufen.UseVisualStyleBackColor = true;
            this.btn_prufen.Click += new System.EventHandler(this.btn_prufen_Click);
            // 
            // txb_zahl2
            // 
            this.txb_zahl2.Enabled = false;
            this.txb_zahl2.Location = new System.Drawing.Point(34, 109);
            this.txb_zahl2.Name = "txb_zahl2";
            this.txb_zahl2.Size = new System.Drawing.Size(75, 20);
            this.txb_zahl2.TabIndex = 1;
            // 
            // txb_ergebnis
            // 
            this.txb_ergebnis.Location = new System.Drawing.Point(34, 172);
            this.txb_ergebnis.Name = "txb_ergebnis";
            this.txb_ergebnis.Size = new System.Drawing.Size(75, 20);
            this.txb_ergebnis.TabIndex = 2;
            // 
            // txb_zahl1
            // 
            this.txb_zahl1.Enabled = false;
            this.txb_zahl1.Location = new System.Drawing.Point(34, 55);
            this.txb_zahl1.Name = "txb_zahl1";
            this.txb_zahl1.Size = new System.Drawing.Size(75, 20);
            this.txb_zahl1.TabIndex = 3;
            // 
            // lbl_zahl1
            // 
            this.lbl_zahl1.AutoSize = true;
            this.lbl_zahl1.Location = new System.Drawing.Point(31, 39);
            this.lbl_zahl1.Name = "lbl_zahl1";
            this.lbl_zahl1.Size = new System.Drawing.Size(37, 13);
            this.lbl_zahl1.TabIndex = 4;
            this.lbl_zahl1.Text = "Zahl 1";
            // 
            // lbl_zahl2
            // 
            this.lbl_zahl2.AutoSize = true;
            this.lbl_zahl2.Location = new System.Drawing.Point(31, 93);
            this.lbl_zahl2.Name = "lbl_zahl2";
            this.lbl_zahl2.Size = new System.Drawing.Size(37, 13);
            this.lbl_zahl2.TabIndex = 5;
            this.lbl_zahl2.Text = "Zahl 2";
            // 
            // lbl_ergebnis
            // 
            this.lbl_ergebnis.AutoSize = true;
            this.lbl_ergebnis.Location = new System.Drawing.Point(31, 156);
            this.lbl_ergebnis.Name = "lbl_ergebnis";
            this.lbl_ergebnis.Size = new System.Drawing.Size(48, 13);
            this.lbl_ergebnis.TabIndex = 6;
            this.lbl_ergebnis.Text = "Ergebnis";
            // 
            // rbt_plus
            // 
            this.rbt_plus.AutoSize = true;
            this.rbt_plus.Location = new System.Drawing.Point(168, 100);
            this.rbt_plus.Name = "rbt_plus";
            this.rbt_plus.Size = new System.Drawing.Size(31, 17);
            this.rbt_plus.TabIndex = 7;
            this.rbt_plus.TabStop = true;
            this.rbt_plus.Text = "+";
            this.rbt_plus.UseVisualStyleBackColor = true;
            this.rbt_plus.CheckedChanged += new System.EventHandler(this.rbt_plus_CheckedChanged);
            // 
            // rbt_minus
            // 
            this.rbt_minus.AutoSize = true;
            this.rbt_minus.Location = new System.Drawing.Point(168, 124);
            this.rbt_minus.Name = "rbt_minus";
            this.rbt_minus.Size = new System.Drawing.Size(28, 17);
            this.rbt_minus.TabIndex = 8;
            this.rbt_minus.TabStop = true;
            this.rbt_minus.Text = "-";
            this.rbt_minus.UseVisualStyleBackColor = true;
            this.rbt_minus.CheckedChanged += new System.EventHandler(this.rbt_minus_CheckedChanged);
            // 
            // rbt_mal
            // 
            this.rbt_mal.AutoSize = true;
            this.rbt_mal.Location = new System.Drawing.Point(168, 148);
            this.rbt_mal.Name = "rbt_mal";
            this.rbt_mal.Size = new System.Drawing.Size(29, 17);
            this.rbt_mal.TabIndex = 9;
            this.rbt_mal.TabStop = true;
            this.rbt_mal.Text = "*";
            this.rbt_mal.UseVisualStyleBackColor = true;
            this.rbt_mal.CheckedChanged += new System.EventHandler(this.rbt_mal_CheckedChanged);
            // 
            // rbt_teilen
            // 
            this.rbt_teilen.AutoSize = true;
            this.rbt_teilen.Location = new System.Drawing.Point(168, 172);
            this.rbt_teilen.Name = "rbt_teilen";
            this.rbt_teilen.Size = new System.Drawing.Size(30, 17);
            this.rbt_teilen.TabIndex = 10;
            this.rbt_teilen.TabStop = true;
            this.rbt_teilen.Text = "/";
            this.rbt_teilen.UseVisualStyleBackColor = true;
            this.rbt_teilen.CheckedChanged += new System.EventHandler(this.rbt_teilen_CheckedChanged);
            // 
            // txb_bereich_hin
            // 
            this.txb_bereich_hin.Location = new System.Drawing.Point(205, 55);
            this.txb_bereich_hin.Name = "txb_bereich_hin";
            this.txb_bereich_hin.Size = new System.Drawing.Size(47, 20);
            this.txb_bereich_hin.TabIndex = 11;
            // 
            // btn_neu
            // 
            this.btn_neu.Location = new System.Drawing.Point(168, 218);
            this.btn_neu.Name = "btn_neu";
            this.btn_neu.Size = new System.Drawing.Size(85, 23);
            this.btn_neu.TabIndex = 14;
            this.btn_neu.Text = "Neue Aufgabe";
            this.btn_neu.UseVisualStyleBackColor = true;
            this.btn_neu.Click += new System.EventHandler(this.btn_neu_Click);
            // 
            // txb_bereich_vor
            // 
            this.txb_bereich_vor.Location = new System.Drawing.Point(151, 55);
            this.txb_bereich_vor.Name = "txb_bereich_vor";
            this.txb_bereich_vor.Size = new System.Drawing.Size(47, 20);
            this.txb_bereich_vor.TabIndex = 15;
            this.txb_bereich_vor.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txb_bereich_vor.TextChanged += new System.EventHandler(this.txb_bereich_vor_TextChanged);
            // 
            // lbl_strich
            // 
            this.lbl_strich.AutoSize = true;
            this.lbl_strich.Location = new System.Drawing.Point(197, 57);
            this.lbl_strich.Name = "lbl_strich";
            this.lbl_strich.Size = new System.Drawing.Size(10, 13);
            this.lbl_strich.TabIndex = 16;
            this.lbl_strich.Text = "-";
            // 
            // lbl_bereich
            // 
            this.lbl_bereich.AutoSize = true;
            this.lbl_bereich.Location = new System.Drawing.Point(165, 39);
            this.lbl_bereich.Name = "lbl_bereich";
            this.lbl_bereich.Size = new System.Drawing.Size(75, 13);
            this.lbl_bereich.TabIndex = 17;
            this.lbl_bereich.Text = "Zahlenbereich";
            // 
            // Rechentrainer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.lbl_bereich);
            this.Controls.Add(this.lbl_strich);
            this.Controls.Add(this.txb_bereich_vor);
            this.Controls.Add(this.btn_neu);
            this.Controls.Add(this.txb_bereich_hin);
            this.Controls.Add(this.rbt_teilen);
            this.Controls.Add(this.rbt_mal);
            this.Controls.Add(this.rbt_minus);
            this.Controls.Add(this.rbt_plus);
            this.Controls.Add(this.lbl_ergebnis);
            this.Controls.Add(this.lbl_zahl2);
            this.Controls.Add(this.lbl_zahl1);
            this.Controls.Add(this.txb_zahl1);
            this.Controls.Add(this.txb_ergebnis);
            this.Controls.Add(this.txb_zahl2);
            this.Controls.Add(this.btn_prufen);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Rechentrainer";
            this.Text = "Rechentrainer";
            this.Load += new System.EventHandler(this.Rechentrainer_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_prufen;
        private System.Windows.Forms.TextBox txb_zahl2;
        private System.Windows.Forms.TextBox txb_ergebnis;
        private System.Windows.Forms.TextBox txb_zahl1;
        private System.Windows.Forms.Label lbl_zahl1;
        private System.Windows.Forms.Label lbl_zahl2;
        private System.Windows.Forms.Label lbl_ergebnis;
        private System.Windows.Forms.RadioButton rbt_plus;
        private System.Windows.Forms.RadioButton rbt_minus;
        private System.Windows.Forms.RadioButton rbt_mal;
        private System.Windows.Forms.RadioButton rbt_teilen;
        private System.Windows.Forms.TextBox txb_bereich_hin;
        private System.Windows.Forms.Button btn_neu;
        private System.Windows.Forms.TextBox txb_bereich_vor;
        private System.Windows.Forms.Label lbl_strich;
        private System.Windows.Forms.Label lbl_bereich;
    }
}

