﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rechentrainer_2
{
    public partial class Rechentrainer : Form
    {
        public Rechentrainer()
        {
            InitializeComponent();
        }

        private void Rechentrainer_Load(object sender, EventArgs e)
        {
            txb_bereich_hin.Text = "50";
            txb_bereich_vor.Text = "10";
            
            rbt_plus.Checked = true;

            zahlengenerrieren();
        }

        private void zahlengenerrieren()
        {
            Random zahl = new Random();
            int zahl1, zahl2, rest, bereich_hin = 0, bereich_vor = 0;

            bereich_hin = 1 + Convert.ToInt32(txb_bereich_hin.Text);
            bereich_vor = Convert.ToInt32(txb_bereich_vor.Text);

            if (rbt_teilen.Checked)
                {
                    do
                    {
                        zahl1 = zahl.Next(bereich_vor, bereich_hin);
                        zahl2 = zahl.Next(bereich_vor, bereich_hin);

                        txb_zahl1.Text = Convert.ToString(zahl1);
                        txb_zahl2.Text = Convert.ToString(zahl2);

                        rest = zahl1 % zahl2;

                    } while (rest != 0 || zahl1 == zahl2 || zahl1 == 1);
                }
                else
                {
                    txb_zahl1.Text = Convert.ToString(zahl.Next(bereich_vor, bereich_hin));
                    txb_zahl2.Text = Convert.ToString(zahl.Next(bereich_vor, bereich_hin));
                }

                txb_ergebnis.Text = "";        

        }

        private void prufen()
        {
            int zahl1, zahl2, ergebnis, ergebnisn;

            zahl1 = Convert.ToInt32(txb_zahl1.Text);
            zahl2 = Convert.ToInt32(txb_zahl2.Text);
            ergebnisn = Convert.ToInt32(txb_ergebnis.Text);

            if (rbt_plus.Checked)
            {
                ergebnis = zahl1 + zahl2;
            }
            else
            {
                if (rbt_minus.Checked)
                {
                    ergebnis = zahl1 - zahl2;
                }
                else
                {
                    if (rbt_mal.Checked)
                    {
                        ergebnis = zahl1 * zahl2;
                    }
                    else
                    {
                        ergebnis = zahl1 / zahl2;
                    }
                }
            }

            if (ergebnis == ergebnisn)
            {
                MessageBox.Show("Richtig", "Rückmeldung");
            }
            else
            {
                MessageBox.Show("Falsch", "Rückmeldung");
            }

            zahlengenerrieren();
        }

        private void btn_prufen_Click(object sender, EventArgs e)
        {
            prufen();
        }

        private void btn_neu_Click(object sender, EventArgs e)
        {
            zahlengenerrieren();
        }

        private void rbt_plus_CheckedChanged(object sender, EventArgs e)
        {
            zahlengenerrieren();
        }

        private void rbt_minus_CheckedChanged(object sender, EventArgs e)
        {
            zahlengenerrieren();
        }

        private void rbt_mal_CheckedChanged(object sender, EventArgs e)
        {
            zahlengenerrieren();
        }

        private void rbt_teilen_CheckedChanged(object sender, EventArgs e)
        {
            pruf_hin();

            zahlengenerrieren();
        }

        private void txb_bereich_hin_TextChanged(object sender, EventArgs e)
        {
            pruf_hin();
        }

        private void txb_bereich_vor_TextChanged(object sender, EventArgs e)
        {
            pruf_vor();
        }

        private void pruf_vor()
        { 
        int bereich_vor = 0, bereich_hin = 0;
            bool fehler = false;

            if (txb_bereich_vor.Text != "")
            {
                try
                {
                    bereich_vor = Convert.ToInt32(txb_bereich_vor.Text);

                    bereich_hin = Convert.ToInt32(txb_bereich_hin.Text);

                    if (bereich_vor >= bereich_hin)
                    {
                        fehler = true;
                    }
                }
                catch
                {
                    fehler = true;
                }

                if (rbt_teilen.Checked && (bereich_hin / bereich_vor) < 2)
                {
                    txb_bereich_hin.Text = Convert.ToString(bereich_vor * 2);

                    fehler = true;
                }

                if (fehler)
                {
                    txb_bereich_vor.Text = "";

                    MessageBox.Show("Zahlenbereich nicht möglich", "Fehler");
                }
                else
                {
                    zahlengenerrieren();
                }
            }
        }

        private void pruf_hin()
        {
            int bereich_vor = 0, bereich_hin = 0;
            bool fehler = false;

            if (txb_bereich_hin.Text != "")
            {
                try
                {
                    bereich_vor = Convert.ToInt32(txb_bereich_vor.Text);

                    bereich_hin = Convert.ToInt32(txb_bereich_hin.Text);

                    if (bereich_vor >= bereich_hin)
                    {
                        fehler = true;
                    }
                }
                catch
                {
                    fehler = true;
                }

                if (rbt_teilen.Checked && ((bereich_hin / bereich_vor) < 2))
                {
                    txb_bereich_hin.Text = Convert.ToString(bereich_vor * 2);

                    fehler = true;
                }

                if (fehler)
                {
                    txb_bereich_hin.Text = "";

                    MessageBox.Show("Zahlenbereich nicht möglich", "Fehler");
                }
                else
                {
                    zahlengenerrieren();
                }
            }
        }
    }
}
