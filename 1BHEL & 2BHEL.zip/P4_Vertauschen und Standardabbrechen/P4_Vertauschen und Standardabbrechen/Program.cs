﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P4_Vertauschen_und_Standardabbrechen
{
    class Program
    {
        static void Main(string[] args)
        {
            /* P4 Vertauschen Standerdabweichung
             * 
             * 
             * 1)   Wir lesen n Werte auf ein Feld a ein
             *      1a) Wir speichern das Feld a in umgekehrter Reihenfolge auf einem feld b ab
             *      1b) Wir speichern die Werte von Feld a in umgekehrter Reihenfolge auf dem Feld a ab
             * 
             * 2) Wir berechnen die Standardabweichung
             * 
             * 
             * 
             * 
             * 
             */

            int n;
            Random zuf = new Random();

            Console.Write("Zahl eingeben: ");
            n = Convert.ToInt32(Console.ReadLine());

            int[] a = new int[n];
            int[] b = new int[n];

            for (int i = 0; i < n; i++)
            {
                a[i] = zuf.Next(0, 2356);
            }

            for (int i = 0; i < n; i++)
            {
                b[i] = a[n - i - 1];
            }

            Console.WriteLine("\nDas Feld a:");

            for (int i = 0; i < n; i++)
            {
                Console.Write(a[i] + " ");
            }

            Console.WriteLine("\n\nDas Feld b:");

            for (int i = 0; i < n; i++)
            {
                Console.Write(b[i] + " ");
            }

            for (int i = 0; i < (n / 2); i++)
            {
                int z = a[i];

                a[i] = a[n - i - 1];

                int j = n - i - 1;

                a[j] = z;
            }

            Console.WriteLine("\n\nDas Feld a(v1b):");

            for (int i = 0; i < n; i++)
            {
                Console.Write(a[i] + " ");
            }

            double[] x = new double[5] {2, 5, 3, 1, 4};
            double m = 3, s, d = 0;

            for (int i = 0; i < 5; i++)
            {
                d = d + Math.Pow(m - x[i], 2);
            }

            s = Math.Sqrt(1 / d);

            Console.WriteLine("\n\ns: {0}", s);


            Console.ReadLine();
        }
    }
}
